//Imports
var mysql    = require('mysql');
var settings = require('./Settings');
var log      = require('../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 4;


var initialized = false;
var queryQueue = [];
var connection = mysql.createConnection({
  host     : settings.host,
  user     : settings.user,
  password : settings.password,
  database : settings.db
});


exports.init = function() {
	connection.connect(function(err) {
		if(err) {
			log.error('Database Connection Failed!');
		} else {
			log.info('Database Connection Success');
			initialized = true;
		}
	});
};

exports.query = function(query,filters,callback) {
	if(!initialized) {
		log.debug("DBHandler isn't initialized yet. Cannot run method query.");
		queryQueue.push({
			func    : "query",
			query   : query,
			filters : filters,
			callback: callback
		});
		return;
	}

	var innerQuery = query;
	if (filters) {
		var moreThanOne = false;
		innerQuery += ' WHERE ';
		for(var i in filters) {
			if(!moreThanOne) {
				innerQuery += i + '=' + mysql.escape(filters[i]) + ' ';
				moreThanOne = true;
			} else {
				innerQuery += 'AND ' + i + '=' + mysql.escape(filters[i]) + ' ';
			}
		}
	}
	log.debug("Query about to run: " +  innerQuery);
	connection.query(innerQuery,callback);
}


function checkForQueries() {
	for(var i in queryQueue) {
		switch(queryQueue[i].func) {
			case "query":
				exports.query(queryQueue[i].query,queryQueue[i].filters,queryQueue[i].callback);
				queryQueue.splice(i,1);
			break;
		}
	}
}


setInterval(checkForQueries,5000);

