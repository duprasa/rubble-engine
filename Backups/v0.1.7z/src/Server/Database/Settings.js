exports.host     = 'localhost';
exports.user     = 'root';
exports.password = 'root';
exports.db       = 'node';