/*== Server settings Module ==*/

//Status: 4 (stable)
//This module provides settings for the Http server, the 
//SocketIO server, and the modules enabled that have to 
//do with the server



exports.settings = {
	//For Both Servers
	domain : "localhost",
	port : 1200,
	//For Http Server
	encoding : "utf8",
	//For SocketIO Server
	logLevel : 1,
	closeTimeout: 10,
	heartbeatTimeout: 10,
	heartbeatInterval: 5,
	pollingDuration: 5,

	//Utility Settings
	//Logger
	defaultLogLevel : 3,
	loggingEnabled : true
};