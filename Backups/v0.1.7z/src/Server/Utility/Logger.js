/*== Logger Module ==*/

//Status: 5 (Very Stable)
//Logger module simply logs info, warnings or debug info
//depending on server settings.



//Imports
var fs = require('fs');
var settings = require("../Settings").settings;
var fileManager = require('./FileManager');

//module variables
var red      = '\033[31m';
var crazyRed = '\033[41m';
var green    = '\033[36m';
var beige    = '\033[33m';
var reset    =  '\033[0m';


exports.makeInstance = function () {
	return new Logger();
};


//Logger Constructor
function Logger() {
	this.enabled = settings.loggingEnabled;
	this.level = settings.defaultLogLevel;
};


//Logger functions
Logger.prototype.file  = function(message,filename) {
	if(this.enabled == false) {
		return;
	}

	if(this.level >= 0) {
		fileManager.log(message,filename);
	}
};


Logger.prototype.error = function(message) {

	if(this.enabled == false) {
		return;
	}

	if(this.level >= 1) {
		log(message,crazyRed);
		//TODO: Should end app here in an organized manner
	}

};


Logger.prototype.warn = function(message) {
	if(this.enabled == false) {
		return;
	}

	if(this.level >= 2) {
		log(message,red);
	}
};


Logger.prototype.info = function(message) {

	if(this.enabled == false) {
		return;
	}

	if(this.level >= 3) {
		log(message,green);
	}

};


Logger.prototype.debug = function(message) {

	if(this.enabled == false) {
		return;
	}

	if(this.level >= 4) {
		log(message,beige);
	}

};




function log(message,color) {
	if((typeof message) === "object") {
		console.log((color || reset) + JSON.stringify(message,function (key,value) {
	//value is an object.
	if (typeof value === "object") {
		//value is object to display.
		if(value === message) {
			//root
			if(key === '') {
				return value;
			//reference down the chain
			} else {
				return "Itself";
			}
		}
		//value is an object within the first level
		if(message[key]) {
			return value;
		} 

		//value is an object within the second level
		for(var i in message) {
			if(message[i][key] === value) {
				return value;
			}
		}

		return "Object";

	}
	else if(typeof value === "function") {
		return "Function";
	
	//value is not an object
	} else {
		return value;
	}
}

,"\t") + reset);
	} else {
		console.log( (color || reset) + message + reset );
	}
}

