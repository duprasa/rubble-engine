/*== Database Module ==*/

//Status: 0 (To be implemented AND defined)
//The database module is the layer in between the game and
//any sort of persistant datastoring related to players, default
//maps or saving any player progress it also loads such such things.
//It should access a data layer's module to obtain db functionailty


//Imports
var settings = require("./Settings");
var data     = require("./Data");
var log      = require('../Utility/Logger').makeInstance();


//Module logging
log.enabled  = true;
log.level    = 3;


exports.load = function() {

	if(settings.moduleEnabled["Database"] == false) {
		return;
	}

	//TODO: Actually load stuff from MongoDB database or MySql
	data.players["1"]   = "Nick";
	data.players["2"]   = "Sam";
	data.monsters["19"] = "Slender man";

}
