/*== Client Events Module ==*/

//Status: -1 (Empty as fuck)
//This module is in charge of either receiving messages 
//from SocketIO server or a queue of messages and keeping
//them here until the Loop module takes care of them.



//Imports
var settings     = require("../Settings");
var data         = require("../Data");
var ioServer = require("../../IO Server/IOHandler");
var log          = require('../../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level = 3;


exports.update = function() {
	var queue = ioServer.queue;
	var relevantData = queue["playerMoved"];

	for(var i in relevantData) {
		data.players["1"] = relevantData[i].data.x;
		data.players["2"] = relevantData[i].data.y;
	}
};
