/*== Client Update Module ==*/

//Status: -1 (Empty as fuck)
//This module is in charge of updating the minimum
//necessary for each client so they know what is 
//going on in their maps and on the maps around them
//as well as their friends' and allies' positions.



//Imports
var settings     = require("../Settings");
var data         = require("../Data");
var ioServer 	 = require("../../IO Server/IOHandler");
var log          = require('../../Utility/Logger').makeInstance();


//Module logging;
log.enabled = true;
log.level   = 3;

exports.update = function() {
	if(settings.moduleEnabled["ClientUpdates"] == false) {
		return;
	}

	//Send messages to peeps about updated locations. and other stuff.
};

