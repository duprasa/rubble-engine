/*== IO Handler Module ==*/

//Status: 2.5 (deprecated, sam has newer version)
//This module deals with the IO Server. It is the root
//of the IO server and point of access for other modules.
//It defines what we do when we receive a SocketIO request and
//routes it appropriately. It might put certain messages received
//in a queue for other modules to loop through them when needed 
//ex: The Game Server Module



//Imports
var log    = require('../Utility/Logger').makeInstance();
var router = require('./router.js');

var eventQueue = {};
//Module logging
log.enabled = true;
log.level   = 3;


var socketIO = null;
var initialized = false;


exports.init = function(inSocketIO){
	initialized = true;
	socketIO = inSocketIO;
	log.info('IO server initialized!');

};
exports.start = function(){
	if(!initialized){
		return;
	}
	router.route(socketIO,eventQueue);
};
exports.emit = function(socket,handleName,Data){
	if(!initialized){
		return;
	}
	socket.emit(handleName,Data);

};
exports.broadcast = function(socket,handleName,Data){
	if(!initialized){
		return;
	}
	socket.broadcast.emit(handleName,Data);

};
exports.broadcastAll = function(handleName,Data){
	if(!initialized){
		return;
	}
	socketIO.sockets.emit(handleName,Data);

};
exports.queue = eventQueue;

exports.getConnectedIds = function(){
	if(!initialized){
		return;
	}
	return Object.keys(socketIO.connected);
};