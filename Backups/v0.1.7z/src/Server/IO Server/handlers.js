/*== IO Handlers Module ==*/

//Status: 2.5 
//This module defines what we do with requests after they
//have been routed here, hence handlers



//Imports
var log = require('../Utility/Logger').makeInstance();


//Module logging.
log.enabled = true;
log.level   = 4;


exports.handlers = {
	test: 	   {queue	: 'single',
				callback:function(data,socket){
					log.debug(data);
					socket.emit('test',data);
				}},
	playerMoved:{queue	: 'single',
				callback:function(data,socket){
					log.debug(data);
					socket.emit('test',data);
				}},
	disconnect:{queue   : true,
				callback:function(data,socket,socketIO){
					log.debug('disconnect');
					var address = socket.handshake.address;
					log.debug('User has disconnected : '+ address.address + ":" + address.port);
					//need reference to socket io to show number of users
					log.debug('number of connected users:' + (Object.keys(socketIO.connected).length - 1));
					socket.broadcast.emit('playerLeft',socket.id);
	 			}},
	signIn:    {queue	: true,
				callback:function(data,socket,socketIO){
					log.debug(data.username + ' has logged in');

				}}
};