window.onload = function() {
	var socket = io.connect();
	var movePlayer = document.getElementById('movePlayer');
	var submit = document.getElementById('submit');
	submit.onclick = function(){
		var username = document.getElementById('username').value;
		var password = document.getElementById('password').value;
		socket.emit('signIn',{username:username,password:password});
	};
	movePlayer.onclick = function(){
		socket.emit('playerMoved',{x:Math.round(Math.random() * 100),y:Math.round(Math.random() * 100)});

	};
	socket.on('test',function(Data){
		console.log(Data);
	});

};
