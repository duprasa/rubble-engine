/*== IO Handlers Module ==*/

//Status: 2.5 
//This module defines what we do with requests after they
//have been routed here, hence handlers



//Imports
var log      = require('../Utility/Logger').makeInstance("IO Handlers");
var userData = require('../Game Server/Users/UserData');
var settings = require('../Settings');

//Module logging.
log.enabled = true;
log.level   = 4;


exports.handlers = {
	playerMove:{queue	: 'single',
				callback:function(data,socket){
					log.debug(data);
					socket.emit('test',data);
				}},
	disconnect:{queue   : true,
				callback:function(data,socket,socketIO){
					log.debug('disconnect');
					var address = socket.handshake.address;
					log.debug('User has disconnected : '+ address.address + ":" + address.port);
					//need reference to socket io to show number of users
					log.debug('number of connected users:' + (Object.keys(socketIO.connected).length - 1));
					socket.broadcast.emit('playerLeft',socket.id);
	 			}},

	newPlayer:   {queue	: true,
				callback:function(data,socket,socketIO){

				}},

	authenticateUser : {queue : false,
				callback:function(data,socket){
					//Check if nickname has been attempted x times from y ip.
					log.debug('whats up');
					var ip       = socket.handshake.address.address;
					var status = "NOT_VALID";
					log.debug(data.nickname);
					log.debug(data.password);
					log.debug(ip);



					if(userData.users[data.nickname]) {
						log.debug('Nickname: ' + data.nickname + ' exists.');
						if(userData.users[data.nickname].invalidAttempts[ip]) {
							log.debug('User has tried to log in from ip: ' + ip + ' already.' + '(' +userData.users[data.nickname].invalidAttempts[ip] + ') times.' );
							if(userData.users[data.nickname].invalidAttempts[ip] >= settings.loginAttempts) {
								log.debug('invalid attempts over maximum allowed');
								status = "TOO_MANY_ATTEMPTS";
							} else {
								if(userData.users[data.nickname].password == data.password) {
									log.debug("validated!");
									status = "VALID";
								}	
							}
						}else if(userData.users[data.nickname].password == data.password) {
							log.debug('User has never tried to log in from ip: ' + ip);
							log.debug('validated!');
							status = "VALID";
						}
					}

					if((status == "NOT_VALID" || status == "TOO_MANY_ATTEMPTS") && userData.users[data.nickname]) {
						log.debug('Validation failed.');
						if(userData.users[data.nickname].invalidAttempts[ip]) {
							log.debug('Attempts from ip:  ' + ip +' increased by 1');
							userData.users[data.nickname].invalidAttempts[ip] += 1;
						} else {
							log.debug('Logged the failed attempt on ip: ' + ip);
							userData.users[data.nickname].invalidAttempts[ip] = 1;
						}
					}
					
					
					socket.emit('validateUser', status );
				}},

	authenticateRegister : {queue : false,
				callback:function(data,socket){
					var nickname = data.nickname;
					var password = data.password;
					var email    = data.email;
				}},

	authenticateGuest : {queue : false,
				callback:function(data,socket){
					//Receive nothing.
				}},

};