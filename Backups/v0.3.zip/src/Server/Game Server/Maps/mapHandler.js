/*== Map Handler Module ==*/

//Status: 0 
//Load maps.



//Imports
var log        = require('../../Utility/Logger').makeInstance("MapHandler");
var data       = require('../Data');
var fm         = require('../../Utility/FileManager');
var settings   = require('./Settings');
var mapBuilder = require('./MapBuilder');


//Module logging
log.enabled = true;
log.level   = 3;


var status = "not initialized";


exports.init = function (callback) {
	//Guards
	if(status == "initialized" || status == "initializing") {
		log.warn('Already initialized or initializing.');
		return;
	}
	if(!(typeof callback === 'function')) {
		log.warn('No callback given to init.');
		return;
	}


	log.debug('Initializing...');
	status = "initializing";

	locks = {};

	//Load Maps
	for(var index in settings.maps) {
		log.debug('Loading ' + settings.maps[index]);
		locks[index] = { status : "locked" };
		loadMap(index,locks[index]);
	}

	setTimeout(function checkIfDone() {
		
		var total = 0;
		var unlocked = 0;
		for(var i in locks) {
			total++;
			if(locks[i].status == "unlocked") {
				unlocked++;
			}
		}	

		if(unlocked == total) {
			status = "initialized";
			callback();
			log.info('Loaded all maps!');
		} else {
			SetTimeout(checkIfDone,1500);
		}
	},1500);

};


function loadMap(index,lock) {
	var path = '/../Game Server/Maps/Map Data/' + settings.maps[index] + '.json';
	fm.fetchFile(path,function(err,file) {
		if(err) {
			log.error('Can\'t fetch file ' + settings.maps[index] + '.json');
			lock.status = "unlocked";
		} else {
			var map = mapBuilder.create(settings.maps[index],file);	
			data.maps[map.name] = map;
			lock.status = "unlocked";
			
		}
	});
}

