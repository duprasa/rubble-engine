//Imports
var settings = require('./settings');
var logger   = require('../../Utility/Logger');

exports.create = function(mapName,mapFile) {
	var mapStructure = JSON.parse(mapFile);
	return new Map(mapName,mapStructure);
};

function Map (name,mapStructure) {

	//Object logging
	this.log  = logger.makeInstance('Map Object ' + name);
	this.log.level = 3;
	this.log.enabled = true;

	//Object properties
	this.name     = (name || settings.defaultMapName);
	this.width    = mapStructure.width; // in Tiles
	this.height   = mapStructure.height; // in Tiles
	this.tileSize = (mapStructure.tileheight || settings.defaultTileSize);

	this.realWidth  = this.width * this.tileSize;
	this.realHeight = this.height * this.tileSize; 

	this.sectors = [];
	this.sectorSize = settings.sectorSize; // in Tiles


	//Find out how many sectors our map will contain
	this.sectorsWide = Math.ceil(this.width / this.sectorSize);
	this.sectorsLong = Math.ceil(this.height/ this.sectorSize);
	this.sectorCount = this.sectorsWide * this.sectorsLong;

	//create a the sectors as well as a tile array in each one.
	for(var b = 0; b < this.sectorCount; b++) {
		var sectorRow = Math.floor(b / this.sectorsWide);
		var sectorCol = Math.floor(b % this.sectorsWide);
		
		
		this.sectors[b] = {
			index : b,
			x     : (sectorCol * this.sectorSize * this.tileSize),
			y     : (sectorRow * this.sectorSize * this.tileSize),
			tiles : [],
			entities : {
				walls    : [],
				monsters : [],
				players  : [],
				items    : [],
				portals  : [],
				attacks  : [],
				others   : [],
			}
		};
		

		for(var t = 0; t < (this.sectorSize * this.sectorSize); t++) {
			var tileRow = Math.floor(t / this.sectorSize);
			var tileCol = Math.floor(t % this.sectorSize);
			
			
			this.sectors[b].tiles[t] = {
				x        : this.sectors[b].x + (tileCol * this.tileSize),
				y        : this.sectors[b].y + (tileRow * this.tileSize),
				graphic : settings.defaultGraphic,
				danger   : settings.defaultDanger,
				spawn   : settings.spawnType[settings.defaultSpawn]
			};
		}
	} 

	//Fill tiles in sectors with data from map file.
	for(var i = 0; i < mapStructure.layers.length;i++) {

		for(var l = 0; l < mapStructure.layers[0].data.length;l++) {
			var row     = Math.floor(l / this.width);
			var col     = l % this.width;
			var sectorY = Math.floor( row / this.sectorSize);
			var sectorX = Math.floor( col / this.sectorSize);

			var sectorIndex = (sectorY * this.sectorsWide) + sectorX;
			var tileIndex   = l - (row * this.width) - (sectorX * this.sectorSize) + (this.sectorSize * (row - (sectorY * this.sectorSize)));
			
			if(mapStructure.layers[i].name == "physics" && mapStructure.layers[i].data[l] != 1) {
				this.sectors[sectorIndex].entities.walls.push({
					x     : this.sectors[sectorIndex].tiles[tileIndex].x,
					y     : this.sectors[sectorIndex].tiles[tileIndex].y,
					width : this.tileSize,
					height: this.tileSize,
					type  : settings.physicsType[mapStructure.layers[i].data[l]]
 				});
			} else {
				switch(mapStructure.layers[i].name) {
					case "graphic":
					case "danger" :
						this.sectors[sectorIndex].tiles[tileIndex][mapStructure.layers[i].name] = mapStructure.layers[i].data[l];
					break;
					case "spawn":
						this.sectors[sectorIndex].tiles[tileIndex].spawn = settings.spawnType[mapStructure.layers[i].data[l]];
					break;
					default:
					break;
				}

			}
		}

	} 


	// this.getTileByPosition   = function(x,y) {
	// 	var tileX = Math.floor(x / this.tileSize);
	// 	var tileY = Math.floor(y / this.tileSize);

	// 	return tiles[(tileY * this.width) + tileX];
	// };


	this.getSectorByPosition = function(x,y) {
		if(x >= 0 && x < this.realWidth && y >= 0 && y < this.realHeight) {
			return this.getSector(Math.floor(x / (this.tileSize *this.sectorSize)),Math.floor( y /(this.sectorSize * this.tileSize)));
		} else {
			this.log.warn('Can\'t find sector with position (' + x + ', ' + y + ')');
			return;
		}
	};


	this.getSector = function(x,y) {
		if(x >= 0 && x < this.sectorsWide && y >= 0 && y < this.sectorsLong) {
			return (this.sectors[(y * this.sectorsWide) + x]);
		} else {
			this.log.warn('Sector (' + x + ', ' + y + ') is invalid.');
			return;
		}
	};
}

