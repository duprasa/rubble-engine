
module.exports = {
	maps: [
		'test'
	],
	//Dimensions of sectors in tiles.
	sectorSize : 10,
	defaultTileSize : 32,
	defaultMapName  : "Unnamed",
	//Defaults for tile settings.
	defaultGraphic : 0,
	defaultDanger  : 0,
	defaultSpawn   : 1,
	
	//type definition.
	physicsType : {
		"2" : "SOLID_WALL",
		"3" : "HALF_WALL"
	},

	spawnType   : {
		"1" : "SPAWN_NOTHING",
		"2" : "SPAWN_MONSTER",
		"3" : "SPAWN_PLAYER" ,
		"4" : "SPAWN_ITEM"   
	}
};