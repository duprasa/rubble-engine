/*== Physics Module ==*/

//Status: -1 (Empty as fuck)
//This module checks for collisions and adds them to a queue,
//it is also in charge of updating locations of players and monsters
//using their nextLocation property, this module returns the list of collisions.



//Imports
var settings = require("../../Settings").gameServer;
var data     = require("../Data");
var log      = require('../../Utility/Logger').makeInstance("Physics");


//Module logging
log.enabled = true;
log.level   = 3;


exports.update = function() {

	if(settings.moduleEnabled["Physics"] == false) {
		return null;
	}

	//Empty
	return collisions;
};

