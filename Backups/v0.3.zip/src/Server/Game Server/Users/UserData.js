//This needs to be initialized at the beginning of the server,
//it will be loaded from the database.
var settings = require('../../Settings');


module.exports = {
	users : {
		"nick" : { password : "banana" , email : "chocomilkplz@gmail.com",invalidAttempts : {} },
		"sam"  : { password : "banana2", email : "sam.dupras@gmail.com",invalidAttempts : {}},
	},
	
};



setInterval(function() {
	for(var i in module.exports.users) {
		module.exports.users[i].invalidAttempts = {};
	}
},settings.invalidAttemptsTimeout * 1000);