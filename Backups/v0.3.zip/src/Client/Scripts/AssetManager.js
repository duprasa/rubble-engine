//WARNING asset manager does not catch bad audio files!!!!!!!
//this needs to be implemented in the future
//WARNING if theres blocking code(alert) in javascript files the asset manager wont think that the file is loaded
"use strict";
function AssetManager(){
	var rh = new RequestHandler();
	this.load = function(paths,callback){
		var nbFiles = (Array.isArray(paths))? paths.length: 1;
		var nbFilesLoaded = 0;
		var files = {};

		if(Array.isArray(paths)){
			for (var i = 0; i < nbFiles; i+=1) {
				var path = paths[i];
				loadFile(path);
			}
		}else{
			//console.log('asset manager called without an array!');
			loadFile(paths);
		}

		function addFile(path,file){
			nbFilesLoaded += 1;
			files[path] = file;
			if(nbFiles === nbFilesLoaded){
				console.log('all files loaded!')
				if(typeof(callback) === 'function'){
					if(Array.isArray(paths)){
						callback(files);
					}else{
						callback(file);
					}
				}
			}
		}
		function loadFile(path){
			var extension = path.split('.')[path.split('.').length - 1];
			switch(extension){
				case 'js':
				 	var script = document.createElement('script');
				 	script.type = "text/javascript";
				 	script.src= path;
				 	script.onerror = function(){
				 		//show error
				 		console.log('error loading ' + path );
				 		addFile(path,null);
				 	};
				 	script.onload = function(){
						console.log('script' + path + ' has loaded');
						addFile(path,true);
				 	};
				 	document.head.appendChild(script);
					break;
				case 'ico': case 'png': case 'jpg': case 'gif':
					var image = document.createElement('img');
					image.onload = function(){
						console.log('image' + path + ' has loaded');
						addFile(path,image);
					};
					image.onerror = function(){
						console.log('error loading ' + path);
						addFile(path,null);
					};
					image.src = path;
					break;
				case 'html': case 'css': case 'json':
					rh.sendRequest(path,
								   function(XHR){
										console.log(extension + " " + path + ' has loaded');
									    addFile(path,XHR.responseText);
								   },
								   function(){
										console.log('error loading ' + path);
									    addFile(path,null);
								   });
					break;
				case 'sound':
					var fileName = path.split('.')[0];
					var audio = new Audio();
					var nbPlayable = 0;
					var playable = false;
					var hasError = false;

					//Attach event to know when file can be played.
					if(audio.addEventListener){
						audio.addEventListener('canplaythrough',
												function() {
													console.log(path +' has loaded successfully');
													playable = true;
													addFile(path,audio);
												});
						audio.addEventListener('error',
												function(){
													console.log('onerror called for file');
													if(playable){return;}
													if(hasError){return;}
													hasError = true;
													addFile(path,null);
												});
					}else{
						audio.attachEvent('oncanplaythrough',
												function() {
													console.log(path +' has loaded successfully');
													playable = true;
													addFile(path,audio);
												});
						audio.attachEvent('onerror',
												function(){
													console.log('onerror called for file');
													if(playable){return;}
													if(hasError){return;}
													hasError = true;
													addFile(path,null);
												});
					}

					//Check what file type browser can play
					if(audio.canPlayType("audio/ogg") !== "") {
						nbPlayable += 1;
						var source = document.createElement('source');
						source.type = "audio/ogg";
						source.src = fileName + '.ogg';
						audio.appendChild(source);
						console.log('requesting ' + fileName + '.ogg');
					}  

					if(audio.canPlayType("audio/wav") !== "") {
						nbPlayable += 1;
						var source = document.createElement('source');
						source.type = "audio/wav";
						source.src = fileName + '.wav';
						audio.appendChild(source);
						console.log('requesting ' + fileName + '.wav');
					}

					if(audio.canPlayType("audio/mpeg") !== "") {
						nbPlayable += 1;
						var source = document.createElement('source');
						source.type = "audio/mpeg";
						source.src = fileName + '.mp3';
						audio.appendChild(source);
						console.log('requesting ' + fileName + '.mp3');
					}
					if(nbPlayable === 0){
						console.log('no plabale formats for this browser');
						addFile(path,null);
					}
					break;
				default:
					console.log('AssetManager: uncaught file type: ' + extension);

			}
		}
	};

}