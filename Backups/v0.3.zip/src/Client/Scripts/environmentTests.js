'use strict';
function testBrowser(){
	if(typeof(Audio) === 'undefined') {
		return false;
	}
	if(!Audio.prototype.canPlayType) {
		return false;
	}
	return true;
}