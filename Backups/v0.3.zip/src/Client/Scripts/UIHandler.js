//THIS WAS TAKEN FROM http://tech.pro/tutorial/725/javascript-tutorial-simple-fade-animation
"use strict";
function UIHandler(){
	var am = new AssetManager();
	var inTransition = false;
	this.goToGame = function(){
		var fadeComplete = false
		var file = null;
		if(inTransition){
			//wait till transition is over
			//console.log('currently in transition');
			return;
		}
		inTransition = true;
		am.load('/game.html',function(afile){
			//console.log('file loaded!');
			file = afile;
			showNewContent(file);
		});
		fade('contents',300,function(){
			//console.log('fadeComplete');
			fadeComplete = true;
			showNewContent(file);
		});
		function showNewContent(){
			if(fadeComplete && file){
				//console.log('loaded new content');
				document.getElementById('contents').innerHTML = 'hello!!';
				fade('contents',300,function(){
					//console.log('fade out complete');
					inTransition = false;});
			}
		}
	}
	this.changeMenu = function(menuId){
		var fadeComplete = false
		var file = null;
		if(inTransition){
			//wait till transition is over
			//console.log('currently in transition');
			return;
		}
		inTransition = true;
		am.load('/' + menuId + '.html',function(afile){
			//console.log('file loaded!');
			file = afile;
			showNewContent(file);
		});
		fade('center-container',300,function(){
			//console.log('fadeComplete');
			fadeComplete = true;
			showNewContent(file);
		});
		function showNewContent(){
			if(fadeComplete && file){
				//console.log('loaded new content');
				document.getElementById('center-container').innerHTML = file;
				fade('center-container',300,function(){
					//console.log('fade out complete');
					inTransition = false;});
			}
		}
	}

	function fade(eid,duration,callback){

	  	var domElement = document.getElementById(eid);
	  	if(domElement == null){
	    	return;
		}

	  	if(domElement.fadeState == null)
	  	{
	    	if(domElement.style.opacity == null 
	    	    || domElement.style.opacity == '' 
	    	    || domElement.style.opacity == '1'){

	    	  	domElement.fadeState = 2;

	    	}else{

	      		domElement.fadeState = -2;
	    	}
	  	}

	  	if(domElement.fadeState == 1 || domElement.fadeState == -1){

	    	domElement.fadeState = domElement.fadeState == 1 ? -1 : 1;
	    	domElement.fadeTimeLeft = duration - domElement.fadeTimeLeft;

	  	}else{

	    	domElement.fadeState = domElement.fadeState == 2 ? -1 : 1;
	    	domElement.fadeTimeLeft = duration;
	    	setTimeout(animateFade(new Date().getTime()), 33);

	  	}  
		function animateFade(lastTick){  

		  	var curTick = new Date().getTime();
		  	var elapsedTicks = curTick - lastTick;
		 
		  	if(domElement.fadeTimeLeft <= elapsedTicks){

		    	domElement.style.opacity = domElement.fadeState == 1 ? '1' : '0';
		    	domElement.style.filter = 'alpha(opacity = ' + (domElement.fadeState == 1 ? '100' : '0') + ')';
		    	domElement.fadeState = domElement.fadeState == 1 ? 2 : -2;
		    	if(typeof(callback) === 'function'){
		    		callback();
		    	}
		    	return;
		  	}
		 
		  	domElement.fadeTimeLeft -= elapsedTicks;
		  	var newOpVal = domElement.fadeTimeLeft/duration;
		  	if(domElement.fadeState == 1){
		    	newOpVal = 1 - newOpVal;
		    }

		  	domElement.style.opacity = newOpVal;
		  	domElement.style.filter = 'alpha(opacity = ' + (newOpVal*100) + ')';
		  
		    setTimeout(function(){animateFade(curTick,eid)}, 33);

		}
	}
}