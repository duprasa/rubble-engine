'use strict';
var uh = new UIHandler();
var gameAssetsReady = false;
var userReady = false;
var socket = null;

//function for all button events
function buttonClick(buttonId){
	switch(buttonId){
		case 'mainMenu': case 'help': case 'register': case 'login': case 'credit':
			uh.changeMenu(buttonId);
			break;
		case 'play':
			//authenticate user
			console.log('authenticating Guest');
			socket.emit('authenticateGuest',{});

			uh.changeMenu('loading');

			socket.on('validateGuest',function(isValid){
				if(isValid){
					//attempt to play game
					if(gameAssetsReady){
						uh.goToGame();
					}else{
						userReady = true;
						uh.changeMenu('loading');
					}	
				}else{
					//go to authentication error page
					uh.changeMenu('authenticationError');
				}
			});
			break;
		case 'login-play':
			//authenticate user
			var nickname = document.getElementById('nickname').value;
			var password = document.getElementById('password').value;
			console.log('authenticating user');
			//uh.changeMenu('loading');
			socket.emit('authenticateUser',{nickname:nickname,
											 password:password});

			socket.on('validateUser',function(status){
				switch(status) {
				case "VALID":
					console.log('username and password are valid');
					//attempt to play game
					if(gameAssetsReady){
						console.log('user is valid and assets are ready');
						uh.goToGame();
					}else{
						console.log('user is valid and assets arent ready');
						userReady = true;
						uh.changeMenu('loading');
					}	
					break;
				case "NOT_VALID":
				case "TOO_MANY_ATTEMPTS":
					console.log('username and password are invalid');
					//go to authentication error page
					uh.changeMenu('error');
					break;
				}
			});
			break; 
		case'register-play':
			//authenticate user
			console.log('authenticating registration');
			socket.emit('authenticateRegister',{nickname:document.getElementById('nickname').value,
											 	 password:document.getElementById('password').value,
											 	 email:document.getElementById('email').value});

			uh.changeMenu('loading');

			socket.on('validateRegister',function(isValid){
				if(isValid){
					//attempt to play game
					if(gameAssetsReady){
						uh.goToGame();
					}else{
						userReady = true;
						uh.changeMenu('loading');
					}	
				}else{
					//go to authentication error page
					uh.changeMenu('authenticationError');
				}
			});
			break;
		default:
			console.log('unhandled buttonClick ' + buttonId);
			break;
	}
}
window.onload = function(){
	var am = new AssetManager();
	//test browser
	if(!testBrowser()){
		uh.changeMenu('incompatible');
		return;
	}
	//test socketIO
	am.load("http://localhost:81/socket.io/socket.io.js",function(asset){
		if(asset){
			socket = io.connect('http://localhost:81');
			uh.changeMenu('mainMenu');
			//load game assets
			loadGameAssets();
		}else{
			uh.changeMenu('error');
		}
	});

	function loadGameAssets(){
		//put all game assets to load here
		am.load(['/game.html'],function(assets){
			var hasError = false;
			for(var path in assets){
				if(assets[path] === null){
					hasError = true;
					break;
				}
			}
			if(!hasError){
				gameAssetsReady = true;
				console.log('game assets ready');
				if(userReady){
					uh.goToGame();
				}
			}else{
				console.log('error loading game files');
			}
		});
	}

};