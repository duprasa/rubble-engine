"use strict";
window.addEventListener('load',function(){

    //set up the canvas 
    var socket = io.connect('http://localhost:81');
    var canvas = document.getElementById('theGame');
    var screen = new Screen(canvas,700,700);
    var inputHandler = new InputHandler(canvas);

    var onlinePlayers = {};
    var entities = [];
    for(var i = 1; i < 10;i++){
        for(var j = 1; j < 10;j++){
            var wall = new Wall(i * 100, j * 100,50,50);
            entities.push(wall);
        }
    }

    socket.on('socketId',function(socketId){

        var player = new Player(1,1,20,20,'#BADA55',socketId);
        screen.follow(player.location);
        entities.push(player);
        socket.emit('newPlayer',player.location);
        //networking stuff
        socket.on('newPlayerLocations',function(players){
            //change all online player locations
            for(var playerId in players){
                if(playerId !== player.playerName){
                    if(playerId in onlinePlayers){
                        onlinePlayers[playerId].location.x = players[playerId].x;
                        onlinePlayers[playerId].location.y = players[playerId].y;
                    }else{
                        var aPlayer = new OnlinePlayer(players[playerId].x,players[playerId].y,20,20,'#BADA55',playerId)
                        onlinePlayers[playerId] = aPlayer;
                        entities.push(aPlayer);
                    }
                }
            }

        });
        socket.on('playerJoined',function(idLocation){
            //add a player to the online players
            console.log(idLocation);
            var id = idLocation.id;
            var location = idLocation.location;
            var player = new OnlinePlayer(location.x,location.y,20,20,'#BADA55',id)
            onlinePlayers[id] = player;
            entities.push(player);
        });
        socket.on('playerLeft',function(id){
            //detele player from the online players
            for (var i = 0; i < entities.length; i++) {
                if(entities[i] === onlinePlayers[id]){
                    entities.splice(i,1);
                    break;
                }
            };
            delete onlinePlayers[id];
        });

        //game loop
        (function gameLoop(){

            //SERVER: tell server player location
            socket.emit('playerMove',{x:player.location.x,y:player.location.y});

            //perform actions on entities
            for(var index in entities){
                entities[index].doActions(inputHandler.isPressed);
                entities[index].move();
            }

            //draw when frame is ready
            requestAnimFrame(function(){
                //do drawing on screen
                for(var index in entities){
                    entities[index].animate(screen);
                }
                screen.drawBackground();
                screen.paint();
            });
            //this must be at 64 or more or anim frame laggs
            setTimeout(gameLoop,(1000/64));
        })();

        //add events
        inputHandler.onKeyDown(function(e,isPressed){
            //these events should execute in the game loop
            if(e.keyCode == 90){
                player.boost(isPressed);
            }
            if(e.keyCode == 32){
                var box = new Box(player.location.x - (30/2), player.location.y - (12/2),12,30);
                console.log(Math.tan(player.rotation))
                box.velocity.x = 10 * Math.cos(player.rotation - Math.PI/2);
                box.velocity.y = 10 * Math.sin(player.rotation- Math.PI/2);
                box.rotation = player.rotation;
                entities.push(box);
                console.log(entities.length);
            }
        });
    });



});