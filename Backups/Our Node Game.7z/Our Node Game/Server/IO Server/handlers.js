/*== IO Handlers Module ==*/

//Status: 2.5 (deprecated, sam has newer version)
//This module defines what we do with requests after they
//have been routed here, hence handlers



//Imports
var log = require('../Utility/Logger').makeInstance();


//Module logging.
log.enabled = true;
log.level   = 3;


exports.handlers = {
	test:function(data,socket){
		log.debug(data);
		socket.emit('test',socket.id + 'hello to you to');
	},
	disconnect:function(data,socket,socketIO){
		log.debug('disconnect');
		var address = socket.handshake.address;
	    var date = new Date();
		log.debug('User has disconnected : '+ address.address + ":" + address.port + " Time: " + date.toJSON())
		//need reference to socket io to show number of users
		log.debug('number of connected users:' + (Object.keys(socketIO.connected).length - 1));
		socket.broadcast.emit('playerLeft',socket.id);
	 }
};