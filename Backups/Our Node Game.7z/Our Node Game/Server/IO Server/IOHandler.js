/*== IO Handler Module ==*/

//Status: 2.5 (deprecated, sam has newer version)
//This module deals with the IO Server. It is the root
//of the IO server and point of access for other modules.
//It defines what we do when we receive a SocketIO request and
//routes it appropriately. It might put certain messages received
//in a queue for other modules to loop through them when needed 
//ex: The Game Server Module



//Imports
var log    = require('../Utility/Logger').makeInstance();
var router = require('./router.js');


//Module logging
log.enabled = true;
log.level   = 3;


var socketIO = null;
var initialized = false;


exports.init = function(inSocketIO){
	initialized = true;
	socketIO = inSocketIO;
	log.debug('IO server initialized!');

};
exports.start = function(){
	if(!initialized){
		return;
	}
	router.route(socketIO);

};
exports.getSocketIO = function(){
	if(!initialized){
		return;
	}
	return socketIO;
};
exports.sendMessage = function(Data){
	if(!initialized){
		return;
	}

};
exports.showQueue = function(){
	log.debug(router.socketQueue);
}