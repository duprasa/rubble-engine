/*== IO Router Module ==*/

//Status: 2.5 (deprecated, sam has newer version)
//This module routes SocketIO requests to the appropriate 
//handlers



//Imports
var handles = require('./handlers').handlers;
var log     = require('../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 3;


var socketQueue = [];


exports.route = function(socketIO){

	socketIO.sockets.on('connection',function(socket){
	    var address = socket.handshake.address;
	    var date = new Date();
	    log.debug("User has connected: " + address.address + ":" + address.port + " Time: " + date.toJSON());
	    log.debug('number of connected users:' + Object.keys(socketIO.connected).length);
	    //create a new socket event for every handle
	    for(var handleName in handles){
	    	createSocketListener(handleName);
	    }
	    //this function is required to keep a reference to each handleName
	    function createSocketListener(handleName){
	    	//function is wraped to have a reference to socket and socketIO
	  		socket.on(handleName,function(data){
	  			var socketData = {
	  				socketId: socket.id,
	  				handleName: handleName,
	  				data:data
	  			};
	  			socketQueue.push(socketData);
	  			handles[handleName](data,socket,socketIO);
	  		});
	  	}
	});

};
exports.socketQueue = socketQueue;