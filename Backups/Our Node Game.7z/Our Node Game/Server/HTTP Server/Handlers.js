/*== Http Handlers Module ==*/

//Status: 4 (stable)
//This module defines what we do with requests after they
//have been routed here, hence handlers



//Imports
var querystring = require("querystring");
var fs 			= require("fs");
var swig 		= require("swig");
var templates   = require("./Templates").templates;
var settings    = require("../Settings").settings;
var log         = require('../Utility/Logger').makeInstance();
var fileManager	= require('../Utility/FileManager');


//Module logging
log.enabled = true;
log.level   = 3;


//Page Request Handlers
exports.handles = {
	notFound:function(response) {
		sendResponse(response,"<p> 404. Page not found. </p>",404,"text/html");
	},

	'/':function(response,postData) {
		log.debug("Request handler 'client' was called.");
		var template = templates.client;
		var content = template.render({
			domain : settings.domain,
			port : settings.port
		});
		sendResponse(response,content,200,"text/html");
	},
	//File Request Handlers 
	json:function(response,filename){
		log.debug("Request handler 'json' was called.");
		sendFile(response,'json/' + filename,"application/json")
	},
	scripts:function(response,filename) {
		log.debug("Request handler 'scripts' was called.");
		sendFile(response,'Scripts/'+ filename,"text/javascript")
	},

	images:function(response,filename) {
		log.debug("Request handler 'images' was called.");
		var extension = filename.substring(filename.indexOf(".") + 1);
		sendFile(response,'Images/'+ filename,"image/" + extension);
	},

	sounds:function(response,filename) {
		log.debug("Request handler 'sounds' was called.");
		var extension = filename.substring(filename.indexOf(".") + 1);
		sendFile(response,'Sounds/'+ filename,"audio/" + extension);
	},


	styles:function(response,filename) {
		log.debug("Request handler 'styles' was called.");
		sendFile(response,'Styles/'+ filename,"text/css");
	}
};

//Helper functions

function sendResponse(response,file,responseCode,contentType){
	response.writeHead(responseCode, {"Content-Type": contentType});
	response.write(file);
	response.end();
}
function sendFile(response,path,contentType){
	fileManager.fetchFile("/../../Client/" + path,function(error,file){
		if(error) {
			log.warn('error reading ' + contentType + ' file.');
			sendResponse(response,contentType +" file not found",404,"text/html");
		}
		else {
			sendResponse(response,file,200,contentType);
		}
	});
}
