/*== Server Module ==*/

//Status: 4 (stable)
//This module creates and starts the all three servers.
//It is only run once every time the server is restarted.



//Imports
var http        = require('http');
var socketIO    = require('socket.io');
var settings    = require('./Settings').settings;
var httpHandler = require('./HTTP Server/HTTPHandler');
var ioHandler   = require('./IO Server/IOHandler');
var gameHandler = require('./Game Server/GameHandler');
var log         = require('./Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 3;


exports.start = function(){
	
	//start the servers
	var HttpServer = http.createServer(httpHandler.onRequest);
	var IOServer   = socketIO.listen(HttpServer);  
	HttpServer.listen(settings.port);

	log.info('Server starting on port: ' + settings.port);

	//set some defaults to socketIO
	IOServer.set('close timeout'	  , settings.closeTimeout);
	IOServer.set('heartbeat timeout'  , settings.heartbeatTimeout);
	IOServer.set('polling duration'	  , settings.pollingDuration);
	IOServer.set('heartbeat interval' , settings.heartbeatInterval);
	IOServer.set('log level'		  , settings.logLevel);
	
	//start http handler
	httpHandler.init();
	//start the io handler
	ioHandler.init(IOServer);
	ioHandler.start();
	//start the game handler
	gameHandler.init();
	gameHandler.start();

};