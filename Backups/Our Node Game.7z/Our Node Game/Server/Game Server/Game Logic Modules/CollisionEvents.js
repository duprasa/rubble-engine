/*== Collision Events module ==*/

//Status: -1 (Empty as fuck)
//This module says what things do when they collide with each other.
//It uses the collision list obtained from the physics module.



//Imports
var rules    = require("../BusinessRules");
var settings = require("../Settings");
var data     = require("../Data");
var log      = require('../../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 3;


exports.update = function(collisions) {
	if(settings.moduleEnabled["CollisionEvents"] == false || (collisions == null))  {
		return;
	}

	//Empty
};

