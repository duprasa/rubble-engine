/*== Game Loop Module ==*/

//Status: 1 (needs to be implemented AND defined)
//This module decides when to use other modules to validate gameData
//or alter the game, it is the heart of the game server and decides what
//the game actually does.



//Imports
var settings = require("./Settings");
var log      = require('../Utility/Logger').makeInstance();
var physics         = require("./Game Logic Modules/Physics");
var collisionEvents = require("./Game Logic Modules/CollisionEvents");
var monsterSpawner  = require("./Game Logic Modules/MonsterSpawner");
var clientUpdates   = require("./Game IO Modules/ClientUpdates");
var clientEvents    = require("./Game IO Modules/ClientEvents");
 

//Module logging
log.enabled = true;
log.level   = 4;


exports.start = function() {
	
	if(settings.moduleEnabled["Loop"] == false) {
		return;
	}

	loop();
	log.debug('Main game loop started.');
	var now; 
	
	function loop() {
		now = new Date();

		//clientEvents
		var collisions = physics.update();
		collisionEvents.update(collisions);
		monsterSpawner.update();
		clientUpdates.update();
		

		if((new Date() - now) > (1000 / settings.FPS)) {
			log.warn("Server Game loop running slow.");
		}

		//Go through some more logic modules.
		setTimeout(loop,1000/ settings.FPS);
	};

};

