/*== Game Server Module ==*/

//Status: 2 (needs additions/editing)
//This is the root of the game, it launches the main gameloop.



//Imports
var gameLoop = require("./Loop");
var settings = require("./Settings");
var database = require("./Database");
var log      = require('../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 3;


var initialized = false;


exports.init = function(){
	initialized = true;
	log.debug('game server initialized!');
};

//Game Server start
exports.start = function() {
	log.debug('game server started!');

	if(!(settings.moduleEnabled["GameHandler"] && initialized)) {
		return;
	}

	settings.listGameModules();

	database.load();
	gameLoop.start();

};
