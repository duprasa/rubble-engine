/*== Client Events Module ==*/

//Status: -1 (Empty as fuck)
//This module is in charge of either receiving messages 
//from SocketIO server or a queue of messages and keeping
//them here until the Loop module takes care of them.



//Imports
var settings     = require("../Settings");
var data         = require("../Data");
var socketServer = require("../../IO Server/IOHandler").getSocketIO();
var log          = require('../../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;


