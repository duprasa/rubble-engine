/*== Game Server Settings Module ==*/

//Status: 2 (Needs additions/editing)
//The server settings module takes care of settings regarding modules,
//Ex: Enabling modules, disabling modules, adding modules,
//or any settings that have to do with the game server. it does NOT
//take care of any game logic rules or settings.



//Imports
var log = require('../Utility/Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 3;


exports.moduleEnabled = {
	"GameHandler" : true,
	"Loop" : true,
	"Database" : true,
	"ClientUpdates" : false,
	"ClientEvents" : false,
	"Physics" : false,
	"CollisionEvents" : false,
	"MonsterSpawner" : true
};

exports.FPS = 60;

exports.listGameModules = function() {
	var count = 0;
	var totalCount = 0;
	for(var i in exports.moduleEnabled) {
		totalCount++;
		if(exports.moduleEnabled[i] == true) {
			log.debug(i + " module is enabled.");
			count++;
		}
	}
	log.info("total game modules: " + count + " out of " + totalCount);
};

