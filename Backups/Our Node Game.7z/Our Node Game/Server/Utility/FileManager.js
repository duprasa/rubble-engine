/*== File Manager Module ==*/

//Status: 3 (not sure)
//This module manages loading and removing files 
//from memory.



//Imports
var fs 	= require("fs");
var log = require('./Logger').makeInstance();


//Module logging
log.enabled = true;
log.level   = 3;


var files = {};
//fetch a file and return more efficient way.
exports.fetchFile = function(path,callback){
	//check if file is in memory
	if(!files[path]){
		//check if callback is valid
		if(typeof callback === 'function'){
			log.debug('fetching file: ' + path);
			//read the file
			fs.readFile( __dirname + path , function(error,file) {
				//file is invalid
				if(error) {
					//call callback with error
					callback(error,null);
				}
				//file is valid
				else {
					files[path] = file;
					//call callback with no error
					callback(null,file);
				}
			});
		}else{
			log.warn('File:' + path +' not loaded yet');
			//return false for user not using callback
			return false;
		}
	}else{
		log.debug('file in memory: ' + path);
		//call callbakc with in memory file
		callback(null,files[path]);
		//return file for user not using callback
		return files[path];
	}
};

//fetch a file weather or not it already is in memory
exports.fetchNewFile = function(path,callback){
	//check if callback is valid
	if(typeof callback === 'function'){
		log.debug('fetching file: ' + path);
		//read the file
		fs.readFile( __dirname + path , function(error,file) {
			//file is invalid
			if(error) {
				//call callback with error
				callback(error,null);
			}
			//file is valid
			else {
				files[path] = file;
				//call callback with no error
				callback(null,file);
			}
		});
	}else{
		log.warn('fetchNewFile called without a callback');
		//return false for user not using callback
		return false;
	}
};
//store a file for future use
exports.storeFile = function(path){
	fs.readFile( __dirname + path , function(error,file) {
		//file is invalid
		if(error) {
			//call callback with error
			log.warn('FILE NOT FOUND: ' + error.message);
		}
		//file is valid
		else {
			files[path] = file;
			log.debug('file: '+ path +' is ready');
		}
	});
};
exports.removeFile = function(path){
	if(files[path]){
		delete files[path];
		return true;
	}else{
		return false;
	}
};