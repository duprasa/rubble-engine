/*== Logger Module ==*/

//Status: 4 (Stable)
//Logger module simply logs info, warnings or debug info
//depending on server settings.



//Imports
var settings = require("../Settings").settings;


//module variables
var red      = '\033[31m';
var crazyRed = '\033[41m';
var green    = '\033[36m';
var beige    = '\033[33m';
var reset    =  '\033[0m';


exports.makeInstance = function () {
	return new Logger();
};


//Logger Constructor
function Logger() {
	this.enabled = settings.loggingEnabled;
	this.level = settings.defaultLogLevel;
};


//Logger functions
Logger.prototype.file  = function(message) {
	if(this.enabled == false) {
		return;
	}

	if(this.level >= 0) {
		//Write to file.
	}
};


Logger.prototype.error = function(message) {

	if(this.enabled == false) {
		return;
	}

	if(this.level >= 1) {
		console.log( crazyRed + message + reset );
		//TODO: Should end app here in an organized manner
	}

};


Logger.prototype.warn = function(message) {
	if(this.enabled == false) {
		return;
	}

	if(this.level >= 2) {
		console.log(red + message + reset);
	}
};


Logger.prototype.info = function(message) {

	if(this.enabled == false) {
		return;
	}

	if(this.level >= 3) {
		console.log(green + message + reset);
	}

};


Logger.prototype.debug = function(message) {

	if(this.enabled == false) {
		return;
	}

	if(this.level >= 4) {
		console.log( beige + message + reset );
	}

};

