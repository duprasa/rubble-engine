window.onload = function() {
	var socket = io.connect();
	var button = document.createElement('button');
	document.body.appendChild(button);
	button.onclick = function(){
		socket.emit('test','test');
	};
	socket.on('test',function(Data){
		console.log(Data);
	});
};
