/*== Client Events Module ==*/

//Status: -1 (Empty as fuck)
//This module is in charge of either receiving messages 
//from SocketIO server or a queue of messages and keeping
//them here until the Loop module takes care of them.



//Imports
var settings = require("../../Settings").gameServer;
var data         = require("../Data");
var userData         = require("../Users/UserData");
var ioServer = require("../../IO Server/IOHandler");
var abilityBuilder = require("../Builders/AbilityBuilder");
var log          = require('../../Utility/Logger').makeInstance("Client Events");


//Module logging
log.enabled = true;
log.level = 3;


exports.update = function() {
	if(settings.moduleEnabled["ClientEvents"] == false) {
		return;
	}
	log.debug('+++++++ UPDATING ++++++');
	var queue = ioServer.queue;
	var connection = queue["connection"];
	var newPlayers = queue["newPlayer"];
	var userUpdate = queue["userUpdate"];
	var disconnect = queue["disconnect"];
	var logOut = queue["logOut"];

	// CONNECTION

	for (var i = 0; i < connection.length; i++) {
		var socket = connection[i].socket;
		log.debug("user: " + socket.id + " has connected");
	};
	queue["connection"] = [];



	//NEW PLAYER

	// for (var i = 0; i < newPlayers.length; i++) {
	// 	var socket = newPlayers[i].socket;
	// 	data.players[socket.id] = {};
	// 	log.debug("user: " + socket.id + " has sent new player data");
	// 	var socketData = newPlayers[i].data;
	// 	data.players[socket.nickname].x = socketData.x;
	// 	data.players[socket.nickname].y = socketData.y;
	// 	data.players[socket.nickname].rotation = socketData.rotation;
	// 	socket.broadcast.emit('playerJoined',{nickname:nickname, location:{x:socketData.x,y:socketData.y},rotation:socketData.rotation});
	// };
	// queue["newPlayer"] = [];





	// USER UPDATE

	for (var i = 0; i < userUpdate.length; i++) {
		var socket = userUpdate[i].socket;
		log.debug("user: " + socket.id + " has moved ");
		var socketData = userUpdate[i].data;
		var player = socketData.player;
		var realPlayer = data.players[socket.nickname]
		if(!realPlayer) { break; }
		//new player location and rotation
		if(!realPlayer.teleported) {
			realPlayer.x = player.x; // should be next x
			realPlayer.y = player.y; //should be next y
		}
		realPlayer.rotation = player.rotation;
		//item data
		var tempItem;

		for(var d in socketData.abilitiesUsed) {
			//Check if general cooldown is 0
			if(realPlayer.cooldown == 0) {
				//Check if item exists.
				if(realPlayer.items[socketData.abilitiesUsed[d]]) {
					//Check if item has an ability
					if(realPlayer.items[socketData.abilitiesUsed[d]].ability) {
						var ability = abilityBuilder.create(realPlayer.items[socketData.abilitiesUsed[d]].ability,
							realPlayer.x,
							realPlayer.y);
							// ability.vx = ability.maxSpeed * Math.cos(ability.rotation - Math.PI/2);
							// ability.vy = ability.maxSpeed * Math.sin(ability.rotation- Math.PI/2);
						//if enough AP...
						if(realPlayer.stats.AP >= ability.AP) {
							realPlayer.stats.AP -= ability.AP;
							ability.damage = ability.damage + realPlayer.stats.STR + realPlayer.items[socketData.abilitiesUsed[d]].bonus.STR;
							ability.dangerLevel = realPlayer.dangerLevel;
							ability.rotation = realPlayer.rotation;
							ability.owner = realPlayer.nickname;
							data.maps[realPlayer.map].insertEntity(ability);
							realPlayer.cooldown = 250;
							log.info('ability created!');
							log.info(ability);
						} else {
							delete data.abilities[ability.id];
						}
					} else { 
						log.warn('Item has no ability!');
					}
				} else { 
					log.debug('No item in that inventory slot!'); 
					//Default Attack
					if(socketData.abilitiesUsed[d] == 0) {
						var ability = abilityBuilder.create('MELEE_1',
							realPlayer.x,
							realPlayer.y);
							// ability.vx = ability.maxSpeed * Math.cos(ability.rotation - Math.PI/2);
							// ability.vy = ability.maxSpeed * Math.sin(ability.rotation- Math.PI/2);
						//if enough AP...
						if(realPlayer.stats.AP >= ability.AP) {
							realPlayer.stats.AP -= ability.AP;
							ability.damage = ability.damage + realPlayer.stats.STR;
							ability.dangerLevel = realPlayer.dangerLevel;
							ability.rotation = realPlayer.rotation;
							ability.owner = realPlayer.nickname;
							data.maps[realPlayer.map].insertEntity(ability);
							realPlayer.cooldown = 250;
							log.info('ability created!');
							log.info(ability);
						} else {
							delete data.abilities[ability.id];
						}
					}
					 
				}
			} else { 
				log.warn('Not cooled down yet.');
			}
		}

		for(var d in socketData.itemChanges) {
			//THIS DOESNT ALWAYS LOG... SOMETIMES ITS EMPTY EVEN AFTER DROPPING STUFF
			log.info(socketData.itemChanges);

			if(typeof socketData.itemChanges[d]["DROPPED"] === 'number') {
				
				//Keep temp item to insert into map later
				tempItem = realPlayer.items[socketData.itemChanges[d]["DROPPED"]];
				
				if(tempItem) {
					//remove from player item collection
					realPlayer.items[socketData.itemChanges[d]["DROPPED"]] = null;

					//Set the dropped item's x, y, and owner to false(so everyone can see it.)
					tempItem.x = realPlayer.x;
					tempItem.y = realPlayer.y;
					tempItem.owner = false;

					//insert into map
					data.maps[realPlayer.map].insertEntity(tempItem);
				}
			}

			if(typeof socketData.itemChanges[d]["SWITCHED"] === 'object') {
				//Should only loop once. looping to get the value of the property.
				for(var s in socketData.itemChanges[d]["SWITCHED"]) {
					tempItem = realPlayer.items[socketData.itemChanges[d]["SWITCHED"][s]];
					realPlayer.items[socketData.itemChanges[d]["SWITCHED"][s]] =  realPlayer.items[s];
					realPlayer.items[s] = tempItem;
				}

				//testing
				log.info(realPlayer.items[0]);

			}

			if(typeof socketData.itemChanges[d]["PICKUP"] === 'object') {
				
				tempItem = data.items[socketData.itemChanges[d]["PICKUP"].item.id];
				
				if(tempItem) {
					if(tempItem.owner == false || tempItem.owner == realPlayer.nickname) {
						if(tempItem.map) {
							data.maps[tempItem.map].removeEntity(tempItem);

							// if(realPlayer.items[socketData.itemChanges[d]["PICKUP"].menuPosition]) {
							// 	//There is an item in inventory slot.
							// 	realPlayer.items[socketData.itemChanges[d]["PICKUP"].menuPosition].owner = false;
							// 	realPlayer.items[socketData.itemChanges[d]["PICKUP"].menuPosition].x = realPlayer.x;
							// 	realPlayer.items[socketData.itemChanges[d]["PICKUP"].menuPosition].y = realPlayer.y;
							// 	data.maps[realPlayer.map].insertEntity(realPlayer.items[socketData.itemChanges[d]["PICKUP"].menuPosition]);
							// }
							realPlayer.items[socketData.itemChanges[d]["PICKUP"].menuPosition] = tempItem;
							
							tempItem.owner = realPlayer.nickname;
							log.info('success!');
						}
					}
				} else {
					//Already picked up, owner is someone else.
					log.warn('failure!');
				}
				

			}
		}
			//SEND NEW MESSAGES TO USERS
			if(typeof socketData.message === 'string'){
					data.maps[realPlayer.map].sectors[realPlayer.sector].newMessages.push({nickname:socket.nickname,
																		   message:socketData.message});
					// for(var nickname in data.players){
					// 	//THIS MAY NOT BE EFFICIENT AND MAY NEED TO BE REVISED
					// 	//find out if player is in 9 sectors around the player
					// 	if(data.players[nickname].sector -1 === data.players[socket.nickname].sector || data.players[nickname].sector + 1 === data.players[socket.nickname].sector ||
					// 	   data.players[nickname].sector + data.maps[data.players[nickname].map].sectorsWide + 1 === data.players[socket.nickname].sector || data.players[nickname].sector + data.maps[data.players[nickname].map].sectorsWide === data.players[socket.nickname].sector ||
					// 	   data.players[nickname].sector + data.maps[data.players[nickname].map].sectorsWide - 1 === data.players[socket.nickname].sector || data.players[nickname].sector - data.maps[data.players[nickname].map].sectorsWide === data.players[socket.nickname].sector ||
					// 	   data.players[nickname].sector - data.maps[data.players[nickname].map].sectorsWide + 1 === data.players[socket.nickname].sector || data.players[nickname].sector - data.maps[data.players[nickname].map].sectorsWide - 1 === data.players[socket.nickname].sector ||
					// 	   data.players[nickname].sector === data.players[socket.nickname].sector){
					// 		//find if player has a socket
					// 	   for(var socketId in sockets){
					// 	   		//check if socket has a nickname
					// 	   		if(sockets[socketId].nickname){
					// 	   			//if the nickname matches socket nickname
					// 	   			if(sockets[socketId].nickname === nickname){
					// 	   				//send the new message
					// 	   				sockets[socketId].emit('newMessage',{nickname:socket.nickname,
					// 									 					  message:socketData.message});
					// 	   			}
					// 	   		}
					// 	   }
					// 	}

					// }
					// ioServer.broadcastAll('newMessages',{nickname:socket.nickname,
					// 									 messages:socketData.messages});
				// for(var message in socketData.messages){
				// 	console.log(socketData.messages[message]);
				// }
			}

	};
	//This might be deleting new things that are in array that havent had time to go through 
	//above loops.
	queue["userUpdate"] = [];
	




	// LOG OUT

	for (var i = 0; i < logOut.length; i++) {
		var socket = logOut[i].socket;
		var socketData = logOut[i].data;
		log.debug("user: " + socket.nickname + " has left ");

		if(typeof(socket.nickname) !== 'undefined'  
		   && typeof(userData.users[socket.nickname]) !== 'undefined'){
			userData.users[socket.nickname].loggedIn = false;
			log.info('LOGGED OUT!');
			var player = data.players[socket.nickname];
			var user   = userData.users[socket.nickname];
			if(user.isGuest) {
				data.maps[player.map].removeEntity(player);
				delete data.players[socket.nickname];
				delete userData.users[socket.nickname];
			} else {
				//Check if log out is valid ( ex: combat )
				data.maps[player.map].removeEntity(player);
			}
			delete socket.nickname;
		}
		//need to make player logged out also
	};
	queue["logOut"] = [];




	// DISCONNECT

	for (var i = 0; i < disconnect.length; i++) {
		var socket = disconnect[i].socket;
		log.debug("user: " + socket.id + " has left ");
		var socketData = disconnect[i].data;
		//socket.broadcast.emit('playerLeft',socket.id);
		if(typeof(socket.nickname) !== 'undefined'  
		   && typeof(userData.users[socket.nickname]) !== 'undefined'){
			userData.users[socket.nickname].loggedIn = false;
			log.info('DISCONNECTED!');

			var player = data.players[socket.nickname];
			var user   = userData.users[socket.nickname];

			if(user.isGuest) {
				data.maps[player.map].removeEntity(player);
				delete data.players[socket.nickname];
				delete userData.users[socket.nickname];
			} else {
				//Check if log out is valid ( ex: combat )
				data.maps[player.map].removeEntity(player);
			}

			delete socket.nickname;
		}
	};
	queue["disconnect"] = [];

	log.debug('+++++++ END UPDATE ++++++');
};
