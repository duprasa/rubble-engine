'use strict';
	//dom event handlers
	var buttonClick;
	var keyPress;
require(['AssetManager','UIHandler','SocketHandler','DomEventHandler','environmentTests','game/data'],
	function(am,uh,sh,domEventHandler,environmentTests,gameData){
	//dont use window onload dom might have already been loaded!
	//window.onload = function(){


		//show main page
		uh.changeContent('menu',function(){

			//test browser
			if(!environmentTests.testBrowser()){
				uh.changeMenu('incompatible');
				return;
			}

			//test socketIO
			console.log(sh);
			if(sh.start()){

				uh.changeMenu('mainMenu');

				//load game assets
				loadGameAssets();

				//make domEvents accessible
				buttonClick = domEventHandler.buttonClick;
				keyPress	= domEventHandler.keyPress;
			}else{
				uh.changeMenu('error');
			}

		});

		function loadGameAssets(){
			//put all game assets to load here
			am.load(['images/background.png',
					 'images/guy2.png',
					 'images/menu.png',
					 'images/sprites/tileset.png',
					 'images/selectorBig.png',
					 'images/selectorSmall.png',
					 'images/selectorBig.png',
					 'images/selectedSmall.png',
					 'images/selectedBig.png',
					 'images/selectorSmall.png',
					 'images/menuOverlay.png',
					 'images/sprites/items.png',
					 'images/menuItemOverlay.png',
					 'images/guy2Shadow.png',
					 'images/warning.png',
					 'json/ability.json',
					 'json/item.json',
					 'json/monster.json',
					 'json/maps.json',
					 'sounds/slimeDeath.sound'],
					 function(assets){
					 	//check if any errors
						if(assets){
							gameData.gameLoaded = true;
						}else{
							uh.changeMenu('error');
							console.log('error loading game files :');
						}
				 	 });
		}

	//};

});