"use strict";
define(function(){
	function SoundHandler(assetSounds) {
		var songPlaying;
		var songToPlay;
		var sounds       = {};
		var soundsToPlay = [];
		var stopFlag     = false;
		

		for(var s in assetSounds) {
			if(!sounds[s]) {
				sounds[s] = new Sound(assetSounds[s],false);
				console.log('Added sound: ' + s);
			} else {
				console.log('sounds[' + s + '] already exists.');
			}
		}

		this.queueSound = function (fileName) { 
			if(sounds[fileName]) {
				console.log('queuing ' + fileName)
				soundsToPlay.push(sounds[fileName]);
			} else {
				console.log('sounds[' + fileName + '] does not exist. Cannot queue sound.');
			}	
		}

		this.queueSong = function (fileName) {
			if(sounds[fileName]) {
				songToPlay = sounds[fileName];
			} else {
				console.log('sounds[' + fileName + '] does not exist. Cannot queue song.');
			}

		}

		this.stopSong = function() {
			stopFlag = true;
		}

		this.update = function() {
			if(songToPlay) {
				if(songPlaying) {
					songPlaying.pause();
				}
				songPlaying = songToPlay;
				songToPlay = null;
				songPlaying.play();
			}
			if(stopFlag) {
				if(songPlaying) {
					songPlaying.pause();
				}
				stopFlag = false;
			}

			for(var i = 0; i < soundsToPlay.length; i++) {
				soundsToPlay[i].play();
			}

			//Empty the array.
			soundsToPlay = [];
		}

	}


	function Sound(audio,loopBoolean) {
		var me = this;

		this.audio = audio;
		this.ready = true;

		if(audio.addEventListener) {
			audio.addEventListener('ended',function() {
				console.log('ended!');
				this.currentTime = 0;
			});
		} else {
			audio.attachEvent('onended',function() {
				this.currentTime = 0;
			});
		}
	} 

	Sound.prototype.volumeUp = function () {
		if(this.audio.volume <= 0.9) {
			this.audio.volume += 0.1;
		}
	};
	Sound.prototype.volumeDown = function () {
		if(this.audio.volume >= 0.1) {
			this.audio.volume -= 0.1;
		}
	};

	Sound.prototype.play = function () {
		if(this.ready) {
			console.log('Playing sound!' + this.audio.src);
			this.audio.play();
		}
	};

	Sound.prototype.pause = function() {
		this.audio.pause();
	};
	return SoundHandler;
});