define(['game/data'],function(gameData){
	function ServerUpdates(){
		
		this.start = function(socket){
           
            //get all sector changes
            socket.on('updateUser',function(data){
                gameData.currentSectors = data.sectors; //9 sectors around player
                gameData.currentMap     = data.map; //map name
                var serverPlayer = gameData.currentSectors[4].entities.players[gameData.player.nickname];

                //Change of location by server
                if(serverPlayer.teleported) {
                	gameData.player.x = serverPlayer.x;
                	gameData.player.y = serverPlayer.y;
                }

                gameData.player.stats =  serverPlayer.stats; // get stats
                gameData.player.dangerLevel =  serverPlayer.dangerLevel; // get danger Level
                //player items
                for(var i in serverPlayer.items){
					var serverItem = serverPlayer.items[i];
					gameData.player.items[i] = serverItem;
				}
                for(var sector in data.sectors){
                    if(data.sectors[sector]){
                        for(var message in data.sectors[sector].newMessages){
                            gameData.newMessages.push(data.sectors[sector].newMessages[message]);
                        }
                    }
                }
            });
      
		};
		this.stop = function(socket){
			//remove the listeners
			socket.removeAllListeners('updateUser');
			socket.removeAllListeners('newMessage');
		};
	}
	return new ServerUpdates();
});