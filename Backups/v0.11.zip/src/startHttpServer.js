var httpServer = require('./Server/httpServer.js');
console.log('stating http server!');
httpServer.start();