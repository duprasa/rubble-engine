var gameServer = require('./Server/GameServer.js');
console.log('stating game server!');
gameServer.start();