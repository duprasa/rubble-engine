/*== Monster Spawner Module ==*/

//Status: -1 (Empty as fuck)
//This decides when and where to spawn monsters as well as which kind
//It can keep track of regions where monsters are killed them most, etc
//for statistics or its own use.



//Imports
var rules    = require("../BusinessRules");
var settings = require("../../Settings").gameServer;
var log      = require('../../Utility/Logger').makeInstance("Monster Spawner");
var data     = require("../Data");


//Module logging
log.enabled = true;
log.level   = 3;


exports.update = function() {
	if(settings.moduleEnabled["MonsterSpawner"] == false) {
		return;
	}
	
	//Probably uses maps and monsters to determine where spawns are needed.
};


