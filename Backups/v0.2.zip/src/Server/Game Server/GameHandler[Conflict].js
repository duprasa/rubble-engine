/*== Game Server Module ==*/

//Status: 2 (needs additions/editing)
//This is the root of the game, it launches the main gameloop.



//Imports
var gameLoop = require("./Loop");
var settings = require("./Settings");
var database = require("./DatabaseAccess");
var log      = require('../Utility/Logger').makeInstance("GameHandler");
var serverSettings = require("../Settings").settings;
var mapHandler     = require("./Maps/mapHandler");

//Module logging
log.enabled = true;
log.level   = 3;


var initialized = false;


exports.init = function(){

	if(serverSettings.moduleEnabled["GameHandler"] == false) {
		log.debug('Cannot call function init. Module is disabled.');
		return;
	}

	initialized = true;
	log.debug('game server initialized!');
};

//Game Server start
exports.start = function() {

	if(serverSettings.moduleEnabled["GameHandler"] == false) {
		log.debug('Cannot call function start. Module is disabled.');
		return;
	}

	if(!initialized) {
		log.warn('Game Server cannot start without being initialized.');
		return;
	}

	log.info('Game server started');

	settings.listGameModules();

	mapHandler.init();

	database.load(function() {
		gameLoop.start();
	});

};
