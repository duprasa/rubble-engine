
module.exports = {
	maps: [
		'grassy'
	],
	//Dimensions of sectors in tiles.
	sectorSize : 10,
	//Defaults for tile settings.
	defaultGraphics : 0,
	defaultPhysics  : 0,
	defaultDanger   : 0,
	defaultSpawn    : 0,
	defaultLevelReq : 0,
	defaultKillReq  : 0,
	defaultSpecial  : 0
};