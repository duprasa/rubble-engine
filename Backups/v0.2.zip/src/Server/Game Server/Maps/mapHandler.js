/*== Map Handler Module ==*/

//Status: 0 
//Load maps.



//Imports
var log      = require('../../Utility/Logger').makeInstance("MapHandler");
var data     = require('../Data');
var fm      = require('../../Utility/FileManager');
var settings = require('./Settings');


//Module logging
log.enabled = true;
log.level   = 3;


var initialized = false;


//If no callback is given. init will act synchronous
exports.init = function (callback) {
	if(initialized) {
		log.warn('Already initialized.');
		return;
	}

	log.debug('Initializing...');

	var locks = {};

	for(var index in settings.maps) {
		locks[index] = "locked";
		initMap(index,locks[index]);
	}

	if(!callback) {
		while(true) {
			var count = 0;
			var unlockedCount = 0;

			for(var i in locks) {
				count++;
				if(locks[i] == "unlocked" ) {
					unlockedCount++;
				}
			}

			if(count == unlockedCount) {
				break;
			}
		}
	}

	if(callback) {
		callback();
	}

	initialized = true;
};


function initMap(index,lock) {
	var path = '/../Game Server/Maps/Map Data/' + settings.maps[index] + '.json';
	fm.fetchFile(path,function(err,file) {
		if(err) {
			log.error('Can\'t fetch file ' + settings.maps[index] + '.json');
		} else {

			var mapStructure = JSON.parse(file);
			var newMap = {};

			newMap.name       = settings.maps[index];
			newMap.tileSize   = mapStructure.tileheight;

			//if sector size is bigger than width or height, pick the smallest and apply to sector size.
			if(settings.sectorSize > mapStructure.width || settings.sectorSize > mapStructure.height) {
				newMap.sectorSize = (mapStructure.height <= mapStructure.width)? mapStructure.height: mapStructure.width;
			} else {
				newMap.sectorSize = settings.sectorSize; 
			}

			newMap.width      = mapStructure.width;
			newMap.height     = mapStructure.height;
			newMap.tiles      = [];

			//Populate map with default tiles
			for(var a = 0;a < (newMap.width * newMap.height);a++) {
				newMap.tiles.push({
					graphics : settings.defaultGraphics,
					physics  : settings.defaultPhysics,
					danger   : settings.defaultDanger,
					spawn    : settings.defaultSpawn,
					levelReq : settings.defaultLevelReq,
					killReq  : settings.defaultKillReq,
					special  : settings.defaultSpecial
				});
			}
			
			//Add graphics layer info to tiles.
			for(var i = 0; i < mapStructure.layers.graphics.data.length;i++) {
				newMap.tiles[i].graphics = mapStructure.layers.graphics.data[i];
			} 

			//Add physics layer info to tiles
			for(var i = 0;i < mapStructure.layers.physics.data.length; i++) {
				newMap.tiles[i].physics = mapStructure.layers.physics.data[i];
			}

			//Add danger layer info to tiles
			for(var i = 0;i < mapStructure.layers.danger.data.length; i++) {
				newMap.tiles[i].danger = mapStructure.layers.danger.data[i];
			}


			//split map tiles into sectors.
			newMap.sectors = [];
			var sectorsWide = Math.ceil(newMap.width / newMap.sectorSize);
			var sectorsLong = Math.ceil(newMap.height/ newMap.sectorSize);

			//create a the sectors as well as a tile array in each one.
			for(var b = 0; b < (sectorsWide * sectorsLong); b++) {
				
				newMap.sectors[b] = {
					tiles : []
				};
			} 

			//copy tiles from map object into appropriate sector objects.
			for(var c = 0; c < newMap.tiles.length; c++) {
				var sectorY = Math.floor(Math.floor(c / newMap.width) / newMap.sectorSize);
				var sectorX = Math.floor((c % (newMap.width)) / newMap.sectorSize);
				
				log.info('sector : ' + ((sectorY * sectorsWide) + sectorX));
				newMap.sectors[(sectorY * sectorsWide) + sectorX].tiles.push(newMap.tiles[c]);
			}
			
			//add newMap to the map collection in the data module.
			data.maps[newMap.name] = newMap;
			
			
			lock = "unlocked";
		}
	});
	
}

