/*== Client Events Module ==*/

//Status: -1 (Empty as fuck)
//This module is in charge of either receiving messages 
//from SocketIO server or a queue of messages and keeping
//them here until the Loop module takes care of them.



//Imports
var settings = require("../../Settings").gameServer;
var data         = require("../Data");
var ioServer = require("../../IO Server/IOHandler");
var log          = require('../../Utility/Logger').makeInstance("Client Events");


//Module logging
log.enabled = true;
log.level = 3;


exports.update = function() {
	log.debug('+++++++ UPDATING ++++++');
	var queue = ioServer.queue;
	var connection = queue["connection"];
	var newPlayers = queue["newPlayer"];
	var playerMove = queue["playerMove"];
	var disconnect = queue["disconnect"];

	for (var i = 0; i < connection.length; i++) {
		var socket = connection[i].socket;
		log.debug("user: " + socket.id + " has connected");
		socket.emit('socketId',socket.id); // test with spike 2S game
		data.players[socket.id] = {};
	};
	queue["connection"] = [];

	for (var i = 0; i < newPlayers.length; i++) {
		var socket = newPlayers[i].socket;
		log.debug("user: " + socket.id + " has sent new player data");
		var socketData = newPlayers[i].data;
		data.players[socket.id].x = socketData.x;
		data.players[socket.id].y = socketData.y;
		socket.broadcast.emit('playerJoined',{id: socket.id, location:{x:socketData.x,y:socketData.y}});
	};
	queue["newPlayer"] = [];

	for (var i = 0; i < playerMove.length; i++) {
		var socket = playerMove[i].socket;
		log.debug("user: " + socket.id + " has moved ");
		var socketData = playerMove[i].data;
		data.players[socket.id].x = socketData.x;
		data.players[socket.id].y = socketData.y;
	};
	queue["playerMove"] = [];

	for (var i = 0; i < disconnect.length; i++) {
		var socket = disconnect[i].socket;
		log.debug("user: " + socket.id + " has left ");
		var socketData = disconnect[i].data;
		socket.broadcast.emit('playerLeft',socket.id);
		delete data.players[socket.id];
	};
	queue["disconnect"] = [];

	  ioServer.broadcastAll('newPlayerLocations',data.players);

	log.debug('+++++++ END UPDATE ++++++');
};
