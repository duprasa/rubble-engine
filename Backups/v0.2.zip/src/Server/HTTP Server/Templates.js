/*== Templates module ==*/

//Status: 4 (stable)
//This module contains all the templates or "views" that the http 
//handlers return to clients, after optionally rendering them with
//specific variables



//Imports
var swig = require("swig");

exports.templates = {
	'game': swig.compileFile(__dirname + '/../../Client/Templates/game.html')
};