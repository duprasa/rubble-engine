var data = require("../../Data");

function AbstractAbility() {

}

AbstractAbility.prototype.type = 'ABILITY';



module.exports = AbstractAbility;

AbstractAbility.prototype.update = function() {
	if(this.new) {
    	this.new = false;
  	}
	if(this.old) {
		this.die();
		return;
	}
	if(!this.map) {
		this.timeLeft = this.timeToLive;
	} else {
		this.timeLeft -= 1000/60; //To change.

		if(this.timeLeft <= 0) {
			this.old = true;
		}
	}
	//calculate its velocity vector based on its rotation
	this.vx = this.maxSpeed * Math.cos(this.rotation - Math.PI/2);
	this.vy = this.maxSpeed * Math.sin(this.rotation- Math.PI/2);
	this.x += this.vx;
	this.y += this.vy;
}

AbstractAbility.prototype.die = function() {
	data.maps[this.map].removeEntity(this);
	delete data.abilities[this.id];
}

AbstractAbility.prototype.hit = function(entity) {
	if(this.old || entity.old) {
		return;
	}

	switch(entity.type) {
		case "MONSTER":
			var alreadyHitMonster = this.entitiesHit[entity.id];
			//Careful this makes count a reserved word which cannot be a username.
			var totalEntitiesHit  = this.entitiesHit.count;

			if(alreadyHitMonster) {
				//Already hit this player.
				if(this.hits === 'ONCE') {
					//Already hit this player and ability only hits once.
					return;
				} else {
					//Proceed to being hit.
					this.entitiesHit[entity.id] += 1;
				}
			} else {
				//Has not hit player yet.
				if(totalEntitiesHit === this.affects) {
					//Already hit as many entities as possible 
					return;
				} else {
					this.entitiesHit[entity.id] = 1;
					this.entitiesHit.count += 1;
					if(this.affects === this.entitiesHit.count && (this.hits != "MANY")) {
						this.old = true;
					}
				}
			}
			//When monster gets damaged what happens depends on the monster's state.
			switch(entity.status) {
				case "CALM":
					entity.status = 'ATTACKED';
					entity.target = this.owner;
					break;
				case "ATTACKED":
					entity.target = this.owner;
					break;
				case "DIEING": 
					//Not much to do at this point..
					break;
				case "DEAD":
					//aren't you cruel?
					return;
					break;
			}

			var damageDealt = ((this.damage - entity.def) >= 1) ? (this.damage - entity.def) : 0; // Math.max(damage - entity.def,0)
			if(damageDealt > entity.maxHP) {
				damageDealt = entity.maxHP;
			}
			//keep track of damage dealt and by whom
			if(entity.damageTaken[this.owner]) {
				entity.damageTaken[this.owner] += damageDealt;
				if(entity.damageTaken[this.owner] > entity.maxHP) {
					entity.damageTaken[this.owner] = entity.maxHP;
				}	
			} else {
				entity.damageTaken[this.owner]  = damageDealt;
			}

			//Ouch!
			entity.hp -= damageDealt;
			//Set recent damage
			if(entity.recentDamage) {
				entity.recentDamage += damageDealt;
			} else {
				entity.recentDamage = damageDealt;
			}
			
			//Check if moster is still alive.
			if(entity.hp <= 0) {
				entity.old = true;
				
			} else if (entity.hp <= (entity.maxHP * 0.30)) {
				entity.status = "DIEING";
			}
		break;
		case "PLAYER":
			//If ability is old, return.
			if(this.old || entity.old) {
				return;
			}

			var alreadyHitPlayer = this.entitiesHit[entity.nickname];
			//Careful this makes count a reserved word which cannot be a username.
			var totalEntitiesHit  = this.entitiesHit.count;

			if(alreadyHitPlayer) {
				//Already hit this player.
				if(this.hits === 'ONCE') {
					//Already hit this player and ability only hits once.
					return;
				} else {
					//Proceed to being hit.
					this.entitiesHit[entity.nickname] += 1;
				}
			} else {
				//Has not hit player yet.
				if(totalEntitiesHit === this.affects) {
					//already hit as many as possible
					return;
				} else {
					this.entitiesHit[entity.nickname] = 1;
					this.entitiesHit.count += 1;
					//last  condition are only for the exception of something that hits many times but only 1 player
					if(this.affects === this.entitiesHit.count  && (this.hits != 'MANY')) {
						this.old = true;
					}
				}
			}

			var damageDealt = ((this.damage - entity.stats.DEF) >= 1) ? (this.damage - entity.stats.DEF) : 0; // Math.max(damage - this.def,0)
			
			if(damageDealt > entity.stats.maxHP) {
			damageDealt = entity.stats.maxHP;
			}
			//keep track of damage dealt and by whom
			if(entity.damageTaken[this.owner]) {
			entity.damageTaken[this.owner] += damageDealt;
				if(entity.damageTaken[this.owner] > entity.stats.maxHP) {
					entity.damageTaken[this.owner] = entity.stats.maxHP;
				}
			} else {
			entity.damageTaken[this.owner]  = damageDealt;
			}

		

			//Ouch!
			entity.stats.HP -= damageDealt;
			//Set recent damage
			if(entity.recentDamage) {
				entity.recentDamage += damageDealt;
			} else {
				entity.recentDamage = damageDealt;
			}
			
			
			//Check if moster is still alive.
			if(entity.stats.HP <= 0) {
				entity.old = true;
				entity.stats.HP = 0;
			} 
		break;
	}
}


