var ib = require('../ItemBuilder');
var data = require('../../Data');
var log  = require('../../../Utility/Logger').makeInstance('Abstract Monster');
function AbstractMonster() {

}

//Static properties defaults
AbstractMonster.prototype.type = 'MONSTER';



AbstractMonster.prototype.die = function() {
	
	var drops = [];
	var biggestDamage = { player : false ,damage : 0 };
	
	for(var nickname in this.damageTaken) {
		//TODO: Allies
		if(data.players[nickname]) {
			data.players[nickname].stats.exp += Math.floor(this.exp * Math.floor(this.damageTaken[nickname] / this.maxHP));
			
		} else {
			log.warn('No such player with nickname "' + nickname + '" exists. Cant award EXP.');
		}

		if(this.damageTaken[nickname] > biggestDamage.damage) {
			biggestDamage.player = nickname;
			biggestDamage.damage = this.damageTaken[nickname];
		}
	}

	for(var i in this.drops) {
		var roll = Math.random() * 100;
		if(this.drops[i] >= roll) {
			var drop = ib.create(i,this.x,this.y,this.map);
			drop.owner = biggestDamage.player;
			drops.push(drop);
		}
	}
	if(data.players[biggestDamage.player]) {
		data.players[biggestDamage.player].stats.monstersKilled += 1;
	}
	delete data.monsters[this.id];
	data.maps[this.map].removeEntity(this);
};

AbstractMonster.prototype.update = function() {
	if(this.new) {
    	this.new = false;
  	}

	if(this.old) {
		this.die();
		return;
	}

	this.recentDamage = null;

	//If target is too far.... forget it.
	if(this.status === "ATTACKED" || this.status === "DIEING") {
		if(data.players[this.target]) {
			//use math.abs
			// if((this.target.x - this.x) > 500 || (this.target.x - this.x) < (-500)) {
			// 	this.status = "CALM";
			// 	this.target = null;
			// }
		} else {
			this.status = "CALM";
		}
	}
	switch(this.behavior[this.status]){
		case "WALK":
		//Walk around..
		break;
		case "FOLLOW":
			if(data.players[this.target] && data.players[this.target].map == this.map) {
				if(this.x < data.players[this.target].x) {
					this.x += this.spd;
				} else {
					this.x -= this.spd;
				}
				if(this.y < data.players[this.target].y) {
					this.y += this.spd;
				} else {
					this.y -= this.spd;
				}

			} else {
				this.status = "CALM";
			}
		break;
		case "ATTACK":
		//follow target and attack ..using attack.. 
		//stop if they run away..
		break;
		case "RUN_AWAY":
		//Run away from target
			// if(data.players[this.target]) {
			// 	if(this.x < data.players[this.target].x) {
			// 		this.x -= this.spd / 2;
			// 	} else {
			// 		this.x += this.spd / 2;
			// 	}
			// 	if(this.y < data.players[this.target].y) {
			// 		this.y -= this.spd / 2;
			// 	} else {
			// 		this.y += this.spd / 2;
			// 	}

			// } else {
			// 	this.status = "CALM";
			// } 
		break;
	}	

	//monsters should refill hp if not damaged for a while
};


module.exports = AbstractMonster;

