//hello nick, the password is POOPYDOOPY
"use strict";
define(['Classes/Player','game/InputBindings','game/PhysicsEngine','game/ScreenHandler','game/data','game/serverUpdates','game/gameManager','game/chatManager'],
    function(Player,inputBindings,physicsEngine,Screen,gameData,serverUpdates,gameManager,chatManager){
    function Game(){
        var stop = false;
        var socket;

        this.start=function(assets,inSocket,IOGameData){
            stop = false;

            //temporary fix for menu manager multiple instance bug
            var menuManager = inputBindings.menuManager;


            //set up the canvas
            var canvas = document.getElementById('theGame');
            var menuCanvas = document.getElementById('theGameMenu');
            var screen = new Screen(canvas,assets.images);
            var menu = new Screen(menuCanvas,assets.images);

            //set up input
            inputBindings.changeState('inGame');

            //set received data
            gameData.currentSectors = IOGameData.sectors;
            gameData.currentMap     = IOGameData.player.map;
            gameData.maps           = JSON.parse(assets.texts['json/maps.json']);
            gameData.monsterInfo    = JSON.parse(assets.texts['json/monster.json']);
            gameData.itemInfo       = JSON.parse(assets.texts['json/item.json']);
            gameData.abilityInfo    = JSON.parse(assets.texts['json/ability.json']);

            //create 'real' player
            var player = new Player(IOGameData.player.x,
                                    IOGameData.player.y,
                                    IOGameData.player.rotation,
                                    IOGameData.player.nickname);
            console.log(IOGameData);
            player.items = IOGameData.player.items;
            player.sector = IOGameData.player.sector;
            player.stats = IOGameData.player.stats;
            player.dangerLevel = IOGameData.player.dangerLevel;
            //add player to game data
            gameData.player = player;

            //set up socket listeners
            socket = inSocket;
            serverUpdates.start(socket,player);
            //add monsters to data

            //get the 9 sectors around that player
                
            //set camera to follow player
            screen.follow(player);
            //THERE SHOULD BE A LOADING SCREEN UNTIL HERE
            var deltaTime = 0;
            var lastTime = performance.now();
            //game loop
            (function gameLoop(){
                if(stop){
                    console.log('stopped game loop');
                    return;
                }
                deltaTime = (performance.now() - lastTime)/ 1000;
                lastTime = performance.now();
                //game data is updated from server in IO

                
                //do actions: physics and stuff go here
                player.doActions(inputBindings.keysPressed);
                physicsEngine.update();
                player.move();

                //determine if player is on an item SHOULD BE DONE ON SERVER
                player.floorItems = []; // clear floor items
                for(var sector in gameData.currentSectors){
                    if(gameData.currentSectors[sector] !== false){
                        for(var itemId in gameData.currentSectors[sector].entities.items){
                            var item = gameData.currentSectors[sector].entities.items[itemId];
                            //Updated so does not test for collision with items that arent yours to pickup.
                            if(item.owner == false || item.owner == gameData.player.nickname) {
                                var dx = Math.abs(player.x - item.x);
                                var dy = Math.abs(player.y - item.y);
                                var d = Math.sqrt(dx * dx + dy * dy);
                                if(d < gameData.itemInfo.radius){
                                    player.floorItems.push(item);
                                }
                            }
                        }     
                    }
                }

                //draw when frame is ready
                requestAnimFrame(function(){
                    //check if game has stopped
                    if(stop){
                        return;
                    }
                    //draw assets and tiles                    
                    gameManager.animate(screen);


                    //draw menu overlay
                    if(inputBindings.getStateName() === 'inMenu'){
                        screen.drawImage(0,0,'images/menuOverlay.png')
                    }
                    //draw chat
                    chatManager.animate(screen);

                    //paint all the changes from the screen
                    screen.paint();

                    //draw Menu
                    menu.drawBackground('images/menu.png');
                    menuManager.animate(menu);
                    menu.paint();

                });
                    //update server with changes
                    gameData.updateServerData.player = {x:Math.round(player.x),
                                                        y:Math.round(player.y),
                                                        rotation:player.rotation};
                    socket.emit('userUpdate',gameData.updateServerData);

                    //clearItems from updateServerData
                    gameData.updateServerData.itemChanges = [];
                    gameData.updateServerData.message = null;
                    gameData.updateServerData.abilitiesUsed = [];

                    //this must be at 64 or more or anim frame laggs
                    setTimeout(gameLoop,(1000/64));
                })();
        };
        this.stop =function(){
            if(!socket){
                console.log('game is already stopped');
                return;
            }
            serverUpdates.stop(socket);
            inputBindings.changeState('default');
            socket.emit('logOut',{});
            stop = true;
            chatManager.stop();
            //clear all gameData
            //gameData.player=null;
            gameData.monsterInfo={};
            gameData.itemInfo ={};
            gameData.currentMap='No Map';
            gameData.currentSectors=[];
            gameData.newMessages=[];
            gameData.serverInventory=[];
            gameData.maps={};
            gameData.updateServerData={
                player:{x:null,y:null,rotation:null},
                itemChanges:[],
                messages:[]
            };
        };
    }
    return new Game();
});