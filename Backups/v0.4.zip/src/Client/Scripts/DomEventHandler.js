

define(['UIHandler'],function(uh){
	//var uh = new UIHandler();
	function DomEventHandler(socket,ready){

		this.buttonClick = function (menuId){
			if(uh.getTransitionState()){
				//there is already a transition occuring
				//do nothing
				return;
			}
			switch(menuId){
				//case just for testing
				case 'getSector':
					console.log('requestingSector');
					socket.emit('requestSector',{});
					break;

				case 'menu':
					uh.changeContent('menu',function(){
						//when page is loaded start the game
						game.stop(socket);
						uh.changeMenu('mainMenu');
					});
					break;
				case 'back':
					uh.previousMenu();
					break;
				case 'mainMenu': case 'help': case 'register': case 'login': case 'credit':
					uh.changeMenu(menuId);
					break;
				case 'play':
					//authenticate user
					console.log('authenticating Guest');
					socket.emit('authGuest',{});

					uh.changeMenu('loading');
					break;
				case 'login-play':
					//get username and password
					var nickname = document.getElementById('nickname').value;
					var password = document.getElementById('password').value;
					console.log('authenticating user');
					//authenticate user
					socket.emit('authUser',{nickname:nickname,
													 password:password});
					break; 
				case'register-play':
					//authenticate user
					console.log('authenticating registration');
					socket.emit('authRegister',{nickname:document.getElementById('nickname').value,
													 	 password:document.getElementById('password').value,
													 	 email:document.getElementById('email').value});

					uh.changeMenu('loading');
					break;
				default:
					console.log('unhandled buttonClick ' + menuId);
					break;
			}
			var focusElement = document.getElementsByClassName('focus2')[0];
			if(focusElement){
				focusElement.focus();
			}
		};
		this.keyPress = function(event,menuId){
			if(event.keyCode === 13){
				this.buttonClick(menuId);
			}
		};

		// socket events
		socket.on('validateUser',function(status){
			var errorElement = document.getElementById('login-error');
			switch(status) {
			case "VALID":
				console.log('username and password are valid');
				//attempt to play game
				if(ready.gameAssets){
					console.log('user is valid and assets are ready');
					uh.changeContent('game',function(){
						//when page is loaded start the game
						game.start(socket);	
					});
				}else{
					console.log('user is valid and assets arent ready');
					ready.user = true;
					uh.changeMenu('loading');
				}	
				break;
			case "NOT_VALID":
				errorElement.innerHTML = 'Nickname or password are invalid';
				break;
			case "TOO_MANY_ATTEMPTS":
				errorElement.innerHTML = 'Too many attempts on same IP';
				break;
			case "ALREADY_LOGGED_IN":
				errorElement.innerHTML = 'User already logged in.';
				break;
			}
			document.getElementById('password').value = '';
		});

		socket.on('validateGuest',function(isValid){
			if(isValid){
				//attempt to play game
				if(ready.gameAssets){
					uh.changeContent('game',function(){
						//when page is loaded start the game
						game.start(socket);	
					});
				}else{
					ready.user = true;
					uh.changeMenu('loading');
				}	
			}else{
				//go to authentication error page
				uh.changeMenu('authenticationError');
			}
		});
		socket.on('validateRegister',function(isValid){
			if(isValid){
				//attempt to play game
				if(ready.gameAssets){
					uh.changeContent('game',function(){
						//when page is loaded start the game
						//game.start(socket);	
					});
				}else{
					ready.user = true;
					uh.changeMenu('loading');
				}	
			}else{
				//go to authentication error page
				uh.changeMenu('authenticationError');
			}
		});

	}
	return DomEventHandler;
});