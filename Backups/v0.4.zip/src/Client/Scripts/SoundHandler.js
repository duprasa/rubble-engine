"use strict";
define(function(){
	function SoundHandler() {
		var songPlaying;
		var songToPlay;
		var sounds       = {};
		var soundsToPlay = [];
		var playable     = {};
		var stopFlag     = false;

		//This section checks for playable types of sound.
		var audio;
		audio = new Audio();

		//Check if audio object is supported.
		if(!audio) {
	 		console.log("Browser does not support audio objects.");
	 		return;
		}
		//Check what file type browser can play
		if(audio.canPlayType) {
			if(audio.canPlayType("audio/ogg") !== "") {
				console.log('can play ogg.');
				playable['ogg'] = true;
			}
			if(audio.canPlayType("audio/wav") !== "") {
				console.log('can play wav.');
				playable['wav'] = true;
	 		}
			if(audio.canPlayType("audio/mpeg") !== "") {
				console.log('can play mp3.');
				playable['mp3'] = true;
			}
		} else {
			console.log("Browser does not have canPlayType function.");
			return;
		}

		

		this.load = function (fileName,loopBoolean) {
			if(!sounds[fileName]) {
				sounds[fileName] = new Sound('sounds/' + fileName,loopBoolean,playable);
			} else {
				console.log('sounds[' + fileName + '] already exists.');
			}
		}


		this.queueSound = function (fileName) { 
			if(sounds[fileName]) {
				soundsToPlay.push(sounds[fileName]);
			} else {
				console.log('sounds[' + fileName + '] does not exist. Cannot queue sound.');
			}	
		}

		this.queueSong = function (fileName) {
			if(sounds[fileName]) {
				songToPlay = sounds[fileName];
			} else {
				console.log('sounds[' + fileName + '] does not exist. Cannot queue song.');
			}

		}

		this.stopSong = function() {
			stopFlag = true;
		}

		this.update = function() {
			if(songToPlay) {
				if(songPlaying) {
					songPlaying.pause();
				}
				songPlaying = songToPlay;
				songToPlay = null;
				songPlaying.play();
			}
			if(stopFlag) {
				if(songPlaying) {
					songPlaying.pause();
				}
				stopFlag = false;
			}

			for(var i = 0; i < soundsToPlay.length; i++) {
				soundsToPlay[i].play();
			}

			//Empty the array.
			soundsToPlay = [];
		}

	}


	function Sound(fileName,loopBoolean,playableTypes) {
		var me = this;

		this.audio;
		this.audio = new Audio(); 
		this.ready = false;

		var loop   = loopBoolean || false;
		
		
		if(playableTypes['ogg']) {
			var source = document.createElement('source');
			source.type = "audio/ogg";
			source.src = fileName + '.ogg';
			this.audio.appendChild(source);
			console.log('requesting ogg');
		}  

		if(playableTypes['wav']) {
			var source = document.createElement('source');
			source.type = "audio/wav";
			source.src = fileName + '.wav';
			this.audio.appendChild(source);
			console.log('requesting wav');
		}

		if(playableTypes['mp3']) {
			var source = document.createElement('source');
			source.type = "audio/mpeg";
			source.src = fileName + '.mp3';
			this.audio.appendChild(source);
			console.log('requesting mp3');
		}

		//Attach event to know when file can be played.
		if(this.audio.addEventListener) {
			this.audio.addEventListener('canplaythrough',
				//Might create circular ref over audio
				function() {
					me.ready = true;
					console.log('File ready to be played.');
				},false);
			if(loop) {
				//Might create circ ref over audio
				this.audio.addEventListener('ended', function() {
					this.currentTime = 0;
					me.play();
				},false);
			}
			

		} else if(this.audio.attachEvent) {
			//might create circ ref over audio
			this.audio.attachEvent('oncanplaythrough', function() {
				me.ready = true;
				console.log('File ready to be played.');
			});
			if(loop) {
				//might create curc ref over audio.
				this.audio.attachEvent('onended', function() {
					this.currentTime = 0;
					me.play();
				});
			}	
			
		} else {
			console.log('Sound cannot be loaded.');
			return;
		}
	} 

	Sound.prototype.volumeUp = function () {
		if(this.audio.volume <= 0.9) {
			this.audio.volume += 0.1;
		}
	};
	Sound.prototype.volumeDown = function () {
		if(this.audio.volume >= 0.1) {
			this.audio.volume -= 0.1;
		}
	};

	Sound.prototype.play = function () {
		if(this.ready) {
			this.audio.play();
		}
	};

	Sound.prototype.pause = function() {
		this.audio.pause();
	};
	return new SoundHandler();
});