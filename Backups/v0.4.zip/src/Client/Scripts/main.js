'use strict';
	//dom events
	var buttonClick;
	var keyPress;
require(['AssetManager','UIHandler','DomEventHandler','environmentTests'],function(AssetManager,uh,DomEventHandler,environmentTests){
	console.log('main.js loaded');
	//dont use window onload dom might have already been loaded!
	//window.onload = function(){
		var ready ={gameAssets:false,
				    user:false};

		var am = new AssetManager();
		//var uh = new UIHandler();

		//show main page
		console.log('chaning to menu!');
		uh.changeContent('menu',function(){

			//test socketIO
			if(typeof(io)!=='undefined'){

				//test browser
				if(!environmentTests.testBrowser()){
					uh.changeMenu('incompatible');
					return;
				}

				var socket = io.connect('http://localhost:81');
				uh.changeMenu('mainMenu');
				//load game assets
				loadGameAssets();
			}else{
				uh.changeMenu('error');
			}
			//set dom Events
			var domEventHandler = new DomEventHandler(socket,ready);
			//make domEvents accessible
			buttonClick = domEventHandler.buttonClick;
			keyPress	= domEventHandler.keyPress;

		});

		function loadGameAssets(){
			//put all game assets to load here
			am.load(["scripts/game/InputHandler.js",
					 "scripts/game/ScreenHandler.js",
					 "scripts/game/Entity.js",
					 "scripts/game/Player.js",
					 "scripts/game/OnlinePlayer.js",
					 "scripts/game/Wall.js",
					 "scripts/game/Box.js",
					 "scripts/game/PhysicsEngine.js",
					 "scripts/game/game.js"],
					 function(assets){
						var hasError = false;
						for(var path in assets){
							if(assets[path] === null){
								console.log('error loading game asset ' + path)
								hasError = true;
								break;
							}
						}
						if(!hasError){
							ready.gameAssets = true;
							console.log('game assets ready');
							if(ready.user){
								//this function is in the loaded scripts
								//change page to game
								uh.changeContent('game',function(){
									//when page is loaded start the game
									game.start(socket);	
								});
							}
						}else{
							console.log('error loading game files');
						}
				 	 });
		}

	//};

});