/*
==Version 1.1==
the screen handler simplifies working with the canvas. The canvas must already
be created and have an id. It also manages Images so that you don't have to reload images
and it is also compatible with json sprite sheet data
## WARNING: doesnt handle rotation on sprite sheets ##
==april 9 2013 samuel dupras==
==april 9 2013 nicolas correa==
==may 14 2013 samuel dupras== //added images cache and sprite management
==may 22 2013 samuel dupras== //added rotation and relative drawing
*/
"use strict";
function Screen(canvas,initWidth,initHeight) {

	//check if canvas is set
	if(!canvas) {
		throw 'OBJECT NOT CREATED: Need valid canvas';
	}
	//create buffer canvas
	var bufferCanvas = document.createElement('canvas');
	var bufferContext = bufferCanvas.getContext('2d');
	//background canvas
	var backgroundCanvas = document.createElement('canvas');
	var backgroundContext = backgroundCanvas.getContext('2d');
	canvas.style.position = 'absolute';
	canvas.style.display = 'inline-block';
	//insert background canvas after canvas 
	canvas.parentNode.insertBefore(backgroundCanvas, canvas.nextSibling);
	//backgroun canvas buffer
	var bgBufferCanvas = document.createElement('canvas');
	var bgBufferContext = bgBufferCanvas.getContext('2d');
	//create temp canvas for rotations
	var tempCanvas = document.createElement('canvas');
	var tempContext = tempCanvas.getContext('2d');

	var width   = canvas.width  = bufferCanvas.width  = backgroundCanvas.width  = bgBufferCanvas.width  = initWidth  || canvas.width;
	var height  = canvas.height = bufferCanvas.height = backgroundCanvas.height = bgBufferCanvas.height = initHeight || canvas.height;
	var context = canvas.getContext('2d'); 

	canvas.tabIndex     = '1'; //Needed so that it can gain focus. so that it can take key events.
	canvas.innerHTML    = 'Your browser does not support the canvas element.';
	bufferContext.fillStyle   = 'black';

	//image buffer
	var images = {};

	//Relative location
	var offsetLocation = {x:(width/2),
						  y:(height/2)};

	this.clear = function () {

		bufferContext.clearRect(0,0,width,height);
		context.clearRect(0,0,width,height);

	};

	this.follow = function(location){

		offsetLocation = location;

	};

	this.getImages = function(){

		return images;

	};

	this.cacheImage = function(src,spriteSheet){

		addImage(src,spriteSheet)

	};

	this.drawRect = function (x,y,width,height,color) {

		//set defaults
		var x      = x 		|| 0;
		var y      = y      || 0;
		var width  = width  || 50;
		var height = height || 50;
		var color  = color  || 'black';
		//draw rect
		bufferContext.fillStyle = color;
		bufferContext.fillRect(~~(0.5 + x),
						 	   ~~(0.5 + y),
						 	   ~~(0.5 + width),
						 	   ~~(0.5 + height));

	};

	this.drawRelRect = function (x,y,width,height,color) {

		this.drawRect(x + calcOffset().x,
					  y + calcOffset().y,
					  width,
					  height,
					  color);

	};

	this.drawRotatedRect = function(dx,dy,width,height,angle,color){

	   	// Save the current context
	   	bufferContext.save();
	   	// Translate to the center point of the rect
	   	bufferContext.translate(dx + (width * 0.5),dy + (height * 0.5));
	   	// Perform the rotation
	   	bufferContext.rotate(angle);
	   	// Translate back to the top left  of the rect
	   	bufferContext.translate(-(dx + (width * 0.5)),-(dy + (height * 0.5)));

		this.drawRect(dx,
					  dy,
					  width,
					  height,
					  color);

	   	bufferContext.restore();

	};

	this.drawRelRotatedRect = function(dx,dy,width,height,angle,color){

		this.drawRotatedRect(dx + calcOffset().x,
							 dy + calcOffset().y,
							 width,
							 height,
							 angle,
							 color);

	};

	this.drawText = function (x,y,text,font,color) {

		//set defaults
		var x     = x     || 0;
		var y     = y     || 0;
		var text  = text  || 'Hello World';
		var font  = font  || '8px comic sans';
		var color = color || 'black';
		//draw text
		bufferContext.fillStyle = color;
		bufferContext.font      = font ;
		bufferContext.fillText(text,
						 ~~(0.5 + x),
						 ~~(0.5 + y));

	};

	this.drawRelText = function (x,y,text,font,color) {

		this.drawText(x + calcOffset().x,
					  y + calcOffset().y,
					  text,
					  font,
					  color);

	};

	//no rotated text methods because its extremely difficult to find the width and length of text

	this.drawImage = function (dx,dy,src,sx,sy,sh,sw) {

		//set defaults
		var dx     = dx     || 0;
		var dy     = dy     || 0;
	
		addImage(src,null);

		if(images[src].isReady){
			//check if user wants to use full image
			if(sx == undefined){
				bufferContext.drawImage(images[src].image,
								  ~~(0.5 + dx),
								  ~~(0.5 + dy));
			}else{
				if(((dx + sw > 0) && (dx < width )) &&
                  ((dy + sh > 0) && (dy < height))){
					bufferContext.drawImage(images[src].image,
									  ~~(0.5 + sx),
									  ~~(0.5 + sy),
									  ~~(0.5 + sw),
									  ~~(0.5 + sh),
									  ~~(0.5 + dx),
									  ~~(0.5 + dy),
									  ~~(0.5 + sw),
									  ~~(0.5 + sh));
				}
			}
		}else{
			console.log('IMAGE NOT DRAWN: image: ' + src + " is not loaded yet!");
		}

	};

	this.drawRelImage = function (dx,dy,src,sx,sy,sh,sw) {

		this.drawImage(dx + calcOffset().x,
					   dy + calcOffset().y,
					   src,
					   sx,
					   sy,
					   sh,
					   sw);

	};

	this.drawRotatedImage = function(dx,dy,src,angle){

	    addImage(src);
	    if(images[src].isReady){
	    	var image = images[src].image;
	    	// Save the current context
	    	bufferContext.save();
	    	// Translate to the center point of our image
	    	bufferContext.translate(dx + (image.width * 0.5),dy + (image.height * 0.5));
	    	// Perform the rotation
	    	bufferContext.rotate(angle);
	    	// Translate back to the top left of our image
	    	bufferContext.translate(-(dx + (image.width * 0.5)),-(dy + (image.height * 0.5)));

			bufferContext.drawImage(image,dx,dy);
	    	bufferContext.restore();

	    }
	};

	this.drawRelRotatedImage = function(dx,dy,src,angle){

		this.drawRotatedImage(dx + calcOffset().x,
							  dy + calcOffset().y,
							  src,
							  angle);

	};

	this.drawSprite = function(dx,dy,src,spriteName,spriteSheet){
	
		//set defaults
		var dx     = dx     || 0;
		var dy     = dy     || 0;

		addImage(src,spriteSheet);

		if(images[src].isReady){
			if(spriteName in images[src].spriteSheet){

				var sprite = images[src].spriteSheet[spriteName].frame;

				bufferContext.drawImage(images[src].image,
								  ~~(0.5 + sprite.x),
								  ~~(0.5 + sprite.y),
								  ~~(0.5 + sprite.w),
								  ~~(0.5 + sprite.h),
								  ~~(0.5 + dx),
								  ~~(0.5 + dy),
								  ~~(0.5 + sprite.w),
								  ~~(0.5 + sprite.h));

			}else{
				console.log('SPRITE NOT DRAWN: sprite: ' + spriteName + ' is not in image:' + src);
			}
		}else{
			console.log('SPRITE NOT DRAWN: image: ' + src + " is not loaded yet!");
		}	
	};

	this.drawRelSprite = function(dx,dy,src,spriteName,spriteSheet){
	
		this.drawSprite(dx + calcOffset().x,
						dy + calcOffset().y,
						src,
						spriteName,
						spriteSheet);

	};
	this.drawBackground = function(src,spriteSheet,mapData){
		//temporary

		//set defaults
		var dx     = dx     || 0;
		var dy     = dy     || 0;
	
		addImage(src,null);

		if(images[src].isReady){
			//check if user wants to use full image
				bgBufferContext.drawImage(images[src].image,
										  ~~(0.5 + dx + calcOffset().x),
										  ~~(0.5 + dy + calcOffset().y));
		}else{
			console.log('IMAGE NOT DRAWN: image: ' + src + " is not loaded yet!");
		}

	};
	//untested
	this.drawRotatedSprite = function(dx,dy,src,spriteName,spriteSheet){
	
	
		//set defaults
		var dx     = dx     || 0;
		var dy     = dy     || 0;

		addImage(src,spriteSheet);

		if(images[src].isReady){
			if(spriteName in images[src].spriteSheet){

				var sprite = images[src].spriteSheet[spriteName].frame;
		    	var image = images[src].image;
		    	// Save the current context
		    	bufferContext.save();
		    	// Translate to the center point of our image
		    	bufferContext.translate(dx + (sprite.w * 0.5),dy + (sprite.h * 0.5));
		    	// Perform the rotation
		    	bufferContext.rotate(angle);
		    	// Translate back to the top left of our image
		    	bufferContext.translate(-(dx + (sprite.w * 0.5)),-(dy + (sprite.h * 0.5)));

				bufferContext.drawImage(images[src].image,
								  ~~(0.5 + sprite.x),
								  ~~(0.5 + sprite.y),
								  ~~(0.5 + sprite.w),
								  ~~(0.5 + sprite.h),
								  ~~(0.5 + dx),
								  ~~(0.5 + dy),
								  ~~(0.5 + sprite.w),
								  ~~(0.5 + sprite.h));

		    	bufferContext.restore();

			}else{
				console.log('SPRITE NOT DRAWN: sprite: ' + spriteName + ' is not in image:' + src);
			}
		}else{
			console.log('SPRITE NOT DRAWN: image: ' + src + " is not loaded yet!");
		}	


	};

	//untested
	this.drawRelRotatedSprite = function(dx,dy,src,spriteName,spriteSheet){
		this.drawRotatedSprite(dx + calcOffset().x,dy + + calcOffset().y,src,spriteName,spriteSheet);
	};

	this.paint = function(){
		//clear the canvas to prepare for next frame
		context.clearRect(0,0,width,height);
		backgroundContext.clearRect(0,0,width,height);
		//draw the next frame
		//context.globalAlpha = 0.3; //this is for effects
		context.drawImage(bufferCanvas,0,0);
		backgroundContext.drawImage(bgBufferCanvas,0,0);
		//clear the buffer
		bufferContext.clearRect(0,0,width,height);
		bgBufferContext.clearRect(0,0,width,height);
	};
	this.drawSector = function(sector,tileSize,srcTile,srcWalls,srcPortals,srcOthers,srcItems){
			//assuming that theres 20 tiles per row
			var NUMBER_OF_TILES_PER_ROW = 16;
			var tiles = sector.tiles;
			for (var i = 0; i < tiles.length; i++) {
				var tile = tiles[i];
				this.drawRelImage(tile.x,
								  tile.y,
								  srcTile,
								  tileSize*((tile.graphic-1)%NUMBER_OF_TILES_PER_ROW) ,
								  tileSize*Math.floor((tile.graphic-1)/NUMBER_OF_TILES_PER_ROW),
								  tileSize,
								  tileSize);

			}
	};

	//PRIVATE FUNCTIONS ==================================================================================
	function addImage(src,spriteSheet){
		(function(){
			//show parameters if called without parameters
			if(!src){
				console.log("addImage INVALID PARAMETERS:  parameters(image source, [spriteSheet])");
				return false;
			}		
			//check if image has been cached	
			if(!(src in images)){
				var image = new Image();
				images[src] = {image:image, spriteSheet:spriteSheet || null, isReady:false};
				image.onload = function() {
					images[src].isReady = true;
					image.onload = null;
					image.onerror = null;
				};
				image.onerror = function(){
					//image might still be added momentaraly could be bad
					delete images[src];
					throw 'IMAGE NOT ADDED:invalid path: ' + src;
					image.onerror = null;
					image.onload = null;
				};
				image.src = src;
				return true;
			}else{
				//image already added to images
			}
		})();
		// function imageLoad(){
		// 	images[src].isReady = true;
		// }
		// function imageError(){
		// 	delete images[src];
		// 	throw 'IMAGE NOT ADDED:invalid path: ' + src;
		// }
	};

	function calcOffset(){
		var offsetX = (width / 2) - offsetLocation.x;
    	var offsetY = (height / 2) - offsetLocation.y;
    	return {x:offsetX,y:offsetY};
	};

	// OLD rotate image function
	// function rotateImage(image,angle){
	// 		tempCanvas.width = image.width;
	// 		tempCanvas.height = image.height;
			
	//         // clear temp canvas
	//     	tempContext.clearRect(0, 0, image.width, image.height);
	//     	// Save the current context
	//     	tempContext.save();
	//     	// Translate to the center point of our image
	//     	tempContext.translate(image.width * 0.5, image.height * 0.5);
	//     	// Perform the rotation
	//     	tempContext.rotate(angle);
	//     	// Translate back to the top left of our image
	//     	tempContext.translate(-image.width * 0.5, -image.height * 0.5);

	// 		tempContext.drawImage(image,0,0);
	//     	tempContext.restore();
	//     	return tempCanvas;
	// }
}