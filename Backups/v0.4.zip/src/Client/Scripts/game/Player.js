var Player = Entity.subClass({
    init: function(x,y,width,height,color,playerName){
        this._super(x,y,height,width,color);
        this.playerName = playerName;
        this.collision.fixed = true;
        this.boostProps = {chargeTime: 3, //in seconds
                           velocity: 20,
                           isCharged: true};
    }
});
Player.prototype.setRotation = function(angle){
    this.rotation = Math.abs(this.rotation % 360);            
};
Player.prototype.doActions = function(isPressed){
    //if can move
    if(isPressed.up){
        //move Up
        if((this.velocity.y - this.accel.y) >= -this.maxvelocity.y){
            this.velocity.y -= this.accel.y;
        }          
    }
    if(isPressed.down){
        //move Down
        if((this.velocity.y + this.accel.y) <= this.maxvelocity.y){
            this.velocity.y += this.accel.y;
        }

    }
    if(isPressed.left){
        // move Left
        if((this.velocity.x - this.accel.x) >= -this.maxvelocity.x){
            this.velocity.x -= this.accel.x;
        }    
    }
    if(isPressed.right){
        // move Right
        if((this.velocity.x + this.accel.x) <= this.maxvelocity.x){
            this.velocity.x += this.accel.x;
        }  
    }
    if(!isPressed.x &&( isPressed.up || isPressed.down || isPressed.left || isPressed.right)){
        if (Math.abs(this.velocity.x) > 0.01 || Math.abs(this.velocity.y) > 0.01){
            this.rotation = calculateRotation(this.velocity);
        }
    }
};

Player.prototype.boost = function(isPressed){
    if(!isPressed.z){
        if (isPressed.up){
            this.velocity.y = -this.boostProps.velocity;
        }else if(isPressed.down){
            this.velocity.y = this.boostProps.velocity;
        }
        if (isPressed.left){
            this.velocity.x = -this.boostProps.velocity;
        }else if(isPressed.right){
            this.velocity.x = this.boostProps.velocity;
        }
    }
};
Player.prototype.animate = function(screen){ 
    screen.drawRelRotatedImage(this.location.x - 50,
                    this.location.y - 50,
                    'images/guy.png',
                    this.rotation);
};
function calculateRotation(velocity){
    var negativeOffset;
    if(velocity.x < 0){
        negativeOffset = Math.PI
    }else{
        negativeOffset = 0;
    }
    var imageOffset = (Math.PI/2)
    return Math.atan(velocity.y/velocity.x) + imageOffset + negativeOffset;
}