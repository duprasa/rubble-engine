var Box = Entity.subClass({
    init: function(x,y,width,height,color){
        this._super(x,y,height,width,color);
        this.color = "#65435";
        this.collision.fixed = false;
    }
});
Box.prototype.animate = function(screen){ 
    //why is the offset for it to be centered + 10 and -20
    screen.drawRelRotatedRect(this.location.x + 10,
                              this.location.y - 20,
                              10,
                              50,
                              this.rotation,
                              'red');
};