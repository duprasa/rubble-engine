function SocketHandler(socket){




}