/*== IO Handlers Module ==*/

//Status: 2.5 
//This module defines what we do with requests after they
//have been routed here, hence handlers



//Imports
var log      = require('../Utility/Logger').makeInstance("IO Handlers");
var userData = require('../Game Server/Users/UserData');
var gameData = require('../Game Server/Data');
var settings = require('../Settings');

//Module logging.
log.enabled = true;
log.level   = 4;


exports.handlers = {
	playerMove:{queue	: 'single',
				callback:function(data,socket){
					log.debug(data);
					socket.emit('test',data);
				}},
	disconnect:{queue   : true,
				callback:function(data,socket,socketIO){
					log.debug('disconnect');
					var address = socket.handshake.address;
					log.debug('User has disconnected : '+ address.address + ":" + address.port);
					//need reference to socket io to show number of users
					log.debug('number of connected users:' + (Object.keys(socketIO.connected).length - 1));
					
					//clean up user data.
					for(var i in userData.users) {
						if(userData.users[i].socket) {
							if(userData.users[i].socket === socket) {
								userData.users[i].loggedIn = false;
							}
						}
					}
					socket.broadcast.emit('playerLeft',socket.id);
	 			}},
	requestSector:{queue: false,
				callback:function(data,socket){
					socket.emit('sector', gameData.maps);
				}},
	newPlayer:   {queue	: true,
				callback:function(data,socket,socketIO){

				}},
	authRegister:{queue	: false,
				callback:function(data,socket){
					//currently no validation implemented
					socket.emit('validateRegister', true );
				}},
	authGuest: {queue	: false,
				callback:function(data,socket){
					//currently no validation implemented
					var ip = socket.handshake.address.address;
					log.debug('authenticating new Guest from:' + ip)
					socket.emit('validateGuest', true );
				}},
	authUser : {queue : false,
				callback:function(data,socket){
					//Check if nickname has been attempted x times from y ip.
					var ip       = socket.handshake.address.address;
					var status = "NOT_VALID";
					log.debug('username: ' + data.nickname);
					log.debug('password: ' + data.password);
					log.debug('from IP : ' + ip);



					if(userData.users[data.nickname]) {
						log.debug('Nickname: ' + data.nickname + ' exists.');
						if(userData.users[data.nickname].invalidAttempts[ip]) {
							log.debug('User has tried to log in from ip: ' + ip + ' already.' + '(' +userData.users[data.nickname].invalidAttempts[ip] + ') times.' );
							if(userData.users[data.nickname].invalidAttempts[ip] >= settings.loginAttempts) {
								log.debug('invalid attempts over maximum allowed');
								status = "TOO_MANY_ATTEMPTS";
							} else {
								if(userData.users[data.nickname].password == data.password) {
									if(userData.users[data.nickname].loggedIn == true) {
										status = "ALREADY_LOGGED_IN";
									} else {
										userData.users[data.nickname].loggedIn = true;
										userData.users[data.nickname].lastIP = ip;
										userData.users[data.nickname].socket = socket;
										log.debug("validated!");
										status = "VALID";
									}
								}	
							}
						}else if(userData.users[data.nickname].password == data.password) {
							if(userData.users[data.nickname].loggedIn == true) {
								status = "ALREADY_LOGGED_IN";
							} else {
								userData.users[data.nickname].loggedIn = true;
								userData.users[data.nickname].lastIP = ip;
								userData.users[data.nickname].socket = socket;
								log.debug('validated!');
								status = "VALID";
							}
						} else {
							log.debug('Validation failed!')
						}
					}

					if((status == "NOT_VALID" || status == "TOO_MANY_ATTEMPTS") && userData.users[data.nickname]) {
						log.debug('Validation failed.');
						if(userData.users[data.nickname].invalidAttempts[ip]) {
							log.debug('Attempts from ip:  ' + ip +' increased by 1');
							userData.users[data.nickname].invalidAttempts[ip] += 1;
						} else {
							log.debug('Logged the failed attempt on ip: ' + ip);
							userData.users[data.nickname].invalidAttempts[ip] = 1;
						}
					}
					
					
					socket.emit('validateUser', status );
				}},

	authenticateRegister : {queue : false,
				callback:function(data,socket){
					var nickname = data.nickname;
					var password = data.password;
					var email    = data.email;
				}},

	authenticateGuest : {queue : false,
				callback:function(data,socket){
					//Receive nothing.
				}},

};