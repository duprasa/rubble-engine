/*== Game Server Module ==*/

//Status: 2 (needs additions/editing)
//This is the root of the game, it launches the main gameloop.



//Imports
var gameLoop = require("./Loop");
var database = require("./DatabaseAccess");
var log      = require('../Utility/Logger').makeInstance("GameHandler");
var settings = require("../Settings").gameServer;
var mapHandler = require("./Maps/MapHandler");
var mb = require("./Builders/MonsterBuilder");
var ib = require("./Builders/ItemBuilder");
var data = require("./Data");
//Module logging
log.enabled = true;
log.level   = 4;


var initialized = false;


exports.init = function(){

	if(settings.moduleEnabled["GameHandler"] == false) {
		log.debug('Cannot call function init. Module is disabled.');
		return;
	}

	initialized = true;
	log.debug('game server initialized!');
};

//Game Server start
exports.start = function() {

	if(settings.moduleEnabled["GameHandler"] == false) {
		log.debug('Cannot call function start. Module is disabled.');
		return;
	}

	if(!initialized) {
		log.warn('Game Server cannot start without being initialized.');
		return;
	}

	log.info('Game server started');

	//list game modules
	var count = 0;
	var totalCount = 0;
	for(var i in settings.moduleEnabled) {
		totalCount++;
		if(settings.moduleEnabled[i] == true) {
			log.debug(i + " module is enabled.");
			count++;
		}
	}
	log.info("total game modules: " + count + " out of " + totalCount);

	//Initialize all maps
	mapHandler.init(function() {

		var s = mb.create('SLIME');
		var drops = s.getDrops();
		//Make drops return items?
		var itemsObtained = [];
		for(var i in drops) {
			itemsObtained.push(ib.create(drops[i]));
		}

		log.debug(itemsObtained);

		//Begin game loop
		gameLoop.start();

	});
	 

};
