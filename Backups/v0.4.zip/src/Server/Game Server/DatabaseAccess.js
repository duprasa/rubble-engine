/*== Database access Module ==*/

//Status: 0 (To be implemented AND defined)
//The database module is the layer in between the game and
//any sort of persistant datastoring related to players, default
//maps or saving any player progress it also loads such such things.
//It should access a data layer's module to obtain db functionailty


//Imports
var settings = require("../Settings").gameServer;
var data     = require("./Data");
var log      = require('../Utility/Logger').makeInstance("GameDB Access");
var db       = require('../Database/DBHandler');

//Module logging
log.enabled  = true;
log.level    = 3;


exports.load = function(callback) {

	if(settings.moduleEnabled["Database"] == false) {
		callback();
		return;
	}
	
	callback();

}
