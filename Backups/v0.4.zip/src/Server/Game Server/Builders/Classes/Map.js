var logger = require("../../../Utility/Logger");
var settings = require('../../Maps/settings');

function Map (name,mapStructure) {

	//Object logging
	this.log  = logger.makeInstance('Map Object ' + name);
	this.log.level = 3;
	this.log.enabled = true;

	//Object properties
	this.name     = (name || settings.defaultMapName);
	this.width    = mapStructure.width; // in Tiles
	this.height   = mapStructure.height; // in Tiles
	this.tileSize = (mapStructure.tileheight || settings.defaultTileSize);

	this.realWidth  = this.width * this.tileSize;
	this.realHeight = this.height * this.tileSize; 

	this.sectors = [];
	this.sectorSize = settings.sectorSize; // in Tiles

	//Bonus properties for sam
	this.tileSheetWidth  = settings.tileSheetWidth; // in Tiles
	this.tileSheetHeight = settings.tileSheetHeight;// in Tiles

	//Find out how many sectors our map will contain
	this.sectorsWide = Math.ceil(this.width / this.sectorSize);
	this.sectorsLong = Math.ceil(this.height/ this.sectorSize);
	this.sectorCount = this.sectorsWide * this.sectorsLong;

	//Game Data
	this.entities = {
		players : {},
		monsters: {},
		attacks : {},
		others  : {}
	};



	//create a the sectors as well as a tile array in each one.
	for(var b = 0; b < this.sectorCount; b++) {
		var sectorRow = Math.floor(b / this.sectorsWide);
		var sectorCol = Math.floor(b % this.sectorsWide);
		
		
		this.sectors[b] = {
			index : b,
			x     : (sectorCol * this.sectorSize * this.tileSize),
			y     : (sectorRow * this.sectorSize * this.tileSize),
			tiles : [],
			entities : {
				walls    : [],
				monsters : {},
				players  : {},
				items    : {},
				portals  : {},
				attacks  : {},
				others   : {},
			}
		};
		

		for(var t = 0; t < (this.sectorSize * this.sectorSize); t++) {
			var tileRow = Math.floor(t / this.sectorSize);
			var tileCol = Math.floor(t % this.sectorSize);
			
			
			this.sectors[b].tiles[t] = {
				x        : this.sectors[b].x + (tileCol * this.tileSize),
				y        : this.sectors[b].y + (tileRow * this.tileSize),
				graphic : settings.defaultGraphic,
				danger   : settings.defaultDanger
			};
		}
	} 

	//Fill tiles in sectors with data from map file.
	for(var i = 0; i < mapStructure.layers.length;i++) {

		for(var l = 0; l < mapStructure.layers[0].data.length;l++) {
			var row     = Math.floor(l / this.width);
			var col     = l % this.width;
			var sectorY = Math.floor( row / this.sectorSize);
			var sectorX = Math.floor( col / this.sectorSize);

			var sectorIndex = (sectorY * this.sectorsWide) + sectorX;
			var tileIndex   = l - (row * this.width) - (sectorX * this.sectorSize) + (this.sectorSize * (row - (sectorY * this.sectorSize)));
			
			switch(mapStructure.layers[i].name) {
				case "graphic":
					if(settings.physicsOffset < mapStructure.layers[i].data[l]) {
						this.sectors[sectorIndex].tiles[tileIndex].graphic = settings.defaultGraphic;
					} else {
						this.sectors[sectorIndex].tiles[tileIndex].graphic = mapStructure.layers[i].data[l] - settings.graphicOffset;
					}
				break;
				case "physics":
					if(mapStructure.layers[i].data[l] != settings.defaultPhysics) {
						if(settings.dangerOffset < mapStructure.layers[i].data[l] || (mapStructure.layers[i].data[l] - settings.physicsOffset) <= settings.defaultPhysics) {
							//do nothing.
						} else {
							this.sectors[sectorIndex].entities.walls.push({
								x     : this.sectors[sectorIndex].tiles[tileIndex].x,
								y     : this.sectors[sectorIndex].tiles[tileIndex].y,
								width : this.tileSize,
								height: this.tileSize,
								type  :        "WALL",
								wallType : settings.physicsType[mapStructure.layers[i].data[l] - settings.physicsOffset]
			 				});
						}
					}
				break;
				case "danger" :
					if(mapStructure.layers[i].data[l] != settings.defaultDanger) {
						if(settings.monsterSpawnOffset < mapStructure.layers[i].data[l] || (mapStructure.layers[i].data[l] - settings.dangerOffset) <= settings.defaultDanger) {
							this.sectors[sectorIndex].tiles[tileIndex].danger = settings.defaultDanger;
						} else {
							this.sectors[sectorIndex].tiles[tileIndex].danger = mapStructure.layers[i].data[l] - settings.dangerOffset;
						}
					} else {
						this.sectors[sectorIndex].tiles[tileIndex].danger = settings.defaultDanger;
					}
				break;
				case "monsterSpawn":
					if(mapStructure.layers[i].data[l] != settings.defaultMonsterSpawn) {
						if(/* Guard against going over the next layer or.. */ (mapStructure.layers[i].data[l] - settings.monsterSpawnOffset) <= settings.defaultMonsterSpawn) {
							//Do nothing.
						} else {
							this.sectors[sectorIndex].tiles[tileIndex].monsterSpawn = settings.monsterSpawnType[mapStructure.layers[i].data[l] - settings.monsterSpawnOffset];
						}
					}
				break;
				default:
				break;
			}

			
		}

	} 

}
//TODO
//Returns the tile using x and y coordinates.
//needed?
//create local optimized insert function so that it can't be called from the outside(NOT SAFE!)

//Returns the sector object using x and y coordinates.
Map.prototype.getSectorByPosition = function(x,y) {
	if(x >= 0 && x < this.realWidth && y >= 0 && y < this.realHeight) {
		return (this.sectors[((Math.floor( y /(this.sectorSize * this.tileSize)) * this.sectorsWide) + (Math.floor( x / (this.tileSize * this.sectorSize))) )]);
	} else {
		this.log.warn('X or Y are out of bounds, Can\'t get sector.');
		return;
	}
};


function optimalInsertEntity(map,entity,newSector) {
	switch(entity.type) {
		case "PLAYER":
			//Optimized path 
				map.sectors[newSector].entities.players[entity.username] = entity;
				entity.sector = newSector;
				return newSector;
		break;
		case "WALL":
			//Optimized path 
			if(newSector) {
				map.sectors[newSector].entities.walls.push(entity);
				map.log.debug('Inserted Entity of Type "' + entity.type + '" in sector ' + newSector + ' (Opt. Path)');
				return newSector;
			}
		break;
		default:
			map.log.warn('Can\'t insert entity of type "' + entity.type + '", behaviour undefined.');
		break;
	}
}


//Returns the index of the sector in which the entity was inserted.
Map.prototype.insertEntity = function(entity) {
	if(!entity) {
		this.log.warn('No entity given.');
		return;
	}

	if(!entity.type) {
		this.log.warn('Can\'t insert entity if it has no type.');
		return;
	}

	switch(entity.type) {
		case "WALL":
			//Regular path
			if(typeof entity.x === 'number' && typeof entity.y === 'number') {
				var targetSector = this.getSectorByPosition(entity.x, entity.y);
				if(targetSector) {
					targetSector.entities.walls.push(entity);
					//set sector to make sure optimized removeEntity gets called.
					entity.sector = targetSector.index;
					this.log.debug('Inserted Entity of Type "' + entity.type + '" in sector ' + targetSector.index + ' (Regular Path)');
					return targetSector.index;
				} else {
					this.log.warn('X or Y are out of bounds, Can\'t insert entity.');
					return;
				}
			} else {
				this.log.warn('Entity of type "' + entity.type + '" does not have X or Y');
			}
		break;
		case "PLAYER":
			//Regular path
			if(typeof entity.x === 'number' && typeof entity.y === 'number') {
				var targetSector = this.getSectorByPosition(entity.x, entity.y);
				if(targetSector) {
					targetSector.entities.players[entity.username] = entity;
					this.entities.players[entity.username] = entity;
					//set sector to make sure optimized removeEntity gets called.
					entity.sector = targetSector.index;
					this.log.debug('Inserted Entity of Type "' + entity.type + '" in sector ' + targetSector.index + ' (Regular Path)');
					return targetSector.index;
				} else {
					this.log.warn('X or Y are out of bounds, Can\'t insert entity.');
					return;
				}
			} else {
				this.log.warn('Entity of type "' + entity.type + '" does not have X or Y');
			}
		break;
		default:
			this.log.warn('Can\'t insert entity of type "' + entity.type + '", behaviour undefined.');
		break;
	}
};


//Returns the removed entity if successful.
//Optionally optimized if entity has a 'sector' property
Map.prototype.removeEntity = function(entity) {
	
	if(!entity) {
		this.log.warn('No entity given.');
		return;
	}

	if(!entity.type) {
		this.log.warn('Can\'t remove entity if it has no type.');
		return;
	}

	switch(entity.type) {
		case "PLAYER":
			//Optimized path
			if(typeof entity.sector === 'number') {
				if(this.sectors[entity.sector]) {
					delete this.sectors[entity.sector].entities.players[entity.username];
					delete this.entities.players[entity.username];
					this.log.debug('Removed Entity of Type "' + entity.type + '" in sector ' + entity.sector + ' (Opt. removal)');
					entity.sector = null;
					return;
				}
				this.log.warn('Entity of type "' + entity.type + '" has an empty property "sector", not running optimized code for removal.');
			}
			//Regular path
			if(typeof entity.x === 'number' && typeof entity.y === 'number') {
				var targetSector = this.getSectorByPosition(entity.x, entity.y);
				if(targetSector) {
					delete targetSector.entities.players[entity.username];
					this.log.debug('Removed Entity of Type "' + entity.type + '" in sector ' + targetSector.index + ' (Slow removal)');
					return;
				} else {
					this.log.warn('X or Y are out of bounds, Can\'t remove entity.');
					return;
				}
			} else {
				this.log.warn('Entity of type "' + entity.type + '" does not have X or Y');
			}
		break;
		case "WALL":
			//Optimized path
			if(typeof entity.sector === 'number') {
				if(this.sectors[entity.sector]) {
					var removedEntity = this.sectors[entity.sector].entities.walls.splice(index,1);
					this.log.debug('Removed Entity of Type "' + entity.type + '" in sector ' + entity.sector + ' (Opt. removal)');
					entity.sector = null;
					return removedEntity;
				}
				this.log.warn('Entity of type "' + entity.type + '" has an empty property "sector", not running optimized code for removal.');
			}
			//Regular path
			if(typeof entity.x === 'number' && typeof entity.y === 'number') {
				var targetSector = this.getSectorByPosition(entity.x, entity.y);
				if(targetSector) {
					for(var index in targetSector.entities.walls) {
						if(targetSector.entities.walls[index] === entity) {
							var removedEntity = targetSector.entities.walls.splice(index,1);
							this.log.debug('Removed Entity of Type "' + entity.type + '" in sector ' + targetSector.index + ' (Slow removal)');
							return removedEntity;
						}
					}
					this.log.warn('Entity cannot be found in sector ' +  targetSector.index);
					return;
				} else {
					this.log.warn('X or Y are out of bounds, Can\'t remove entity.');
					return;
				}
			} else {
				this.log.warn('Entity of type "' + entity.type + '" does not have X or Y');
			}
		break;
		default:
			this.log.warn('Can\'t remove entity of type "' + entity.type + '", behaviour undefined.');
		break;
	}
};


//Checks if entity needs to be changed sectors.
Map.prototype.update = function() {
	for(var p in this.entities.players) {
		var newSector = this.getSectorByPosition(this.entities.players[p].x, this.entities.players[p].y).index;
		if(typeof this.entities.players[p].sector === 'number' &&
		    newSector === this.entities.players[p].sector ) {
			//Nothing changed! best case scenario!
			this.log.debug('Player has a sector already and is still in same sector!');
		} else {
			var temp = this.entities.players[p];
			this.removeEntity(this.entities.players[p]);
			optimalInsertEntity(this,temp,newSector);
			this.entities.players[p] = temp;
		}
	}
	
};

module.exports = Map;
