var log = require('../../../../Utility/Logger').makeInstance('Abstract Monster');

function AbstractMonster() {

}

AbstractMonster.prototype.type = 'MONSTER';
AbstractMonster.prototype.drops = {};


AbstractMonster.prototype.setId = function() {
	this.id = uniqueMonsterId.id;
	uniqueMonsterId.id++;
}

AbstractMonster.prototype.getDrops = function() {
	var drops = [];
	for(var i in this.drops) {
		var roll = Math.random() * 100;
		if(this.drops[i] >= roll) {
			drops.push(i);
		}
	}
	return drops;
}

var uniqueMonsterId = { id : 0 };


var defaultMon = new AbstractMonster();
module.exports = defaultMon;

