var abstractMonster  = require('./AbstractMonster');

function Slime() {
	this.monsterType = "SLIME";

	this.hp  = 50;
	this.atk = 3;
	this.spd = 3;
	this.def = 3;
	this.lvl = 2; //This should be calculated from stats universally.

	//Drops is an array of ->  { ItemName : chanceOfDrop on 100% }
	this.drops = {
		"SLIME_REMAINS" : 90,
		"STICK"         : 50,
	}

	this.attacks = {}; 
}

Slime.prototype = abstractMonster;

module.exports = Slime;