var abstractItem  = require('./AbstractItem');

function SlimeRemains() {
	this.itemType = "COLLECTABLE";

	this.desc  = "Remains from a defeated slime, if you inspect" +
	            " it closely you can feel the sadness of the"   +
	            "misunderstood slime.";
}

SlimeRemains.prototype = abstractItem;

module.exports = SlimeRemains;