function AbstractItem() {

}

AbstractItem.prototype.type = 'ITEM';
AbstractItem.prototype.desc = 'A nameless item.';
AbstractItem.prototype.bonus = {};

AbstractItem.prototype.setId = function() {
	this.id = uniqueItemId.id;
	uniqueItemId.id++;
}


var uniqueItemId = { id : 0 };


var defaultItem = new AbstractItem();
module.exports = defaultItem;

