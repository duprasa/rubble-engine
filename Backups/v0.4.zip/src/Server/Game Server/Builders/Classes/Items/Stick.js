var abstractItem  = require('./AbstractItem');

function Stick() {
	this.itemType = "WEAPON";
	this.weaponType = "MELEE";

	this.bonus = {
		"ATK" : -1,
		"DEF" : 1,
		"STR" : 1,
	};

	this.desc = "Probably the lamest weapon in the game.";
}

Stick.prototype = abstractItem;

module.exports = Stick;