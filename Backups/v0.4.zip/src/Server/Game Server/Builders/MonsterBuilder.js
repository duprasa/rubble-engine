//Imports
var monsterIndex = require('./MonsterIndex');
var log          = require('../../Utility/Logger').makeInstance('Monster Builder');

exports.create = function(monsterName) {
	var monster = new monsterIndex[monsterName];
	monster.setId();
	monster.setId = alreadySetId;
	return monster;
};

function alreadySetId() {
	log.warn('Already set Monster Id');
}

