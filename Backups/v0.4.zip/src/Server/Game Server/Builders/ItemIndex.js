module.exports = {
	"STICK" : require('./Classes/Items/Stick'),
	"SLIME_REMAINS" : require('./Classes/Items/SlimeRemains'),
};