module.exports = {
	"SLIME" : require('./Classes/Monsters/Slime'),
};