//Imports
var itemIndex = require('./ItemIndex');
var log       = require('../../Utility/Logger').makeInstance('Item Builder');

exports.create = function(itemName) {
	
	var item = new itemIndex[itemName];
	item.setId();
	item.setId = alreadySetId;
	return item;
};

function alreadySetId() {
	log.warn('Already set Item Id');
}

