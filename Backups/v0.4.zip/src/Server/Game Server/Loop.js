/*== Game Loop Module ==*/

//Status: 1 (needs to be implemented AND defined)
//This module decides when to use other modules to validate gameData
//or alter the game, it is the heart of the game server and decides what
//the game actually does.



//Imports
var settings = require("../Settings").gameServer;
var log      = require('../Utility/Logger').makeInstance("GameLoop");
var physics         = require("./Game Logic Modules/Physics");
var collisionEvents = require("./Game Logic Modules/CollisionEvents");
var monsterSpawner  = require("./Game Logic Modules/MonsterSpawner");
var clientUpdates   = require("./IO/ClientUpdates");
var clientEvents    = require("./IO/ClientEvents");
//for testing to be removed
var ioHandler = require('../IO Server/IOHandler');


//Module logging
log.enabled = true;
log.level   = 4;


var looping = false;


exports.start = function() {
	if(settings.moduleEnabled["Loop"] == false) {
		return;
	}
	looping = true;
	monsterSpawner.init();
	loop();
};

exports.pause = function() {
	looping = false;
};

function loop() {
	if(!looping){
		return;
	}

	var startTime = Date.now();
	
	clientEvents.update();
	var collisions = physics.update();
	collisionEvents.update(collisions);
	monsterSpawner.update();
	clientUpdates.update();
	
	if(Date.now() - startTime > (1000 / settings.FPS)) {
		log.warn("Server Game loop running slow.");
	}
	//Go through some more logic modules.
	setTimeout(loop,1000/ settings.FPS);
};


