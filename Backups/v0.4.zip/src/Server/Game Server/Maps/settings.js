
module.exports = {
	maps: [
		'test',
		'test2'
	],
	//Dimensions of sectors in tiles.
	sectorSize : 10, // in tiles of size : (defaultTileSize)
	defaultTileSize : 32,
	defaultMapName  : "Unnamed",
	//Defaults for tile settings.
	defaultGraphic : 0,
	defaultDanger  : 0,
	defaultMonsterSpawn : 0,
	defaultPhysics      : 0,
	//offsets because of tiled map editor..
	graphicOffset      :   0,
	physicsOffset      : 192,
	dangerOffset       : 292,
	monsterSpawnOffset : 392,
	//some graphic tilesheet info
	tileSheetWidth     : 16,
	tileSheetHeight    : 12,
	//type definition.
	physicsType : {
		"1"  : "SOLID_WALL",
		"11" : "HALF_WALL"
	},

	monsterSpawnType   : {
		"0" : null,
		"1" : "SLIME",
		"2" : "BLUE_SLIME",
		"3" : "MOVING_TREE",
		"4" : "BAT",
	}
};