/*== Monster Spawner Module ==*/

//Status: -1 (Empty as fuck)
//This decides when and where to spawn monsters as well as which kind
//It can keep track of regions where monsters are killed them most, etc
//for statistics or its own use.



//Imports
var rules    = require("../BusinessRules");
var settings = require("../../Settings").gameServer;
var log      = require('../../Utility/Logger').makeInstance("Monster Spawner");
var data     = require("../Data");


//Module logging
log.enabled = true;
log.level   = 3;


var initialized = false;
var mapMonsters = [];

exports.init = function() {
	// if(initialized) {
	// 	log.warn('Already initialized.');
	// 	return;
	// }

	// for(var i in data.maps) {
	// 	mapMonsters[i] = { capacity: (data.maps[i].sectorCount * 3),
	// 					   current: 0,
	// 					   needsSpawning : true };
	// }
	// initialized = true;
};


exports.update = function() {
	// if(!initialized) {
	// 	return;
	// }
	// if(settings.moduleEnabled["MonsterSpawner"] == false) {
	// 	return;
	// }

	// for(var m in data.maps) {
		
	// 	if(mapMonsters[m].needsSpawning) {
	// 		log.debug('Spawning Monsters!');
	// 		for(var i = mapMonsters[m].current; i < mapMonsters[m].capacity; i++) {
	// 			var newMonster = {}; //Should use new Monster() instead which creates a new ID for monster.
	// 			newMonster.x = Math.floor(Math.random() * data.maps[m].realWidth);
	// 			newMonster.y = Math.floor(Math.random() * data.maps[m].realHeight);
	// 			data.maps[m].getSectorByPosition(newMonster.x, newMonster.y).entities.monsters.push(newMonster);
	// 			mapMonsters[m].current += 1;
	// 		}
	// 		log.debug('Done Spawning Monsters.');
	// 		mapMonsters[m].needsSpawning = false;
	// 	}
	// }
	
};

//Verifies if any map needs spawning 
// setInterval(function () {
// 	for(var m in data.maps) {
// 		if(mapMonsters[m]) {
// 			if(mapMonsters[m].current < mapMonsters[m].capacity) {
// 				mapMonsters[m].needsSpawning = true;
// 				log.debug('Map: ' + m + ' needs spawning!');
// 			} else {
// 				log.debug('Map: ' + m + ' does not need spawning.');
// 			}
// 		}
// 	}
// },settings.monsterSpawnRate * 1000);



//Test which destroys a sector of monsters every 10 seconds.
// setInterval(function() {
// 	for(var m in data.maps) {
// 		if(mapMonsters[m]) {
// 			if(mapMonsters[m].current = mapMonsters[m].capacity) {
// 				var sectorToKill = Math.floor(Math.random() * data.maps[m].sectorCount);
// 				if(data.maps[m].sectors[sectorToKill].entities.monsters.length != 0) {
// 					for(var f in data.maps[m].sectors[sectorToKill].entities.monsters) {
// 						data.maps[m].sectors[sectorToKill].entities.monsters.splice(f,1);
// 						mapMonsters[m].current -= 1;
// 						log.debug('Killed a Monster.');
// 					}
// 					log.debug('Eradicated Monsters in sector: ' + sectorToKill);
// 				}
// 			}
// 		}	
// 	}
// },10000);


