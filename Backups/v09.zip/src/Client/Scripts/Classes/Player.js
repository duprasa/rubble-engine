define(function(){
    var Player = function(x,y,rotation,nickname){
        this.x = x || 10;
        this.y = y || 10;
        this.radius = 15; //this should be sent from server
        this.imageRadius = 20; // this should be sent from server
        this.rotation = rotation || 0;
        this.offset = (this.imageRadius - this.radius); // offset if image is different size than the hittest radius
        this.velocity = {x:0,
                         y:0};
        this.vx = 0;
        this.vy = 0;
        this.nickname = nickname || 'no player name entered';
        this.items = {};
        this.sector = null;
        this.dangerLevel = 0; //this should be sent from server
        this.floorItems = []; //list of items under the player
        this.stats = {} // this is sent from server
        //CONSTANTS
        this.maxVelocity = {x:4,
                            y:4};
        this.accel ={x:20,
                     y:20};
        this.friction ={x:0.07,
                     y:0.07};
    };

    Player.prototype.move = function(){
        //move Player
        if (this.vx){
            this.x += this.vx;
            //friction velocity
            var tempVX = this.vx;
            if(this.vx > 0){
                this.vx -= this.friction.x;
            }else{
                this.vx += this.friction.x;
            }
            if(tempVX * this.vx < 0){
                this.vx = 0;
            }
        }
        if (this.vy){
            this.y += this.vy;
            //friction velocity
            var tempVY = this.vy;
            if(this.vy > 0){
                this.vy -= this.friction.y;
            }else{
                this.vy += this.friction.y;
            }
            if(tempVY * this.vy < 0){
                this.vy = 0;
            }
        }
    };

    Player.prototype.onCollision = function(wall,direction){
        //Default Collision behavior used with Player and Box
        var newlocation;
        switch(direction){
            case 'x':
                this.vx = 0;
                break;
            case 'y':             
                this.vy = 0;
                break;
        }
    };
    Player.prototype.setRotation = function(angle){
        this.rotation = Math.abs(this.rotation % 360);            
    };
    Player.prototype.doActions = function(keysPressed){
        //if can move
        if(keysPressed.up){
            //move Up
            if((this.vy - this.accel.y) >= -this.maxVelocity.y){
                this.vy -= this.accel.y ;
            }else{
                this.vy = -this.maxVelocity.y;
            }
            this.friction.y = 0
        }else if(keysPressed.down){
            //move Down
            if((this.vy + this.accel.y ) <= this.maxVelocity.y ){
                this.vy += this.accel.y ;
            }else{
                this.vy = this.maxVelocity.y ;
            }
            this.friction.y = 0

        }else{
            this.friction.y = 1 ;
        }
        if(keysPressed.left){
            // move Left
            if((this.vx - this.accel.x ) >= -this.maxVelocity.x ){
                this.vx -= this.accel.x ;
            }else{
                this.vx = -this.maxVelocity.x ;
            }    
            this.friction.x = 0;
        }else if(keysPressed.right){
            // move Right
            if((this.vx + this.accel.x) <= this.maxVelocity.x){
                this.vx += this.accel.x;
            }else{
                this.vx = this.maxVelocity.x;
            }
            this.friction.x = 0;
        }else{
            this.friction.x = 1;
        }
        if(!keysPressed.lockDirection &&( keysPressed.up || keysPressed.down || keysPressed.left || keysPressed.right)){
            if (Math.abs(this.vx) > 0.01 || Math.abs(this.vy) > 0.01){
                //calculate rotation
                var negativeOffset; // determine if rotated left or right
                if(this.vx < 0){
                    negativeOffset = Math.PI;
                }else{
                    negativeOffset = 0;
                }
                var imageOffset = (Math.PI/2);//because rotation 0 is on right and not on top like the player image
                this.rotation = Math.atan(this.vy/this.vx) + imageOffset + negativeOffset;
            }
        }
    };
    Player.prototype.animate = function(screen){ 
        screen.drawRelRotatedImage(this.x - this.radius - this.offset,
                        this.y - this.radius- this.offset + 6,
                        'images/guy2Shadow.png',
                        this.rotation);
        screen.drawRelCircle(this.x,this.y,this.radius + 1,'#996633');
        screen.drawRelRotatedImage(this.x - this.radius- this.offset,
                        this.y - this.radius- this.offset,
                        'images/guy2.png',
                        this.rotation);
    };
    return Player;
});