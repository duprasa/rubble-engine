'use strict';
define({
	 testBrowser:function(){
			if(typeof(Audio) === 'undefined') {
				return false;
			}
			if(!(new Audio().canPlayType)) {
				return false;
			}
			return true;
		}
});