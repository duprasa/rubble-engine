'use strict';
define(['game/data'],function(gameData){
	function MenuManager(){
		this.selectorPosition = 0;
		this.selectedPosition = null;
		this.hasFocus = false;
		this.focus = function(){
			this.hasFocus = true;
		};
		this.blur = function(){
			this.hasFocus = false;
		};
		this.showFocus = function(){
			console.log(this.hasFocus);
		};
		this.moveSelector = function(direction){
			switch(direction){
				case 'up':
					if(this.selectorPosition === 5 || this.selectorPosition === 6 || this.selectorPosition === 7){
						this.selectorPosition -= 5;
					}
					if(this.selectorPosition > 7){
						this.selectorPosition -= 6;
					}
					
					break;
				case 'down':
					if(this.selectorPosition < 3){
						this.selectorPosition +=5;
					}else{
						if(gameData.player.floorItems.length){
							if(this.selectorPosition < 47){
								this.selectorPosition += 6;
							}
						}else{
							if(this.selectorPosition < 23){
								this.selectorPosition += 6;
							}
						}
					}
					break;
				case 'left':
					if(this.selectorPosition >= 1){
						this.selectorPosition -=1;
					}
					break;
				case 'right':
					if(gameData.player.floorItems.length){
						if(this.selectorPosition < 52){
								this.selectorPosition += 1;
						}
					}else{
						if(this.selectorPosition < 28 ){
							this.selectorPosition +=1;
						}
					}
					break;
				default:
					throw('invalid direction!');
					break;
			}
		};

		this.swapItems = function(){
			if(this.selectedPosition === null){
				this.selectedPosition = this.selectorPosition;
			}else{
				if(this.selectedPosition === this.selectorPosition){
					console.log('not swaping item with itself')
					this.selectedPosition = null;
					return;
				}
				if(this.selectedPosition <= 28 && this.selectorPosition > 28){
					//drop item
					if(gameData.player.items[this.selectedPosition] !== null){
						gameData.updateServerData.itemChanges.push({"DROPPED":this.selectedPosition});
						//gameData.player.items[this.selectedPosition] = null;
						console.log('dropped item');
					}
					//pick up item
					if(gameData.player.floorItems[this.selectorPosition- 29] !== undefined){
							console.log('pick up item');
							gameData.updateServerData.itemChanges.push({"PICKUP":{item:gameData.player.floorItems[this.selectorPosition- 29],
																				  menuPosition:this.selectedPosition}});
					}
					
					this.selectedPosition = null;
 
				}else if(this.selectedPosition > 28 && this.selectorPosition > 28){
					//do nothing
					this.selectedPosition = null;

				}else if(this.selectedPosition > 28 && this.selectorPosition <= 28){
					//drop item
					if(gameData.player.items[this.selectorPosition] !== null){
						gameData.updateServerData.itemChanges.push({"DROPPED":this.selectorPosition});
						//gameData.player.items[this.selectorPosition] = null;
						console.log('dropped item');
					}
					//pick up item
					if(gameData.player.floorItems[this.selectedPosition - 29] !== undefined){
						console.log('pick up item');
						gameData.updateServerData.itemChanges.push({"PICKUP":{item:gameData.player.floorItems[this.selectedPosition- 29],
																			  menuPosition:this.selectorPosition}});
					}
					this.selectedPosition = null;
				}else{
					//switch items
					var tempItem = gameData.player.items[this.selectedPosition];
					//gameData.player.items[this.selectedPosition] = gameData.player.items[this.selectorPosition];
					//gameData.player.items[this.selectorPosition] = tempItem;
					var switchedObject = {};
					switchedObject[this.selectedPosition] = this.selectorPosition;
					gameData.updateServerData.itemChanges.push({"SWITCHED":switchedObject});
					console.log('switched items');
					this.selectedPosition = null;
				}
			}
		};
		this.update = function(){
		};
		this.dropItem = function(){
			if(gameData.player.items[this.selectorPosition] != null){
				gameData.updateServerData.itemChanges.push({"DROPPED":this.selectorPosition});
				//gameData.player.items[this.selectorPosition] = null;
			}
		}
		this.animate = function(screen){
			var selectorImg,x,y,itemOffset,selectedImg;
			
			//draw danger meter
			var color = '#E6E600';
			if(gameData.player.dangerLevel > 80){
				color = '#0000FF';
			}else if(gameData.player.dangerLevel > 70){
				color = '#660066';
			}else if(gameData.player.dangerLevel > 60){
				color = '#FF33CC';
			}else if(gameData.player.dangerLevel > 50){
				color = '#FF0066';
			}else if(gameData.player.dangerLevel > 40){
				color = '#FF0000';
			}else if(gameData.player.dangerLevel > 30){
				color = '#B20000';
			}else if(gameData.player.dangerLevel > 20){
				color = '#FF3300';
			}else if(gameData.player.dangerLevel > 10){
				color = '#991F00';
			}
			screen.drawRect(2,842 - (gameData.player.dangerLevel / 100) *832 ,15,(gameData.player.dangerLevel / 100) *832,color); // 100 is danger level cap
			//draw top stats
			color = 'green';
			if(gameData.player.stats.level > 80){
				color = '#6600CC';
			}else if(gameData.player.stats.level > 70){
				color = '#FF0000';
			}else if(gameData.player.stats.level > 60){
				color = '#FF3300';
			}else if(gameData.player.stats.level > 50){
				color = '#FFCC00';
			}else if(gameData.player.stats.level > 40){
				color = '#CCFF33';
			}else if(gameData.player.stats.level > 30){
				color = '#66FF33';
			}else if(gameData.player.stats.level > 20){
				color = '#00FF99';
			}else if(gameData.player.stats.level > 10){
				color = '#0099FF';
			}
			screen.drawText(42,45,gameData.player.stats.level,'30px Arial bold',color);
			screen.drawText(102,45,gameData.player.nickname,'30px Arial bold','white');
			screen.drawText(102,198,gameData.player.stats.playersKilled,'30px Arial bold','white');
			screen.drawText(300,198,gameData.player.stats.monstersKilled,'30px Arial bold','white');
			screen.drawText(102,238,gameData.player.stats.playersKilled /(gameData.player.stats.deaths || 1),'30px Arial bold','white');
			screen.drawRect(42,57,(gameData.player.stats.exp /gameData.player.stats.nextLevelXP) * 356 ,30,'blue'); // dont know calculation
			screen.drawText(45,80,'XP  ' + Math.floor(gameData.player.stats.exp),'20px Arial bold','white');
			screen.drawRect(42,96,(gameData.player.stats.HP / gameData.player.stats.maxHP) * 356,30,'red');
			screen.drawText(45,119,'HP  ' + Math.floor(gameData.player.stats.HP) + '/' + gameData.player.stats.maxHP,'20px Arial bold','white');
			screen.drawRect(42,135,(gameData.player.stats.AP / gameData.player.stats.maxAP) * 356,30,'#FFCC00');
			screen.drawText(45,158,'AP  ' + Math.floor(gameData.player.stats.AP) + '/' + gameData.player.stats.maxAP,'20px Arial bold','white');


			//draw bottom stats // NEED TO ADD BONUS FROM EQUIPED ITEMS
			screen.drawText(118,648,gameData.player.stats.STR,'30px Arial bold','white');
			screen.drawText(118,703,gameData.player.stats.DEX,'30px Arial bold','white');
			screen.drawText(118,759,gameData.player.stats.SPD,'30px Arial bold','white');
			screen.drawText(118,812,gameData.player.stats.VUL,'30px Arial bold','white');

			screen.drawText(320,648,gameData.player.stats.DEF,'30px Arial bold','white');
			screen.drawText(320,703,gameData.player.stats.STA,'30px Arial bold','white');
			screen.drawText(320,759,gameData.player.stats.AGL,'30px Arial bold','white');
			screen.drawText(320,812,gameData.player.stats.LUK,'30px Arial bold','white');

			//draw item overlay
			if(gameData.player.floorItems.length){
				screen.drawImage(20,597,'images/menuItemOverlay.png');
			}

			if(this.hasFocus){
				//draw selected position
				if(this.selectedPosition !== null){
					if(this.selectedPosition < 5){
						x = 20 + 80 * this.selectedPosition;
						y = 261;
						selectedImg = 'images/selectedBig.png'; 
					}else if(this.selectedPosition < 29){
						x = 40 + 60 * ((this.selectedPosition -5) % 6)
						y = 348 + 60 * (Math.floor((this.selectedPosition -5) / 6))
						selectedImg = 'images/selectedSmall.png';
					}else{
						x = 40 + 60 * ((this.selectedPosition -5) % 6)
						y = 359 + 60 * (Math.floor((this.selectedPosition -5) / 6))
						selectedImg = 'images/selectedSmall.png';
					}
					screen.drawImage(x,y,selectedImg);
				}
				//draw selector
				if(this.selectorPosition < 5){
					x = 20 + 80 * this.selectorPosition;
					y = 261;
					selectorImg = 'images/selectorBig.png'; 
				}else if(this.selectorPosition < 29){
					x = 40 + 60 * ((this.selectorPosition -5) % 6)
					y = 348 + 60 * (Math.floor((this.selectorPosition -5) / 6))
					selectorImg = 'images/selectorSmall.png';
				}else{
					x = 40 + 60 * ((this.selectorPosition -5) % 6)
					y = 359 + 60 * (Math.floor((this.selectorPosition -5) / 6))
					selectorImg = 'images/selectorSmall.png';
				}
				screen.drawImage(x,y,selectorImg);
			}else{
				this.selectedPosition = null;
				this.selectorPosition = 2;
			}

			//draw Items in inventory
			for(var itemIndex in gameData.player.items){
				if(gameData.player.items[itemIndex]){
					if(itemIndex < 5){
						x = 20 + 80 * (itemIndex);
						y = 261;
						itemOffset = 16; 
					}else{
						x = 40 + 60 * ((itemIndex -5) % 6)
						y = 348 + 60 * (Math.floor((itemIndex -5) / 6))
						itemOffset = 6;
					}
					screen.drawImage(x + itemOffset,
									 y + itemOffset,
									 gameData.itemInfo.imagePath,
									 (gameData.itemInfo.items[gameData.player.items[itemIndex].itemType].imageIndex % gameData.itemInfo.tilesWide) * gameData.itemInfo.tileSize,
									 Math.floor(gameData.itemInfo.items[gameData.player.items[itemIndex].itemType].imageIndex / gameData.itemInfo.tilesWide) * gameData.itemInfo.tileSize,
									 gameData.itemInfo.tileSize,
									 gameData.itemInfo.tileSize);
				}
			}
			//draw items in floor menu
			for(var itemIndex in gameData.player.floorItems){
				x = 40 + 60 * ((itemIndex) % 6)
				y = 600 + 60 * (Math.floor((itemIndex) / 6))
				itemOffset = 6;
				// screen.drawRect(10,10,gameData.itemInfo.tileSize,gameData.itemInfo.tileSize,'red');
				
				screen.drawImage(x + itemOffset,
								 y + itemOffset,
								 gameData.itemInfo.imagePath,
								 (gameData.itemInfo.items[gameData.player.floorItems[itemIndex].itemType].imageIndex % gameData.itemInfo.tilesWide) * gameData.itemInfo.tileSize,
								 Math.floor(gameData.itemInfo.items[gameData.player.floorItems[itemIndex].itemType].imageIndex / gameData.itemInfo.tilesWide) * gameData.itemInfo.tileSize,
								 gameData.itemInfo.tileSize,
								 gameData.itemInfo.tileSize);
			}
		};
	}
	return new MenuManager();
});
		// var data = {
		// 	selectorPosition : 0;
		// 	hasFocus : false;
		// };	
		// return {
		// 	focus:function(){
		// 			data.hasFocus = true;
		// 			//set cursor to first slot
		// 			data.selectorPosition = 0;
		// 		},
		// 	blur:function(){
		// 			data.hasFocus = false;
		// 		},
		// 	moveSelector:function(direction){
		// 			switch(direction){
		// 				case 'up':
		// 					break;
		// 				case 'down':
		// 					break;
		// 				case 'left':
		// 					data.selectorPosition -=1;
		// 					break;
		// 				case 'right':
		// 					data.selectorPosition +=1;
		// 					break;
		// 				default:
		// 					throw('invalid direction!');
		// 					break;
		// 			}
		// 			return data.selectorPosition;
		// 		},
		// 	animate:function(screen){
		// 		var selectorImg,x,y;
		// 		if(data.hasFocus){
		// 			console.log(data.selectorPosition);
		// 			if(data.selectorPosition <= 5){
		// 				x = 12 + 80 * data.selectorPosition;
		// 				y = 261;
		// 				selectorImg = 'images/selectorBig.png'; 
		// 			}else{
		// 				x = 32 + 60 * (data.selectorPosition % 6)
		// 				y = 348 + 60 * (Math.floor(data.selectorPosition / 6))
		// 				selectorImg = 'images/selectorSmall.png';
		// 			}
		// 			screen.drawImage(x,y,selectorImg);
		// 		}else{
		// 			console.log(data.hasFocus);
		// 			screen.clear();
		// 		}
		// 	}

		// };