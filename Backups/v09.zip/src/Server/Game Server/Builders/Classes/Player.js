var ib = require('../ItemBuilder');
var data = require('../../Data');
function Player(x,y,rotation,nickname){
	 

        this.nickname = nickname || 'no nickname entered';
        this.new = true;
        this.x = (x || 240);
        this.y = (y || 60);
        this.radius = 15;
        this.rotation = rotation || 0;
        this.sector = null;
        this.map = null;
        this.type = 'PLAYER';
        this.dangerLevel = 0;
        
        //
        this.teleported = false;
        this.recentDamage = [];
        //This does not need to be in client.
        this.damageTaken = {};
        //Generic cooldown in between abilities
        this.cooldown = 250;


        this.stats = {
          level: 1,
          exp : 30,
          nextLevelXP: 300,
          STR : 1, // damage delt (adds damage)
          DEF : 1, // minus damage received
          DEX : 1, // increase rate of AP recovery
          STA : 1, // increate rate of HP recovery
          SPD : 1, // faster movement
          AGL : 1, // increases acceleration
          VUL : 1, // decrease vulnarability time
          LUK : 1, // increases drop luck
          HP : 50,
          AP : 11,
          maxHP : 50,
          maxAP : 50,     
          playersKilled:0,
          monstersKilled:0,
          deaths:0
        };
        this.items = {0:ib.create('SLIME_REMAINS'),
                      1:ib.create('SLIME_REMAINS'),
                      2:ib.create('STICK'),
                      3:ib.create('SLIME_REMAINS'),
                      4:ib.create('SLIME_REMAINS'),
                      5:ib.create('SLIME_REMAINS'),
                      6:ib.create('SLIME_REMAINS'),
                      7:ib.create('SLIME_REMAINS'),
                      8:ib.create('SLIME_REMAINS'),
                      9:ib.create('STICK'),
                      10:null,
                      11:ib.create('SLIME_REMAINS'),
                      12:ib.create('SLIME_REMAINS'),
                      13:ib.create('SLIME_REMAINS'),
                      14:ib.create('SLIME_REMAINS'),
                      15:ib.create('SLIME_REMAINS'),
                      16:ib.create('SLIME_REMAINS'),
                      17:ib.create('SLIME_REMAINS'),
                      18:null,
                      19:ib.create('SLIME_REMAINS'),
                      20:ib.create('SLIME_REMAINS'),
                      21:ib.create('SLIME_REMAINS'),
                      22:null,
                      23:ib.create('SLIME_REMAINS'),
                      24:ib.create('SLIME_REMAINS'),
                      25:ib.create('SLIME_REMAINS'),
                      26:ib.create('SLIME_REMAINS'),
                      27:ib.create('SLIME_REMAINS'),
                      28:ib.create('SLIME_REMAINS')};
}
Player.prototype.levelUp = function(){
        //use a formula to distribute levels to skills
};
Player.prototype.die = function() {

  var biggestDamage = { player : false ,damage : 0 };
  for(var nickname in this.damageTaken) {

    //give % of exp based on dmg / maxHP 
    //TODO: Allies
    
    if(data.players[nickname]) {
      data.players[nickname].stats.exp += Math.floor(this.stats.exp * Math.floor(this.damageTaken[nickname] / this.stats.maxHP));
      
    } else {
      //Player is no longer there...
    }

    if(this.damageTaken[nickname] > biggestDamage.damage) {
      biggestDamage.player = nickname;
      biggestDamage.damage = this.damageTaken[nickname];
    }

  }
  for(var i in this.items) {
    if(this.items[i]) {
      if(data.players[biggestDamage.player]) {
        this.items[i].owner = biggestDamage.player;
      } else {
        this.items[i].owner = false;
      }
      this.items[i].x = this.x;
      this.items[i].y = this.y;
      data.maps[this.map].insertEntity(this.items[i]);
      this.items[i] = null;
    }
  }

  //PLAYER HAS TO DIE HERE.
  this.stats.exp = 0;
  this.stats.deaths += 1;
  if(data.players[biggestDamage.player]) {
    data.players[biggestDamage.player].stats.playersKilled += 1;
    data.maps[this.map].sectors[this.sector].newMessages.push({nickname:'',message: ('>> ' + biggestDamage.player + ' killed ' + this.nickname)});
  } else {
    if(data.monsters[biggestDamage.player]) {
      var name = data.monsters[biggestDamage.player].monsterType;
      data.maps[this.map].sectors[this.sector].newMessages.push({nickname:'',message: ('>> ' + this.nickname + ' was killed by a ' + name)});
    }
  }
  this.stats.HP = this.stats.maxHP;
  this.stats.AP = this.stats.maxAP;


  this.x = 500;
  this.y = 400;
  this.teleported = true;
  data.maps[this.map].removeEntity(this);
  data.maps['tutorial'].insertEntity(this);
  if(data.players[biggestDamage.player]) {
    data.players[biggestDamage.player].stats.playersKilled += 1;
    data.maps[this.map].sectors[this.sector].newMessages.push({nickname:'',message: ('>> ' + biggestDamage.player + ' killed ' + this.nickname)});
  } else {
    if(data.monsters[biggestDamage.player]) {
      var name = data.monsters[biggestDamage.player].monsterType;
      data.maps[this.map].sectors[this.sector].newMessages.push({nickname:'',message: ('>> ' + this.nickname + ' was killed by a ' + name)});
    }
  }

  this.old = false;
};

Player.prototype.update = function() {
  if(this.new) {
    this.new = false;
  }

  if(this.old) {
    this.die();
    return;
  }

  if(this.teleported) {
    this.teleported = false;
  }

  this.recentDamage = [];
  
  //HP REFILLS
  if(this.stats.HP < this.stats.maxHP) {
    this.stats.HP += (this.stats.STA / 20);
    if(this.stats.HP >= this.stats.maxHP) {
      this.stats.HP = this.stats.maxHP;
      this.damageTaken = {};
    }
  }
  //AP REFILLS
  if(this.stats.AP < this.stats.maxAP) {
    this.stats.AP += (this.stats.DEX / 5);
    if(this.stats.AP > this.stats.maxAP) {
      this.stats.AP = this.stats.maxAP;
    }
  }
 
  //COOLDOWN LOWERS
  this.cooldown -= (1000/60);
  if(this.cooldown < 0) {
    this.cooldown = 0;
  }
  //Determine dangerLevel
  var tileSize = data.maps[this.map].tileSize;
  if(this.map != null && this.sector != null){
    for(var tileId in data.maps[this.map].staticMap.sectors[this.sector].tiles){
        var tile = data.maps[this.map].staticMap.sectors[this.sector].tiles[tileId];
        if(((this.x > tile.x) && (this.x < tile.x + tileSize)) 
            && ((this.y > tile.y) && (this.y < tile.y + tileSize))){
            //console.log(tile);
            this.dangerLevel = tile.danger;
            break;
        }
    }     
  }
};

module.exports = Player;
