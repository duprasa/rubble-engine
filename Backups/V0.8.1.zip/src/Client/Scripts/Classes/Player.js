define(function(){
    var Player = function(x,y,rotation,nickname){
        this.x = x || 10;
        this.y = y || 10;
        this.radius = 15; //this should be sent from server
        this.imageRadius = 20; // this should be sent from server
        this.rotation = rotation || 0;
        this.offset = (this.imageRadius - this.radius); // offset if image is different size than the hittest radius
        this.velocity = {x:0,
                         y:0};
        this.nickname = nickname || 'no player name entered';
        this.items = {};
        this.sector = null;
        this.dangerLevel = 0; //this should be sent from server
        this.floorItems = []; //list of items under the player
        this.stats = {} // this is sent from server
        //CONSTANTS
        this.maxVelocity = Object.create({},{x:{writable:false, value:4},
                                             y:{writable:false, value:4}});
        this.accel =       Object.create({},{x:{writable:false, value:0.3},
                                             y:{writable:false, value:0.3}});
        this.decel =       Object.create({},{x:{writable:true, value:0.03},
                                             y:{writable:true, value:0.03}});
    };

    Player.prototype.move = function(){
        //move Player
        if (this.velocity.x){
            this.x += this.velocity.x;
            //decel velocity
            var tempVX = this.velocity.x;
            if(this.velocity.x > 0){
                this.velocity.x -= this.decel.x;
            }else{
                this.velocity.x += this.decel.x;
            }
            if(tempVX * this.velocity.x < 0){
                this.velocity.x = 0;
            }
        }
        if (this.velocity.y){
            this.y += this.velocity.y;
            //decel velocity
            var tempVY = this.velocity.y;
            if(this.velocity.y > 0){
                this.velocity.y -= this.decel.y;
            }else{
                this.velocity.y += this.decel.y;
            }
            if(tempVY * this.velocity.y < 0){
                this.velocity.y = 0;
            }
        }
    };

    Player.prototype.onCollision = function(wall,direction){
        //Default Collision behavior used with Player and Box
        var newlocation;
        switch(direction){
            case 'x':
                this.velocity.x = 0;
                break;
            case 'y':             
                this.velocity.y = 0;
                break;
        }
    };
    Player.prototype.setRotation = function(angle){
        this.rotation = Math.abs(this.rotation % 360);            
    };
    Player.prototype.doActions = function(keysPressed){
        //if can move
        if(keysPressed.up){
            //move Up
            if((this.velocity.y - this.accel.y) >= -this.maxVelocity.y){
                this.velocity.y -= this.accel.y;
            }          
        }
        if(keysPressed.down){
            //move Down
            if((this.velocity.y + this.accel.y) <= this.maxVelocity.y){
                this.velocity.y += this.accel.y;
            }

        }
        if(keysPressed.left){
            // move Left
            if((this.velocity.x - this.accel.x) >= -this.maxVelocity.x){
                this.velocity.x -= this.accel.x;
            }    
        }
        if(keysPressed.right){
            // move Right
            if((this.velocity.x + this.accel.x) <= this.maxVelocity.x){
                this.velocity.x += this.accel.x;
            }  
        }
        if(!keysPressed.lockDirection &&( keysPressed.up || keysPressed.down || keysPressed.left || keysPressed.right)){
            if (Math.abs(this.velocity.x) > 0.01 || Math.abs(this.velocity.y) > 0.01){
                this.rotation = calculateRotation(this.velocity);
            }
        }
    };
    Player.prototype.animate = function(screen){ 
        screen.drawRelRotatedImage(this.x - this.radius,
                        this.y - this.radius + 6,
                        'images/guy2Shadow.png',
                        this.rotation);
        screen.drawRelRotatedImage(this.x - this.radius,
                        this.y - this.radius,
                        'images/guy2.png',
                        this.rotation);
    };
    function calculateRotation(velocity){
        var negativeOffset;
        if(velocity.x < 0){
            negativeOffset = Math.PI
        }else{
            negativeOffset = 0;
        }
        var imageOffset = (Math.PI/2)
        return Math.atan(velocity.y/velocity.x) + imageOffset + negativeOffset;
    }
    return Player;
});