define(['SocketHandles'],function(socketHandles){
	function SocketHandler(){
		var started = false;
		this.socket = null;
		this.start = function(){
			if(typeof(io) === 'undefined'){
				return false;
			}else{
				//get new socket
				if(started === false){
					this.socket = io.connect('http://localhost:81');
					socketHandles.start(this.socket);
					return true;
				}else{
					throw 'socketHandler already started! cannot start again';
				}
			}
		};
	}
	return new SocketHandler();
});