'use strict';
	//dom events
	var buttonClick;
	var keyPress;
require(['AssetManager','UIHandler','SocketHandler','DomEventHandler','environmentTests','game/data'],
	function(am,uh,sh,domEventHandler,environmentTests,gameData){
	//dont use window onload dom might have already been loaded!
	//window.onload = function(){


		//show main page
		uh.changeContent('menu',function(){

			//test browser
			if(!environmentTests.testBrowser()){
				uh.changeMenu('incompatible');
				return;
			}

			//test socketIO
			console.log(sh);
			if(sh.start()){
				console.log(sh);
				uh.changeMenu('mainMenu');

				//load game assets
				loadGameAssets();

				//make domEvents accessible
				buttonClick = domEventHandler.buttonClick;
				keyPress	= domEventHandler.keyPress;
			}else{
				uh.changeMenu('error');
			}

		});

		function loadGameAssets(){
			//put all game assets to load here
			am.load(['images/background.png',
					 'images/guy2.png',
					 'images/menu.png',
					 'images/sprites/tileset.png',
					 'images/selectorBig.png',
					 'images/selectorSmall.png',
					 'images/selectorBig.png',
					 'images/selectedSmall.png',
					 'images/selectedBig.png',
					 'images/selectorSmall.png',
					 'images/menuOverlay.png',
					 'images/sprites/items.png',
					 'images/menuItemOverlay.png',
					 'images/guy2Shadow.png'],
					 function(assets){
					 	//check if any errors
						if(!assets.errors.length){
							gameData.gameLoaded = true;
						}else{
							uh.changeMenu('error');
							console.log('error loading game files');
							console.log(assets.errors);
						}
				 	 });
		}

	//};

});