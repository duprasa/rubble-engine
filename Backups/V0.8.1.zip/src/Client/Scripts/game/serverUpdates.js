define(['game/data'],function(gameData){
	function IO(){
		//var player = gameData.player;
		
		this.start = function(socket,player){
            //networking stuff
           
            socket.on('updateUser',function(data){


                //get all sector changes
                gameData.currentSectors = data.sectors;
                gameData.currentMap     = data.map;

            });
            socket.on('newMessages',function(messages){
            	console.log(messages);
            	gameData.newMessages = messages;
            });
      
		};
		this.stop = function(socket){
			socket.removeAllListeners('updateUser');
		};
	}
	return new IO();
});