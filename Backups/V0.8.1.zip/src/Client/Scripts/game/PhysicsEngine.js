///SAM SAM SAM SAM SAM
///SAM SAM SAM SAM SAM
///SAM SAM SAM SAM SAM
///SAM SAM SAM SAM SAM
///SAM SAM SAM SAM SAM
//WALLS are sent as static entites at beginning so they are gonna be with your maps object or wherever the tiles are
//NOT in currentSectors[x].entites.walls

define(['game/data'],function(gameData){
    var PhysicsEngine = Object.subClass({
        init: function(){
            var isPaused = false;
            this.pause = function(){
                isPaused = true;
            };
            this.resume = function(){
                isPaused = false;
            };
            this.update = function(){
                var player = gameData.player;
                var wall;
                if(isPaused){
                    return;
                }

                if(!(player.velocity.x === 0 && player.velocity.y === 0)){  
                    //Test for collisions
                    for(var i in gameData.currentSectors){  
                        if(gameData.currentSectors[i]){
                            //console.log(gameData.currentSectors);
                            //console.log(gameData.maps[gameData.currentMap].sectors[gameData.currentSectors[i].index]);
                            for(var j in gameData.maps[gameData.currentMap].sectors[gameData.currentSectors[i].index].walls){
                                wall = gameData.maps[gameData.currentMap].sectors[gameData.currentSectors[i].index].walls[j];
                                //check if future e1 intersects with wall
                                if(((player.x + player.offset + player.velocity.x + player.radius > wall.x) && (player.x + player.offset + player.velocity.x - player.radius < wall.x + wall.width )) &&
                                   ((player.y + player.offset + player.velocity.y + player.radius > wall.y) && (player.y + player.offset + player.velocity.y - player.radius < wall.y + wall.height))){

                                    //check if just x collision occures
                                    if(((player.x + player.offset + player.velocity.x + player.radius > wall.x) && (player.x + player.offset + player.velocity.x - player.radius < wall.x + wall.width )) &&
                                       ((player.y + player.offset + player.radius > wall.y) && (player.y + player.offset - player.radius < wall.y + wall.height))){     
                                       //stop player exaclty at the wall
                                        if(player.velocity.x > 0){
                                            player.x  = wall.x - player.radius - player.offset;
                                        }else{
                                            player.x = wall.x + wall.width + player.radius - player.offset;
                                        }
                                        //stop
                                        if(Math.abs(player.velocity.x) > 3){
                                            player.velocity.x = -player.velocity.x /2;
                                        }else{
                                            player.velocity.x = 0;
                                        }
                                        
                                    //Assume player is colliding on y axis
                                    }
                                    if(((player.x + player.offset + player.radius > wall.x) && (player.x + player.offset - player.radius < wall.x + wall.width )) &&
                                       ((player.y + player.offset + player.velocity.y + player.radius > wall.y) && (player.y + player.offset + player.velocity.y - player.radius < wall.y + wall.height))){   
                                        //stop player exaclty at the wall
                                        if(player.velocity.y > 0){
                                            player.y  = wall.y - player.radius - player.offset;
                                        }else{
                                            player.y  = wall.y + wall.height + player.radius - player.offset;
                                        }                           
                                        //stop
                                        if(Math.abs(player.velocity.y) > 3){
                                            player.velocity.y = -player.velocity.y /2;
                                        }else{
                                            player.velocity.y = 0;
                                        }
                                    }    
                                }
                            }
                        }
                    }
                }
            };

        }
    });
    return new PhysicsEngine;
});