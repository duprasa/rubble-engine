//this module is used to help reduce clutter on game
//for now all it does is draws all the assets to the screen

'use strict';
define(['game/data'],function(gameData){
	function GameManager(){

		this.animate = function(screen){
            //draw map backgrounds
            screen.fillBackground();
            var map = gameData.maps[gameData.currentMap];
            screen.drawSectors(map,'images/sprites/tileset.png',1);
            screen.drawSectors(map,'images/sprites/tileset.png',2);
            //draw items
            for(var sectorIndex in gameData.currentSectors) {
                if(gameData.currentSectors[sectorIndex]) {
                    for(var itemId in gameData.currentSectors[sectorIndex].entities.items) {
                        var itemToDraw = gameData.currentSectors[sectorIndex].entities.items[itemId];
                        screen.drawRelImage(itemToDraw.x,
                                            itemToDraw.y,
                                            gameData.itemInfo.imagePath,
                                            (gameData.itemInfo.items[itemToDraw.itemType].imageIndex % gameData.itemInfo.tilesWide) * gameData.itemInfo.tileSize,
                                            Math.floor(gameData.itemInfo.items[itemToDraw.itemType].imageIndex / gameData.itemInfo.tilesWide) * gameData.itemInfo.tileSize,
                                            gameData.itemInfo.tileSize,
                                            gameData.itemInfo.tileSize);
                    }
                }
            }
            //draw monsters

            //draw other players
            for(var sectorIndex in gameData.currentSectors) {
                if(gameData.currentSectors[sectorIndex]) {
                    for(var nickname in gameData.currentSectors[sectorIndex].entities.players) {
                        var playerToDraw = gameData.currentSectors[sectorIndex].entities.players[nickname];
                        if(playerToDraw.nickname !== gameData.player.nickname) {
                        	screen.drawRelText(playerToDraw.x - playerToDraw.radius,
								                       playerToDraw.y - playerToDraw.radius -12,
								                       playerToDraw.nickname,
								                       '16px Arial bold',
								                       'white');
					        screen.drawRelRotatedImage(playerToDraw.x - playerToDraw.radius,
								                       playerToDraw.y - playerToDraw.radius + 6,
								                       'images/guy2Shadow.png',
								                       playerToDraw.rotation);
                            screen.drawRelRotatedImage(playerToDraw.x - playerToDraw.radius,
						                               playerToDraw.y - playerToDraw.radius,
						                               'images/guy2.png',
						                               playerToDraw.rotation);
                        }
                    }
                }
            }
           
            //draw player
            gameData.player.animate(screen);
            screen.drawSectors(map,'images/sprites/tileset.png',3);

            //draw attacks 
                    
            //draw dangerLevel in bottom corner
			var color = 'green';
			if(gameData.player.dangerLevel > 80){
				color = '#6600CC';
			}else if(gameData.player.dangerLevel > 70){
				color = '#FF0000';
			}else if(gameData.player.dangerLevel > 60){
				color = '#FF3300';
			}else if(gameData.player.dangerLevel > 50){
				color = '#FFCC00';
			}else if(gameData.player.dangerLevel > 40){
				color = '#CCFF33';
			}else if(gameData.player.dangerLevel > 30){
				color = '#66FF33';
			}else if(gameData.player.dangerLevel > 20){
				color = '#00FF99';
			}else if(gameData.player.dangerLevel > 10){
				color = '#0099FF';
			}
			screen.drawText(805,80,gameData.player.dangerLevel,'30px Arial bold',color);
		};




	}
	return new GameManager();
});