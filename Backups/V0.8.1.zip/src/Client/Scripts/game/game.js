"use strict";
define(['Classes/Player','game/InputBindings','game/PhysicsEngine','game/ScreenHandler','game/data','game/serverUpdates','game/gameManager','game/chatManager'],
    function(Player,inputBindings,physicsEngine,Screen,gameData,serverUpdates,gameManager,chatManager){
    function Game(){
        var stop = false;
        var socket;

        this.start=function(assets,inSocket,IOGameData){
            stop = false;

            //temporary fix for menu manager multiple instance bug
            var menuManager = inputBindings.menuManager;


            //set up the canvas
            var canvas = document.getElementById('theGame');
            var menuCanvas = document.getElementById('theGameMenu');
            var screen = new Screen(canvas,assets.images);
            var menu = new Screen(menuCanvas,assets.images);

            //set up input
            inputBindings.changeState('inGame');

            //add maps to data
            gameData.maps = IOGameData.maps;

            gameData.currentSectors = IOGameData.sectors;
            gameData.currentMap     = IOGameData.player.map;
            gameData.monsterInfo    = IOGameData.monsterInfo;
            gameData.itemInfo       = IOGameData.itemInfo;

            //create 'real' player
            var player = new Player(IOGameData.player.x,
                                    IOGameData.player.y,
                                    IOGameData.player.rotation,
                                    IOGameData.player.nickname);
            console.log(IOGameData);
            player.items = IOGameData.player.items;
            player.sector = IOGameData.player.sector;
            player.stats = IOGameData.player.stats;
            player.dangerLevel = 0;
            //add player to game data
            gameData.player = player;

            //set up socket listeners
            socket = inSocket;
            serverUpdates.start(socket,player);
            //add monsters to data

            //get the 9 sectors around that player
                
            //set camera to follow player
            screen.follow(player);
            //THERE SHOULD BE A LOADING SCREEN UNTIL HERE

            //game loop
            (function gameLoop(){
                if(stop){
                    console.log('stopped game loop');
                    return;
                }
                console.log(player.velocity.x)
                //game data is updated from server in IO
                
                //do actions: physics and stuff go here
                player.doActions(inputBindings.keysPressed);
                physicsEngine.update();
                player.move();

                //determine danger level SHOULD BE DONE ON SERVER
                var tileSize = gameData.maps[gameData.currentMap].tileSize;
                for(var tileId in gameData.maps[gameData.currentMap].sectors[gameData.currentSectors[4].index].tiles){
                    var tile = gameData.maps[gameData.currentMap].sectors[gameData.currentSectors[4].index].tiles[tileId];
                    if(((player.x > tile.x) && (player.x < tile.x + tileSize)) 
                        && ((player.y > tile.y) && (player.y < tile.y + tileSize))){
                        //console.log(tile);
                        player.dangerLevel = tile.danger
                    }
                }     
                //determine if player is on an item SHOULD BE DONE ON SERVER
                var ITEM_SIZE = 40;
                player.floorItems = [];
                for(var sector in gameData.currentSectors){
                    if(gameData.currentSectors[sector] !== false){
                        // console.log(sector);
                        // console.log(gameData.currentSectors[sector]);
                        for(var itemId in gameData.currentSectors[sector].entities.items){
                            var item = gameData.currentSectors[sector].entities.items[itemId];
                            if(((player.x > item.x) && (player.x < item.x + ITEM_SIZE)) 
                                && ((player.y > item.y) && (player.y < item.y + ITEM_SIZE))){
                                player.floorItems.push(item);
                            }
                        }     
                    }
                }
                //update the menu
                menuManager.update();

                //draw when frame is ready
                requestAnimFrame(function(){
                    //draw assets and tiles                    
                    gameManager.animate(screen);

                    //draw menu overlay
                    if(inputBindings.getStateName() === 'inMenu'){
                        screen.drawImage(0,0,'images/menuOverlay.png')
                    }
                    //draw chat
                    chatManager.animate(screen);
                    //paint all the changes from the screen
                    screen.paint();

                    //draw Menu
                    menu.drawBackground('images/menu.png');
                    menuManager.animate(menu);
                    menu.paint();

                });
                    //update server with changes
                    gameData.updateServerData.player = {x:player.x,y:player.y,rotation:player.rotation};
                    socket.emit('userUpdate',gameData.updateServerData);
                    //clearItems from updateServerData
                    gameData.updateServerData.itemChanges = [];
                    gameData.updateServerData.messages = [];
                    //clear player floor items

                    //this must be at 64 or more or anim frame laggs
                    setTimeout(gameLoop,(1000/64));
                })();
        };
        this.stop =function(){
            if(!socket){
                console.log('game is already stopped');
            }
            serverUpdates.stop(socket);
            inputBindings.changeState('default');
            socket.emit('logOut',{});
            stop = true;
            //empty the array
            // entities.splice(0, entities.length);
            //clear online players
            // for (var prop in onlinePlayers) { if (onlinePlayers.hasOwnProperty(prop)) { delete onlinePlayers[prop]; } }
        };
    }
    return new Game();
});