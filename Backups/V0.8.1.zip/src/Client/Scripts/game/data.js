define(function(){
	return{
			//game ready states
			gameLoaded:false,
		    
		    player:null,
		    
		    monsterInfo: {},
		    itemInfo   : {},

		    currentMap:'No Map',
		    currentSectors:[],
		    newMessages:{},
		    serverInventory:[],
		    updateServerData:{
		    	player:{x:null,y:null,rotation:null},

		    	itemChanges:[],
		    		//possible contents of itemChanges
		    		// {DROPPED:itemMenuPosition}
		    		// {SWITCHED:{item menuPosition(origin) : item menuPosition(destination)}}
		    		// {PICKUP:{itemID:item menuPosition}}
		    	pickedUp:{}, //item id : itemMenuPosition
		    	messages:[] //this might be able to be more than one but has never occured
		    },
		    //static object
		    maps:{},
		};
});