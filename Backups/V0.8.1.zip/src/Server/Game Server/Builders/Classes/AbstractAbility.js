var data = require("../../Data");

function AbstractAbility() {

}

AbstractAbility.prototype.type = 'ATTACK';



module.exports = AbstractAbility;

AbstractAbility.prototype.update = function() {
	if(!this.map) {
		this.timeLeft = this.timeToLive;
	} else {
		this.timeLeft -= 1000/60; //To change.

		if(this.timeLeft <= 0) {
			this.die();
		}
	}
}

AbstractAbility.prototype.die = function() {
	data.maps[this.map].removeEntity(this);
	delete data.abilities[this.id];
}


