var ib = require('../ItemBuilder');
function Player(x,y,rotation,nickname){
	 

        this.nickname = nickname || 'no nickname entered';
        this.x = (x || 240);
        this.y = (y || 60);
        this.radius = 15;
        this.rotation = rotation || 0;
        this.sector = null;
        this.map = null;
        this.type = 'PLAYER';

        //This does not need to be in client.
        this.damageTaken = {};

        this.stats = {
          level: 1,
          exp : 30,
          nextLevelXP: 300,
          STR : 1, // damage delt (adds damage)
          DEF : 1, // minus damage received
          DEX : 1, // increase rate of AP recovery
          STA : 1, // increate rate of HP recovery
          SPD : 1, // faster movement
          AGL : 1, // increases acceleration
          VUL : 1, // decrease vulnarability time
          LUK : 1, // increases drop luck
          HP : 50,
          AP : 50,
          maxHP : 50,
          maxAP : 50,     
          playersKilled:0,
          monstersKilled:0,
          deaths:0
        };
        this.items = {0:ib.create('SLIME_REMAINS'),
                      1:ib.create('SLIME_REMAINS'),
                      2:ib.create('STICK'),
                      3:ib.create('SLIME_REMAINS'),
                      4:ib.create('SLIME_REMAINS'),
                      5:ib.create('SLIME_REMAINS'),
                      6:ib.create('SLIME_REMAINS'),
                      7:ib.create('SLIME_REMAINS'),
                      8:ib.create('SLIME_REMAINS'),
                      9:ib.create('STICK'),
                      10:null,
                      11:ib.create('SLIME_REMAINS'),
                      12:ib.create('SLIME_REMAINS'),
                      13:ib.create('SLIME_REMAINS'),
                      14:ib.create('SLIME_REMAINS'),
                      15:ib.create('SLIME_REMAINS'),
                      16:ib.create('SLIME_REMAINS'),
                      17:ib.create('SLIME_REMAINS'),
                      18:null,
                      19:ib.create('SLIME_REMAINS'),
                      20:ib.create('SLIME_REMAINS'),
                      21:ib.create('SLIME_REMAINS'),
                      22:null,
                      23:ib.create('SLIME_REMAINS'),
                      24:ib.create('SLIME_REMAINS'),
                      25:ib.create('SLIME_REMAINS'),
                      26:ib.create('SLIME_REMAINS'),
                      27:ib.create('SLIME_REMAINS'),
                      28:ib.create('SLIME_REMAINS')};
}
Player.prototype.levelUp = function(){
        //use a formula to distribute levels to skills
};
Player.prototype.die = function() {
  if(this.status !== "DEAD") {
    return;
  }

  var biggestDamage = { player : false ,damage : 0 };
  for(var nickname in this.damageTaken) {

    //give % of exp based on dmg / maxHP 
    //TODO: Allies
    //Ceil it as minimum exp would be 1.
    if(data.players[nickname]) {
      data.players[nickname].exp += Math.ceil(this.exp * (this.damageTaken[nickname] / this.maxHP));
      
    } else {
      log.warn('No such player with nickname "' + nickname + '" exists. Cant award EXP.');
    }

    if(this.damageTaken[nickname] > biggestDamage.damage) {
      biggestDamage.player = nickname;
      biggestDamage.damage = this.damageTaken[nickname];
    }

  }
  for(var i in this.items) {
    this.items[i].owner = biggestDamage.player;
    data.maps[this.map].insertEntity(this.items[i],this.x,this.y);
    player.items[i] = null;
  }

};

Player.prototype.update = function() {
  //HP REFILLS
  //AP REFILLS
};

Player.prototype.damage = function(username,damage) {
  //When monster gets damaged what happens depends on the monster's state.
  switch(this.status) {
    //
  }

  var damageDealt = ((damage - this.def) >= 1) ? (damage - this.def) : 0; // Math.max(damage - this.def,0)
  if(damageDealt > this.maxHP) {
    damageDealt = this.maxHP;
  }
  //keep track of damage dealt and by whom
  if(this.damageTaken[username]) {
    this.damageTaken[username] += damageDealt;
  } else {
    this.damageTaken[username]  = damageDealt;
  }

  //Ouch!
  this.hp -= damageDealt;

  //Check if moster is still alive.
  if(this.hp <= 0) {
    this.status = "DEAD";
    //Send message to sockets? or have them figure out that monster is dead by themselves?
    data.maps[this.map].removeEntity(this);
    this.die();
  } else if (this.hp <= (this.maxHP * 0.15)) {
    this.status = "DIEING";
  }
};
module.exports = Player;
