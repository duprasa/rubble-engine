var ib = require('../ItemBuilder');
var data = require('../../Data');
var log  = require('../../../Utility/Logger').makeInstance('Abstract Monster');
function AbstractMonster() {

}

//Static properties defaults
AbstractMonster.prototype.type = 'MONSTER';



AbstractMonster.prototype.die = function() {
	if(this.status !== "DEAD") {
		return;
	}
	
	var drops = [];
	var biggestDamage = { player : false ,damage : 0 };
	
	for(var nickname in this.damageTaken) {
		//TODO: Allies
		if(data.players[nickname]) {
			data.players[nickname].exp += Math.ceil(this.exp * (this.damageTaken[nickname] / this.maxHP));
			
		} else {
			log.warn('No such player with nickname "' + nickname + '" exists. Cant award EXP.');
		}

		if(this.damageTaken[nickname] > biggestDamage.damage) {
			biggestDamage.player = nickname;
			biggestDamage.damage = this.damageTaken[nickname];
		}
	}

	for(var i in this.drops) {
		var roll = Math.random() * 100;
		if(this.drops[i] >= roll) {
			var drop = ib.create(i,this.x,this.y,this.map);
			drop.owner = biggestDamage.player;
			drops.push(drop);
		}
	}
	this.die = null;
};

AbstractMonster.prototype.update = function() {
	//Guard in case dead but not removed from entities.
	if(this.status === "DEAD") {
		return;
	}

	//If target is too far.... forget it.
	if(this.status === "ATTACKED" || this.status === "DIEING") {
		if(this.target) {
			//use math.abs
			if((this.target.x - this.x) > 500 || (this.target.x - this.x) < (-500)) {
				this.status = "CALM";
				this.target = null;
			}
		} else {
			this.status = "CALM";
		}
	}
	switch(this.behavior[this.status]){
		case "WALK":
		//Walk around..
		break;
		case "FOLLOW":
			if(this.target) {
				//set nextX .. nextY for physics to validate?
			} else {
				this.status = "CALM";
			}
		break;
		case "ATTACK":
		//follow target and attack ..using attack.. 
		//stop if they run away..
		break;
		case "RUN_AWAY":
		//Run away from target 
		break;
	}	

	//monsters should refill hp if not damaged for a while
};

AbstractMonster.prototype.damage = function(username,damage) {
	//When monster gets damaged what happens depends on the monster's state.
	switch(this.status) {
		case "CALM":
			this.status = 'ATTACKED';
			this.target = username;
			break;
		case "ATTACKED":
			this.target = username;
			break;
		case "DIEING": 
			//Not much to do at this point..
			break;
		case "DEAD":
			//aren't you cruel?
			return;
			break;
	}

	var damageDealt = ((damage - this.def) >= 1) ? (damage - this.def) : 0; // Math.max(damage - this.def,0)
	if(damageDealt > this.maxHP) {
		damageDealt = this.maxHP;
	}
	//keep track of damage dealt and by whom
	if(this.damageTaken[username]) {
		this.damageTaken[username] += damageDealt;
	} else {
		this.damageTaken[username]  = damageDealt;
	}

	//Ouch!
	this.hp -= damageDealt;

	//Check if moster is still alive.
	if(this.hp <= 0) {
		this.status = "DEAD";
		//Send message to sockets? or have them figure out that monster is dead by themselves?
		delete data.monsters[this.id];
		data.maps[this.map].removeEntity(this);
		this.die();
	} else if (this.hp <= (this.maxHP * 0.15)) {
		this.status = "DIEING";
	}
};

module.exports = AbstractMonster;

