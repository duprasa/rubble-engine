//Imports
var AbstractMonster = require('./Classes/AbstractMonster');
var log          = require('../../Utility/Logger').makeInstance('Monster Builder');
var fm           = require('../../Utility/FileManager');
var data         = require('../Data');


var uniqueMonsterId = 0;
var initialized = false;
var constructors = {};

exports.init   = function(callback) {
	if(initialized) {
		log.warn('Already initialized!');
		return;
	}

	initialized = true;

	var monsterDefinitions;
	var path = '/../../Shared/Classes.monster';
	var constructorsToLoad = 0;

	fm.fetchFile(path,function(err,file) {
		if(err) {
			log.error('Can\'t fetch file ' + path);
		} else {
			monsterDefinitions = JSON.parse(file);

			if(!monsterDefinitions) {
				log.warn('JSON file unreadable.');
				return;
			}

			for(var name in monsterDefinitions.monsters) {
				constructors[name] = returnConstructor(name,monsterDefinitions.monsters);

				constructors[name].prototype = new AbstractMonster();
				constructors[name].prototype.monsterType = name;
				constructors[name].prototype.radius = monsterDefinitions.monsters[name].radius;
				constructors[name].prototype.exp = monsterDefinitions.monsters[name].exp;
				constructors[name].prototype.maxHP = monsterDefinitions.monsters[name].maxHP;
				constructors[name].prototype.atk = monsterDefinitions.monsters[name].atk;
				constructors[name].prototype.str = monsterDefinitions.monsters[name].str;
				constructors[name].prototype.def = monsterDefinitions.monsters[name].def;
				constructors[name].prototype.spd = monsterDefinitions.monsters[name].spd;
				constructors[name].prototype.drops = monsterDefinitions.monsters[name].drops;
				constructors[name].prototype.behavior = monsterDefinitions.monsters[name].behavior;
				constructors[name].prototype.attacks = monsterDefinitions.monsters[name].attacks;

			}

			callback();

		}
	});


};


exports.create = function(monsterName,x,y,optionalMap) {
	if(!initialized) {
		log.warn('Not initialized yet.');
		return;
	}

	var monster = new constructors[monsterName]();
	monster.id = uniqueMonsterId++;
	monster.x = x;
	monster.y = y;
	data.monsters[monster.id] = monster;

	if(optionalMap) {
		data.maps[optionalMap].insertEntity(monster);
	}

	return monster;
};

function returnConstructor(name,definitions) {
	return function() {
		this.id;
		this.hp = definitions[name].maxHP;
		this.monsterType = name;
		this.damageTaken = {};
		this.status = "CALM";
		this.target = null;
		this.x = null;
		this.y = null;
		this.sector = null;
		this.map = null;
		this.rotation = 0;
	}			
}

