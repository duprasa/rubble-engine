//Imports
var AbstractAbility = require('./Classes/AbstractAbility');
var log          = require('../../Utility/Logger').makeInstance('Ability Builder');
var fm           = require('../../Utility/FileManager');
var data         = require('../Data');


var uniqueAbilityId = 0;
var initialized = false;
var constructors = {};

exports.init   = function(callback) {
	if(initialized) {
		log.warn('Already initialized!');
		return;
	}

	initialized = true;

	var abilityDefinitions;
	var path = '/../../Shared/Classes.attack';
	var constructorsToLoad = 0;

	fm.fetchFile(path,function(err,file) {
		if(err) {
			log.error('Can\'t fetch file ' + path);
		} else {
			abilityDefinitions = JSON.parse(file);

			if(!abilityDefinitions) {
				log.warn('JSON file unreadable.');
				return;
			}

			for(var name in abilityDefinitions.abilities) {
				constructors[name] = returnConstructor(name,abilityDefinitions.abilities);

				constructors[name].prototype = new AbstractAbility();
				constructors[name].prototype.abilityType = name;
				constructors[name].prototype.AP = abilityDefinitions.abilities[name].AP;
				constructors[name].prototype.timeToLive = abilityDefinitions.abilities[name].timeToLive;
				constructors[name].prototype.damage = abilityDefinitions.abilities[name].damage;
				constructors[name].prototype.accel = abilityDefinitions.abilities[name].accel;
				constructors[name].prototype.maxSpeed = abilityDefinitions.abilities[name].maxSpeed;
				constructors[name].prototype.radius = abilityDefinitions.abilities[name].radius;
				//Other prototype properties go here.

			}

			callback();

		}
	});


};


exports.create = function(abilityName,x,y,optionalMap) {
	if(!initialized) {
		log.warn('Not initialized yet.');
		return;
	}

	var ability = new constructors[abilityName]();
	ability.id = uniqueAbilityId++;
	ability.x = x;
	ability.y = y;
	data.abilities[ability.id] = ability;
	
	if(optionalMap) {
		data.maps[optionalMap].insertEntity(ability);
	}

	return ability;
};

function returnConstructor(name,definitions) {
	return function() {
		this.id = null;
		this.abilityType = name;
		this.owner = false;
		this.x = null;
		this.y = null;
		this.sector = null;
		this.map = null;
		this.timeLeft = definitions[name].timeToLive;
	}			
}

