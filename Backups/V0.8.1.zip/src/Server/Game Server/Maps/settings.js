
module.exports = {
	maps: [
		'test',
		'tutorial'
	],
	//Dimensions of sectors in tiles.
	sectorSize : 14, // in tiles of size : (defaultTileSize)
	defaultTileSize : 32,
	defaultMapName  : "Unnamed",
	//Defaults for tile settings.
	defaultGraphic : 0,
	defaultDanger  : 0,
	defaultMonsterSpawn : 0,
	defaultPhysics      : 0,
	//offsets because of tiled map editor..
	graphicOffset      :   0,
	physicsOffset      : 3000,
	dangerOffset       : 3100,
	monsterSpawnOffset : 3200,
	//some graphic tilesheet info
	tileSheetWidth     : 8,
	tileSheetHeight    : 375,
	//type definition.
	physicsType : {
		"1"  : "SOLID_WALL",
		"11" : "HALF_WALL"
	},

	monsterSpawnType   : {
		"0" : null,
		"1" : "SLIME",
		"2" : "BIG_SLIME",
	}
};