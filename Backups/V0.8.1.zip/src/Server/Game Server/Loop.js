/*== Game Loop Module ==*/

//Status: 1 (needs to be implemented AND defined)
//This module decides when to use other modules to validate gameData
//or alter the game, it is the heart of the game server and decides what
//the game actually does.



//Imports
var settings = require("../Settings").gameServer;
var log      = require('../Utility/Logger').makeInstance("GameLoop");
var physics         = require("./Game Logic Modules/Physics");
var collisionEvents = require("./Game Logic Modules/CollisionEvents");
var monsterSpawner  = require("./Game Logic Modules/MonsterSpawner");
var clientUpdates   = require("./IO/ClientUpdates");
var clientEvents    = require("./IO/ClientEvents");
var data            = require("./Data");
//for testing to be removed
var ioHandler = require('../IO Server/IOHandler');


//Module logging
log.enabled = true;
log.level   = 4;


var looping = false;


exports.start = function() {
	if(settings.moduleEnabled["Loop"] == false) {
		return;
	}
	
	looping = true;


	//Initialize modules
	monsterSpawner.init();
	//Begin loop
	loop();
};

exports.pause = function() {
	looping = false;
};

function loop() {
	if(!looping){
		return;
	}

	var startTime = Date.now();
		
	//Receive client events
	clientEvents.update();

	//Collision (to be done soon.)
	var collisions = physics.update();
	collisionEvents.update(collisions);

	//Make sure all entities' sectors' are updated.
	for(var mapName in data.maps) {
		data.maps[mapName].update();
	}

	//Loop through entities
	for(var itemName in data.items) {
		data.items[itemName].update();
	}
	for(var abilityName in data.abilities) {
		data.abilities[abilityName].update();
	}

	//Spawn monsters
	monsterSpawner.update();
	
	//update clients
	clientUpdates.update();
	
	if(Date.now() - startTime > (1000 / settings.FPS)) {
		log.warn("Server Game loop running slow.");
	}
	//Go through some more logic modules.
	setTimeout(loop,1000/ settings.FPS);
};


