var server = require('./Server/Server.js');

server.start();