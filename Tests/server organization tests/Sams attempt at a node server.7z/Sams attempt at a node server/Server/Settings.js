exports.settings = {
	 moduleEnabled: {
		logger : true
	},
//these are for the logger Utility
	loggerLevel:4,
//these are for the server
	domain : "localhost",
	port : 80,
	logLevel : 1,
	closeTimeout: 10,
	heartbeatTimeout: 10,
	heartbeatInterval: 5,
	pollingDuration: 5
};