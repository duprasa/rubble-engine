var log = require('../Utility/Logger');
var router = require('./router.js');
var socketIO = null;
var initailized = false;

exports.init = function(inSocketIO){
	initialized = true;
	socketIO = inSocketIO;
	log.debug('IO server initialized!');

};
exports.start = function(){
	if(!initialized){
		return;
	}
	router.route(socketIO);

};
exports.getSocketIO = function(){
	if(!initialized){
		return;
	}
	return socketIO;
};
exports.sendMessage = function(Data){
	if(!initialized){
		return;
	}

};
exports.showQueue = function(){
	log.debug(router.socketQueue);
}