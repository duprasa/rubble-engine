exports.settings = {
	domain : "localhost",
	port : 80,
	encoding: "utf8"
};