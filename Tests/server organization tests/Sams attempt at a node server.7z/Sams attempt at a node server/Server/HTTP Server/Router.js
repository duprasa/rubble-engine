var url    = require('url');
var handle = require('./Handlers').handles;
var log    = require('../Utility/Logger');

exports.route = function(rawUrl,response,postData) {
	var parsedUrl = url.parse(rawUrl);
	var pathname = parsedUrl.pathname;
	var category = pathname.split("/")[1];

	//Intercept file requests.
	switch(category) {
		//handle all file cases
		case "scripts": case "images": case "sounds": case "styles": case "json":
			if(pathname.split("/")[2]) {
				handle[category](response,pathname.split("/")[2]);
			} else {
				handle['notFound'](response);
			}
		break;
		//handle favicon case
		case "favicon.ico":
				handle['images'](response,"favicon.ico");
		break;

		//Page Requests
		default:
			//test if the handle exists
			if (typeof handle[pathname] === 'function') {
				handle[pathname](response,postData,parsedUrl);
			} else {
				log.warn("No Request Handler found for " + pathname)
				handle['notFound'](response);
			}
		break;
	}
};
