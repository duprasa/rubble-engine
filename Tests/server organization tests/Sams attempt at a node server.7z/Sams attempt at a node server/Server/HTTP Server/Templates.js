var swig = require("swig");
var log  = require('../Utility/Logger');
exports.templates = {
	'client': swig.compileFile(__dirname + '/../../Client/Templates/client.html')
};