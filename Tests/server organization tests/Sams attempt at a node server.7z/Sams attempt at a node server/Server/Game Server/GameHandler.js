/*== Game Server Module ==*/

//Status: 2 (needs additions/editing)
//This is the root of the game, it launches the main gameloop.



//Imports
var gameData     = require("./game_data");
var gameLoop     = require("./game_loop");
var settings     = require("./server_settings");
var clientEvents = require("./client_events");
var database     = require("./database");
var log 		 = require('../Utility/Logger');

var initialized = false;
var ioHandler = null;
var socketIO = null;
exports.init = function(inIoHandler){
	log.debug('game server initialized!');
	ioHandler = inIoHandler;
	socketIO = ioHandler.getSocketIO();
};

//Game Server start
exports.start = function() {
	log.debug('game server started!');
	if(!(settings.moduleEnabled["game_server"] && initialized)) {
		return;
	}
	settings.listModules();

	database.load(gameData);
	clientEvents.init(gameData, socketIO);
	gameLoop.start(gameData, socketIO);

};
