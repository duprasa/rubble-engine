/*== Collision Events module ==*/

//Status: -1 (Empty as fuck)
//This module says what things do when they collide with each other.
//It uses the collision list obtained from the physics module.



//Imports
var rules    = require("./game_logic");
var settings = require("./server_settings");


var update = function(gameData, collisions) {
	if(settings.moduleEnabled["collision_events"] == false || (collisions == null))  {
		return;
	}

	//Empty
};


exports.update = update;