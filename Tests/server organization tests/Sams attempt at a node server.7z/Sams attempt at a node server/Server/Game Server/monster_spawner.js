/*== Monster Spawner Module ==*/

//Status: -1 (Empty as fuck)
//This module decides when to use other modules to validate gameData
//or alter the game, it is the heart of the game server and decides what
//the game actually does.



//Imports
var rules    = require("./game_logic");
var settings = require("./server_settings");

var update = function(gameData) {
	if(settings.moduleEnabled["monster_spawner"] == false) {
		return;
	}

	//Probably uses maps and monsters to determine where spawns are needed.
};


//Exports
exports.update = update;
