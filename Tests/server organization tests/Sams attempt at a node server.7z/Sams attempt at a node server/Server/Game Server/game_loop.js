/*== Game Data Module ==*/

//Status: 1 (needs to be implemented AND defined)
//This module decides when to use other modules to validate gameData
//or alter the game, it is the heart of the game server and decides what
//the game actually does.


//Imports
var settings = require("./server_settings");
var log 		 = require('../Utility/Logger');

//Game logic modules Imports
var physics         = require("./physics");
var collisionEvents = require("./collision_events");
var monsterSpawner  = require("./monster_spawner");
var clientUpdate    = require("./client_update");


var start = function(gameData, socketServer) {
	
	if(settings.moduleEnabled["game_loop"] == false) {
		return;
	}

	//TODO: SetTimeout with proper logic. Is it running too slow? etc.
	
	function loop() {

		var collisions = physics.update(gameData);
		collisionEvents.update(gameData,collisions);
		clientUpdate.update(gameData, socketServer);
		monsterSpawner.update(gameData);
		//Go through some more logic modules.
		setTimeout(loop,1000/60);
	};

};


exports.start = start;