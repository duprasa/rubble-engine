/*== Physics Module ==*/

//Status: -1 (Empty as fuck)
//This module checks for collisions and adds them to a queue,
//it is also in charge of updating locations of players and monsters
//using their nextLocation property, this module returns the list of collisions.



var settings = require("./server_settings");

var update = function(gameData) {

	if(settings.moduleEnabled["physics"] == false) {
		return null;
	}

	//Empty
	return collisions;
};


exports.update = update;